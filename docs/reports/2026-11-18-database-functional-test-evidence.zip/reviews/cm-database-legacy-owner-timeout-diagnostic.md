# Legacy owner SQL timeout diagnostic

Status: same frozen source passes unchanged on the released core SQL fixture; legacy suite still running at initial report. No product, test assertion, timeout, frozen source, or running fixture was modified by this diagnosis.

## Source and commands

Frozen source manifest: `dc384330cef3d943dc0e7060ae06a464213f1e3a7bc4875e7f381b25c314f11c`.
Remote source root: `/root/cm-database-completion-20261118/final`.
`git diff acf8665a --stat -- backend/internal/ownerrecords` is empty: the whole ownerrecords directory is unchanged against baseline.

Read-only source inspection:
- `migration_test.go:260` calls `verifyCalendarAndReportIsolation` after the successful 500-owner growth and numeric checks.
- `calendar_test.go:183–194` uses an unchanged 3-second context on each of two `processDueReports` passes, requiring progress of at most five jobs.
- `report_worker.go:100–115` starts another job if the parent has at least 300ms, then reserves 150ms from the remaining parent deadline for bookkeeping.
- `report_worker.go:140–165` retains a failed job for retry with reason `report_budget` and returns its error. The logged `budget_exhausted` checks only the parent context, so false does not imply the child deadline remained valid.

Root explicitly allocated released query fixture 33327 for one comparison. Before starting, runner verified every file against the frozen inventory, successful v3 query-capacity metadata, no TCP clients on 33327, zero other root SQL connections, healthy owned mysql-perf Pod, and marker1.

Actual recorded command:
```
env NB_KEYS_TEST_MYSQL=127.0.0.1:33327 /root/cm-nfs-multislot-20261105/tools/usr/local/go/bin/go test ./internal/ownerrecords -run '^TestOwnerMigrationMySQL$' -json -p 1 -count=1 -timeout=10m
```
No additional runtime/Kube/Redis/MinIO opt-in was inherited. Blank owned-fixture root password was supplied privately. Standard offline Go cache environment and CGO0/GOMAXPROCS2 match the legacy runner.

## Observed failing legacy environment

Raw: `final/evidence/v3-legacy-sql-regression.jsonl` on 54.
Original test failed in 170.35s at `2026-11-17T20:49:52.512579053Z`.

- Before failure: 500 owners/20 concurrent Growth reads elapsed5.232217302s, P95 210.030828ms, statistics write attempts0, global rank builds1; 500 numeric aggregation calls1.615238251s.
- Burst phase logged completed4, elapsed2859ms, parent budget_exhausted=false.
- Fifth job failed in `ReportRevisions` for `report-burst-4@example.test`. The logged SQL took0.00001s; child deadline had already expired8.415826ms, while parent still had141.58597ms remaining. This is cumulative per-job latency exhausting the child budget, not a single 3-second query.
- Legacy resource configuration:2CPU/4Gi limit,1Gi buffer, nativeAIO0, MySQL8.4.8, max80; port33347 via socat.
- Empty report phases repeatedly take40–41ms. Actual proxy args: `socat TCP4-LISTEN:33347,bind=127.0.0.1,reuseaddr,fork TCP4:10.244.236.16:3306` (no explicit nodelay). TCP delayed ACK/Nagle interaction is a plausible transport hypothesis, not established by this comparison. No proxy was changed or latency experiment run while the suite was using it.

## Fair core comparison: PASS

Recorder suite_id `owner-baseline-resource-check`, runner exit0 and command_exit_code0; started20:56:02.743725Z, finished20:56:08.285038Z, wall5.541099s.

- TestOwnerMigrationMySQL PASS4.77s;1leaf PASS,0SKIP/FAIL.
- Both unchanged 3-second burst passes completed5 jobs, elapsed65ms and64ms.
- Growth500owner/20concurrent:elapsed523.301848ms/P9524.16908ms;statistics write attempts0/global rank builds1.
- Numeric500calls:179.796326ms.
- mysql-perf UID `8bbffab5-16c4-4630-a12c-9ed0252b1bb7`:4CPU/8Gi limit,4Gi buffer,nativeAIO1,MySQL8.4.8,max80.
- 33327 released after this sole command finished.

Remote evidence under `final/evidence/`:
- `owner-baseline-resource-check-runner.py` (outside frozen app/source manifest)
- `v3-owner-baseline-resource-check-fixture.json`
- `v3-owner-baseline-resource-check.meta.json`
- `v3-owner-baseline-resource-check.jsonl`, SHA256 `ac89e19cea4bbd6a6fb7d83cbb437c7bf963276b3871beb5c4efba52d51958eb`
- `v3-owner-baseline-resource-check-console.log`

Classification: environment-dependent failure of an unchanged baseline test, not reproduced on the prescribed core environment with identical source and assertions. This comparison changes resource and transport configuration together, so it does not identify CPU, buffer, nativeAIO, or proxy as the sole cause. Do not modify product budgets or soften the test. Final supplemental acceptance should use the fair core environment or a separately validated equivalent fixture; retain the original failed run as diagnostic evidence.

## Legacy failure collection (in progress)

At20:56:13Z legacy was in services. Confirmed failures remain:
- Handler `TestGatewayActivityPublicProtocolsRejectStoppedAndStaleMySQL`:8leaf failures (chat/responses/anthropic/images × stopped/stale), all independently assigned to E4 for missing109 fixture migration; their independent RED/GREEN is separate evidence.
- Owner `TestOwnerMigrationMySQL`:1leaf, classified above and same-source core comparison PASS.
Parent/package fail events are not extra failing cases. Final counts will be appended after suite completion.

## Subsequent single-factor network diagnostic (E4, independently read)

E4 used a separate loopback33357 proxy with `nodelay` on both TCP endpoints to the **same** running legacy MySQL Pod; original33347 and its clients were left unchanged. Raw `final/evidence/legacy-sql-network-auto-prepare-roundtrips.jsonl` records both ports with identical MySQL server_uuid `e9a58dfc-e2c6-11f1-8a87-e6d1e475d3ce`, MySQL8.4.8/1GiB buffer/nativeAIO0.40 measured calls per mode follow3 warmups, persistent connection, same Go client; no test/product timeout was changed.

| Query mode | Original33347 P95 | Separate nodelay33357 P95 |
|---|---:|---:|
| plain SELECT1 |0.163023ms|0.128779ms|
| persistent prepared SELECT? |0.074318ms|0.109917ms|
| temporary auto-prepared SELECT? |41.603765ms|0.705217ms|

Auto-prepared mean was40.670972075ms vs0.441171775ms. This directly reproduces and removes the ~40ms per-command transport penalty without changing database resources. It supports the observed owner timeout's environment classification and identifies a concrete proxy transport defect; the owner test itself has so far been rerun on core33327 only, not33357. Original failed suite remains running and must finish before any replacement of33347. The safe next validation is the unchanged owner test/full selected suite after authorized proxy correction, retaining the original budgets.

## Final retained partial run (root terminated after confirming proxy defect)

Root terminated only the legacy Go process tree. Recorder finished `2026-11-17T21:01:40.508339Z`, exit_code **-15**. This is not a passing suite. JSONL SHA256 `a18e75d648d52e0ac0f28cc27dd6c49992f1427a5168e78a2abd7711ee249af0`.

Final completed leaf totals: **318 PASS, 11 FAIL, 0 SKIP**. Parent/package fail events are excluded. Four packages finished: db PASS5.489s, handlers FAIL0.752s, ownerrecords FAIL540.903s, repository PASS279.589s. Services was interrupted before completion.

Failure categories:
1. Eight handler leaf failures: missing migration109 in the old partial fixture. E4 owns the narrow fixture correction and separate actual normal/race evidence.
2. One unchanged owner baseline failure: child report budget exhaustion, independently PASS4.77s on core with unchanged3s assertions, as above.
3. Two additional services deadline failures appeared just before termination: `TestAutoStopScanDoesNotWaitForAnotherRuntimeType` (4.05s) and `TestAutoStopRetriesBriefLifecycleLockContention` (4.09s). Both fail exactly `instance_auto_stop_dispatch_test.go:121: slow OpenClaw stop blocked independent runtime types: entered=map[1:true]`. The unchanged test allows2s for all4 mocked Runtime types to enter. Later context-canceled SQL logs are cleanup after this assertion. These are timing failures under the proven per-query proxy penalty, not yet independently reproduced on corrected transport; do not claim resolved until the complete corrected-transport run passes, and do not change product/thresholds on this evidence.

Machine-readable complete leaf names/package durations/exit/source hash preserved remotely in `final/evidence/v3-legacy-sql-partial-classification.json`. Monitoring is stopped as requested. No further test launched; no source or frozen runner changed. Parent plans authorized same-Pod proxy correction followed by a full freshly frozen run.
