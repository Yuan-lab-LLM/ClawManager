# Consolidated whole-branch W1–W4 remediation

Status: implementation and same-source covering, native8 and focused race verification COMPLETE. Original W1–W4 closure is retained; R1–R3 fixes and all covering tests pass. Parent owns final independent review and the frozen whole-branch acceptance run. The first final native batch failed on cached allocator statistics and the general SQL fixture OOM; those raw failures are retained and were superseded by the successful current-source rerun. Parent owns the frozen full suite, final900k performance execution and independent rereview. No application deployment, image build, Runtime upgrade, production cleanup or commit occurred.

Source: ClawManager branch `database`, base HEAD `71d723ac` plus shared uncommitted work. Runtime source was not edited. F3 cancellation and parent E3 guards preserved. All executable builds/tests/browser runs occurred on root@10.130.81.54; local work was source/document edits, reading and gofmt.

## W1: actual monthly writes and reads

Five observational kinds now use registered monthly rows for real payload and metadata serving after explicit per-month cutover: model_invocations, audit_events, chat_messages, risk_hits and display copies of cost_records. Cost's native financial source is authoritative and is absent from archival/deletion Kinds. Identity, budgets, ledgers and active Team tasks remain native.

The approved gray deployment keeps fixed native sources for AUTO_INCREMENT public IDs, compatibility writers and rollback. Synchronous repository/WAL transactions write registered monthly payloads and the narrow `(kind, original_id, month_table)` online locator. This is explicitly a dual-write design, not an exclusive physical-write cutover. Canonical typed payload JSON is LONGTEXT because MySQL JSON rewrites DECIMAL lexemes and would break the canonical payload hash; metadata remains JSON. Large bodies use the existing encrypted object references.

Read route authority is separate from archive verification state. `log-backfill` copies <=500 rows per30-second batch, `log-verify` persists a bounded bidirectional verification cursor, `log-cutover` requires complete verification and no pending legacy receipts, and `rollback` requires intact original sources. A repaired recutover resets rolled_back archive state to prepared; archive verification must still run before deletion. Chat/risk incremental receipts use `log-catchup`; model/cost/audit receipts are drained by observation-backfill/report maintenance. Background workers also drain bounded queues. No unbounded global counter or serving read locks were added.

GetByID, old-ID resolution, trace/recent detail methods, cursor history and Trace metadata route into the active month. Active route corruption or incomplete legacy catchup fails visibly; it never silently falls back to fixed copies. Owner filters remain SQL predicates. Trace/recent selection and payload reads share one readonly repeatable-read snapshot, preventing concurrent rollback from omitting rows. Synchronous paths cap200 records,8MiB and4 registered active months; wider exact traces require bounded range/export.

Body migration acquires catalog ownership before existing source-row mutation and writes updated month payload in the same transaction. Archive save rechecks the current source under the same catalog→source order, preventing a stale snapshot from replacing newer monthly data. Physical body expiry uses the existing verified shared tombstone; hydration returns expired with no plaintext, while immutable source/month references keep their canonical identity. No restore/deletion proof gate was relaxed.

After proven90-day source retirement, online locator rows are removed; archive manifests locate old IDs. Native backup freezes/validates actual monthly schema and captures inline payload dependencies plus encrypted archive/body objects. Restore resets route authority and omits trusted executable triggers. Native allocator floors are captured for all seven monthly-capable native source kinds and also derived from authenticated native/month/archive IDs for older snapshots. Only the empty isolated schema preparation stage applies trusted ALTER AUTO_INCREMENT. Import stays DML-only; verification uses readonly current-engine metadata. The normal cm_restore_* business-service startup prohibition remains intact.

## W2: commit-visible legacy reconciliation

Unreleased migration121 installs exact transactional invocation/cost/audit pending receipts;123 adds chat/risk receipts. Every bounded reconciler unions pending IDs with the forward source cursor, uses at most500 IDs, clears only successfully projected receipts in the same transaction, and never moves its forward watermark backwards. Readiness includes pending work. Initial targets are initialized after hooks exist, covering pre-hook source rows. Normal repository/WAL projection clears its own receipt atomically.

Native executable capture recognizes only the five exact trusted INSERT hooks; changed/foreign triggers remain rejected. Isolated restore installs none. The900k synthetic cost fixture acknowledges only IDs with matching facts, in500-ID batches; actual audit source initial backfill drains processed queue receipts. Added default30-day search capacity scenario; final900k execution remains parent's responsibility and is not claimed here.

## W3: typed real SQL archival

SQL bool and DECIMAL normalization happens once before both metadata and payload. Boolean true/false, every non-NULL cost decimal, throughput decimals and NULL retain their Go model types. Complete invocation error_message, audit message and report fields survive archive metadata. Duplicate summary evidence compares complete report identity/content, refusing deletion proof for a previously truncated or incompatible report.

Tests use the complete migration path and actual history.Backfill, including archive IDs501/502 before the first500 hot rows. They reconcile actual summary facts, run typed Get/Trace, activate all five monthly kinds, capture and restore real SQL plus encrypted MinIO objects, and hydrate all six applicable archive kinds. Costs remain native; their monthly display decimals are verified after explicit restore cutover.

## W4 and discovered streaming regression

Admin and instance pagination guard both loading and predecessor-cursor availability, including state updaters and the request function. Page>1 never sends cursorless OFFSET. The browser regression holds page2, attempts double Next, releases a late409 and checks the visible stale-window error. Existing refreshed-window, older-page, filter/detail, stale-response, export refusal,503 retry and mobile guards remain.

The E4 actual streaming outage test exposed a separate terminal SSE delimiter loss. The shared proxy now returns after the terminal blank delimiter (or compatible EOF), preserving exact LF/CRLF bytes and durable raw response while retaining1MiB/time bounds. Existing one-LF and bare-EOF compatibility tests remain.

## Evidence collected

Remote evidence root: `/root/cm-database-completion-20261118/whole-branch-fixes/evidence/`.

- `w1-red.log`: registered month empty after actual new repository write (RED).
- `w1-all-observation-red.log`: chat/risk/cost scope gaps (RED).
- `w2-red.log`: actual allocated-low/uncommitted, committed-high/catchup, late-low commit omitted for both invocation/cost (RED).
- `w3-red.log`: actual SQL-produced numeric bool and quoted DECIMAL fail typed archive metadata (RED).
- `w4-red-browser.log`: held page2/double Next emitted an extra cursorless page request (RED).
- `stream-frame-red.log`: complete provider SSE loses terminal delimiter (RED).
- `allocator-red.log`: actual highest-ID retirement→native restore yields next=2, archived=2, live=1 (RED).
- `w2-w3-green.log`: initial full-schema W2/W3 GREEN10.604s.
- `whole-native.log`: six archive kinds + five active monthly kinds, decimal/null, beyond-hot500 summaries, real SQL/encrypted objects/typed restore GREEN78.674s before allocator extension.
- `frontend-build.log`,`w4-final-browser.log`: production frontend build and both actual routed browser cases PASS.
- `final-covering-green.log`: actual DSN+compiled CLI repository97.114s, history18.220s, gateway40.833s, maintenance0.015s PASS; no skipped integration cases in selected suite.
- `backup-unit.log`: systembackup0.750s,team0.004s,db0.083s PASS before allocator cache correction.
- `final-native.log`: FAILED, correctly retained. Exposed cached information_schema AUTO_INCREMENT values after ALTER; final case also hit the independently confirmed OOMKilled general SQL fixture.

Latest final native/race/source-hash evidence will be appended after execution, not predeclared.

## Reproduction commands and environment

Source sync (no deployment): `rsync -a --exclude=.git --exclude=node_modules --exclude=dist ./ root@10.130.81.54:/root/cm-database-completion-20261118/whole-branch-fixes/ClawManager/`.

Backend cwd: `/root/cm-database-completion-20261118/whole-branch-fixes/ClawManager/backend`.
Go: `/root/cm-nfs-multislot-20261105/tools/usr/local/go/bin/go`.
Environment: `env -u GOROOT GOTOOLCHAIN=local CGO_ENABLED=0 GOMAXPROCS=2 GOPROXY=off GOSUMDB=off GOMODCACHE=/root/cm-nfs-multislot-20261105/cache/mod GOCACHE=/root/cm-nfs-multislot-20261105/cache/build`.

CLI build: `go build -o /root/cm-database-completion-20261118/whole-branch-fixes/bin/ ./cmd/observation-backfill ./cmd/history-maintenance ./cmd/system-backup-artifact`.

Covering command: `TEST_DATABASE_MYSQL_PORT=33317 CM_OBSERVABILITY_TEST_DSN='root@tcp(127.0.0.1:33317)/mysql?parseTime=true' CM_OBSERVATION_BACKFILL_BIN=/root/cm-database-completion-20261118/whole-branch-fixes/bin/observation-backfill go test ./internal/repository ./internal/historymaintenance ./internal/aigateway ./internal/maintenancecli ./cmd/history-maintenance -run 'TestWholeBranch|TestObservationBackfillCLI|TestDurableInvocationRealMySQL|TestMySQL|TestGatewayExecutedResult|TestGatewayObservation|TestProxyOpenAIStream|TestMaintenanceCLI' -count=1 -v -timeout=15m`.

Native runner: remote `run_native_final.py` loads MinIO credentials from the private0600 fixture file without printing them. It selects TestWholeBranch, schema contract, trigger allowlist/inert restore, monthly frozen catalog, TeamData monthly restore, TeamHistory native bundle, and actual observation proof/expiry pipeline. Environment uses SQL33317, MinIO33319 and Redis DB15 on33318→33320; no shared Redis DB0 flush/ACL mutation. Actual independent verifier executable is the locally built server54 system-backup-artifact.

Frontend cwd: corresponding frontend directory, read-only cached node_modules symlink. PATH includes `/root/cm-slot-release-20261111/tools/bin`; run `npm run build`, then `CM_PLAYWRIGHT_MODULE=/root/cm-migration-ui-fix4/browser-tools/node_modules/playwright CM_CHROME_PATH=/root/cm-uiux08-20261111/browser/root/opt/google/chrome/chrome node scripts/session-refresh.browser.mjs`.

## Current-source final native evidence (completed)

`final-native-green.log`: **exit0, PASS107.369s**, all8 selected tests executed, no skips. Command on54:

```sh
cd /root/cm-database-completion-20261118/whole-branch-fixes
TEST_SYSTEM_BACKUP_VERIFY_EXE=/root/cm-database-completion-20261118/whole-branch-fixes/bin/system-backup-artifact \
TEST_SYSTEM_BACKUP_REDIS_DATABASE=15 TEST_SYSTEM_BACKUP_REDIS_PORT=33318 TEST_SYSTEM_BACKUP_REDIS_TARGET_PORT=33320 \
python3 run_native_green.py
```

The runner uses the documented Go environment, privately loads MinIO credentials, and executes:

```sh
go test ./internal/systembackup -run 'TestWholeBranch|TestSchemaContractMatchesFreshMigrations|TestAuditTriggerCaptureAllowlistAndInertRestore|TestMonthlyCaptureRejectsUnregisteredAndFreezesCatalog|TestTeamDataMonthlyNativeSchemaRestore|TestTeamHistoryNativeBundleRestoresMonthlyObjectsAndImmutableKey|TestObservationNativeProofAndExpiredSnapshot' -count=1 -v -timeout=10m
```

Actual output:

```text
--- PASS: TestAuditTriggerCaptureAllowlistAndInertRestore (11.17s)
--- PASS: TestWholeBranchNativeRestorePreservesRetiredPublicIDFloor (12.74s)
--- PASS: TestMonthlyCaptureRejectsUnregisteredAndFreezesCatalog (0.87s)
--- PASS: TestObservationNativeProofAndExpiredSnapshot (30.41s)
--- PASS: TestSchemaContractMatchesFreshMigrations (6.25s)
--- PASS: TestTeamDataMonthlyNativeSchemaRestore (12.78s)
--- PASS: TestTeamHistoryNativeBundleRestoresMonthlyObjectsAndImmutableKey (14.56s)
--- PASS: TestWholeBranchFullSchemaArchiveMonthlyNativeRestore (18.56s)
ok clawreef/internal/systembackup 107.369s
```

The allocator test primes stale information_schema statistics before trusted ALTER, then reads current SHOW CREATE TABLE metadata, imports/verifies the native snapshot and performs an actual repository Create: live=1, archived=2, new=3. Normal isolated business-service startup remains prohibited. Only the fixture's fresh static day-lock slots are seeded for the one repository-write probe. The actual independent verifier in observation native proof uses its existing read-only credentials; no SET/DDL or privilege changes were added to verification.

`cli-build-final.log`: exit0 for the three CLI binaries. `backup-unit-final.log`: systembackup0.742s,team0.005s,db0.084s,history-maintenance0.017s PASS.

Product/source hash manifest: `/tmp/cm-database-whole-branch-source.sha256`, SHA256 `51403dbbe04019676592ed356e1bb210113ea6bcc0101a2fc019fbf217d5a8e2`. It enumerates every tracked/untracked nonignored backend/frontend source file (Git cached+others inventory), not just a hand-selected subset. Generated after the final product changes. Parent's final freeze may additionally include report/Runtime sources separately.

Actual tested CLI binary SHA256:

```text
ad8cad1043938d450b7bf25f578a18061906c4ecf6565cd240e14b68f730485a observation-backfill
a64d03aef7ff649fef054475e08f10ddee2f3e90ab0c06414f79e0d9a2a59138 history-maintenance
bc0d6f2e3b569ab6cfbb8bc225404e165e533070e2d6be850c6f8ac2486b6aaf system-backup-artifact
```

Root recreated ONLY the owned OOMKilled general fixture with8Gi memory/4GiInnoDB; old private ephemeral test schemas were lost, not application data. New native tests use new random owned schemas. Perf fixtures and all live application resources remained unchanged. Redis DB15 pair was released after native exit0.

## Current review boundary: R1–R3 correction wave remains in progress

The previously recorded eight native and selected race passes apply to the prior candidate. Independent re-review closed original W1–W4, allocator and SSE, but identified three new Important boundary defects. All three have actual full-migration RED in `monthly-r1-r2-r3-red.log`; fixes and expanded deterministic coverage are being completed. Do not interpret earlier candidate hashes or passes as acceptance of the current unverified wave. Updated exact commands/output/hashes will follow after covering checks.

## R1–R3 implementation and current verification candidate

R1 now selects only route metadata plus inline byte lengths first, admits an exact <=8MiB prefix, then fetches each accepted payload inside the same readonly repeatable-read transaction. Canonical LONGTEXT is checked directly against its stored bytes/hash and JSON validity; no decoded/re-encoded copy is allocated. The regression poisons the first excluded row's hash: page1 succeeds, the next page explicitly rejects it, then repaired continuation reaches all20 IDs. Real HTTP NDJSON export also traverses all20 legacy2MiB rows across7 pages. Current first-page allocation is12,672,144 bytes for6,293,745 response payload bytes (pre-fix416,331,904 bytes); the64MiB regression limit was not increased.

R2 `WriteLogPrefix` returns only the ordered IDs actually materialized under the8MiB budget. Invocation/cost reconciliations, audit initial/pending drains, chat/risk pending drains and explicit online backfill advance/acknowledge that exact prefix. The initial audit completion flag also distinguishes byte truncation from exhausted input. Archive-derived summary batches enforce the existing byte budget. A valid prefix before an individually oversized row commits; the oversized row then remains an explicit blocker, with its and later receipts/cursor intact. CLI log-backfill completion now requires an empty continuation batch rather than treating a short byte-limited batch as exhaustion.

R3 source routing takes shared exact `(kind,month_utc)` ownership before its current source read. Under the existing repeatable-read writer transactions, an absent catalog key's gap is protected too, so first registration cannot finish before a source transaction that chose the fixed route commits. Present catalog ownership remains compatible among normal writers. Existing-source mutations retain catalog→source lock order; serving readers still use snapshots without locks. Session isolation is checked fail-closed. There is no global kind allocator/counter or serving read lock.

All five kinds × both registration orderings have actual full-schema PASS53.67s in `monthly-r1-r2-r3-green-v4.log`. The fixture has performance_schema disabled and INNODB_TRX caches state, so the deterministic observer also reads the current `SHOW ENGINE INNODB STATUS` TRANSACTIONS lock wait, restricted to the random owned database and catalog index. The held source executes the production projection/receipt hook, higher ID is committed independently, and the concurrent actual Backfill→Verify→Cutover must preserve IDs1/2 with zero outstanding receipts.

Intermediate test failures are retained and not counted as complete passes: v2 used disabled performance_schema; v3's stale lock probe was stopped after establishing the fixture mismatch; v3/v4 audit fixture initially used the bounded message column and then omitted required traffic_class/severity. The final fixture uses valid legacy `details LONGTEXT` and supplies all required source columns. Model's original500×20KiB error_message TEXT RED remains valid and both queued/pre-hook variants passed; no product requirement was relaxed.

Current source manifest `/tmp/cm-database-whole-branch-source.sha256`, remote `evidence/r123-source.sha256`, SHA256 `e673b6d9e65063f178cdc3db35e190027009959bcafda123fbacd54b2df43d53`. Local Git inventory covers every tracked/untracked nonignored backend/frontend source file. Remote `sha256sum -c --quiet` exited0. No schema definition changed in this wave. Current covering/native/race results will be appended; earlier whole-candidate passes are not substituted.

All3 CLI builds exited0 on54 with the declared Go environment. Current binaries:
- history-maintenance `4aa6c3638268e52ab064a2dfbe60005627a331e60d0a01cbd119b859f7952889`
- observation-backfill `a6084b374160042b7cedb35093c68b4fc80ad9844fbcdedf6dde6c47fd59fd4e`
- system-backup-artifact `4c5bbf52198ea18bd0fb5a82ca22e9aa58e4b38b2073fd672c87d1273d957024`

Final covering command uses the same environment previously recorded plus TEST_DATABASE_MYSQL_PORT=33317, actual CM_OBSERVABILITY_TEST_DSN on33317, and current observation-backfill binary:
`go test -p=1 ./internal/repository ./internal/historymaintenance ./internal/aigateway ./internal/handlers ./internal/maintenancecli ./cmd/history-maintenance -run 'TestWholeBranch|TestObservationBackfillCLI|TestDurableInvocationRealMySQL|TestMySQL|TestGatewayExecutedResult|TestGatewayObservation|TestProxyOpenAIStream|TestMaintenanceCLI|TestHistoryHandler|TestHistoryBody' -count=1 -v -timeout=15m`
Log: `evidence/r123-final-covering.log` (running at this report boundary).

### Final R1–R3 covering result

`r123-final-covering.log` completed **exit0** on the current manifest. All selected integration fixtures executed (no skipped cases). The actual new model500×20KiB queued/pre-hook variants, audit initial/pending2KiB/40KiB LONGTEXT bodies, chat backfill/pending, individual9MiB blocker, ten first-registration orderings, excluded-row poison/read-memory check and actual HTTP20-row/7-page export passed. Existing typed archive, late model/cost commits, five-kind monthly writes, active corruption/rollback, post-cutover body migration/expiry, max4months, actual CLI and actual gateway dual SQL/object outages with stream/nonstream plus admission guards also passed. `cmd/history-maintenance` reports [no tests to run], counted only as compilation.

The eight native compatibility cases are now running in `evidence/r123-final-native.log`; race remains pending. No source edits after the recorded manifest.

Covering package durations: repository157.395s; historymaintenance7.502s; aigateway15.569s; handlers9.261s; maintenancecli0.015s. Command history-maintenance0.020s is compilation-only. Current registration10-case group53.26s; actual HTTP export9.22s. All outputs are from the e673…d53 manifest, with no intervening source edits.

Pending race command (queued after native finishes, SQL fixtures remain sequential): same Go environment except CGO_ENABLED=1, actual TEST_DATABASE_MYSQL_PORT33317 and CM_OBSERVABILITY_TEST_DSN33317:
`go test -race -p=1 ./internal/repository ./internal/historymaintenance ./internal/aigateway ./internal/handlers -run 'TestWholeBranch|TestMySQLRollback|TestMySQLActiveMonthly|TestMySQLStaleArchive|TestGatewayExecutedResult|TestGatewayObservation|TestProxyOpenAIStream' -count=1 -v -timeout=15m`
Output target `evidence/r123-final-race.log`; no pass is asserted until completion.

### Final R1–R3 native compatibility result

`evidence/r123-final-native.log`: **exit0, PASS107.415s**, all8 actual tests, no skips, same manifest `e673b6d9e65063f178cdc3db35e190027009959bcafda123fbacd54b2df43d53`.

Exact command from the remote sandbox parent:
```sh
TEST_SYSTEM_BACKUP_VERIFY_EXE=/root/cm-database-completion-20261118/whole-branch-fixes/bin/system-backup-artifact \
TEST_SYSTEM_BACKUP_REDIS_DATABASE=15 TEST_SYSTEM_BACKUP_REDIS_PORT=33318 TEST_SYSTEM_BACKUP_REDIS_TARGET_PORT=33320 \
python3 run_native_r123.py
```
The runner is the prior documented `run_native_green.py`, with only the output log filename changed; its exact8-test Go selector/environment/private MinIO credential load are unchanged. Actual output:
```text
--- PASS: TestAuditTriggerCaptureAllowlistAndInertRestore (11.18s)
--- PASS: TestWholeBranchNativeRestorePreservesRetiredPublicIDFloor (12.99s)
--- PASS: TestMonthlyCaptureRejectsUnregisteredAndFreezesCatalog (0.88s)
--- PASS: TestObservationNativeProofAndExpiredSnapshot (30.11s)
--- PASS: TestSchemaContractMatchesFreshMigrations (6.31s)
--- PASS: TestTeamDataMonthlyNativeSchemaRestore (12.79s)
--- PASS: TestTeamHistoryNativeBundleRestoresMonthlyObjectsAndImmutableKey (14.78s)
--- PASS: TestWholeBranchFullSchemaArchiveMonthlyNativeRestore (18.35s)
ok clawreef/internal/systembackup 107.415s
```
The last case exercised actual complete migrations, six archive kinds/five active monthly kinds, bool true/false, every cost decimal/null, archive IDs beyond hot500, summary facts, monthly Get/Trace, SQL plus encrypted objects, typed isolated restore and inert hooks/routes. DB15 pair33318→33320 released to parent after completion. General SQL33317 remains reserved only for the ongoing same-source focused race; no further product edits are planned or made.

### Final R1–R3 race result and release

`evidence/r123-final-race.log`: **exit0**, current same-source test command recorded above. Actual package outputs:
```text
ok clawreef/internal/repository 163.653s
ok clawreef/internal/historymaintenance 3.978s
ok clawreef/internal/aigateway 16.985s
ok clawreef/internal/handlers 22.896s
```
Actual race counts parsed from PASS lines, treating parent subtest containers as containers rather than additional leaf cases:

| Package | PASS entries | Executed leaf cases |
|---|---:|---:|
| repository |28|25|
| historymaintenance |4|4|
| aigateway |20|17|
| handlers |1|1|
| Total race |53|47|

All current race output has **0 skipped cases,0 failed cases,0 data-race warnings**. Current ordinary covering has60 leaf cases and native has8 leaf cases, likewise0 skips/failures. These runs overlap and their counts are not summed into a claim of115 distinct scenarios. Machine-readable output and each package duration/count are stored in remote `evidence/r123-final-summary.json` alongside the three raw logs.

After all executions, local complete source inventory was recomputed and compared byte-for-byte to `/tmp/cm-database-whole-branch-source.sha256` (exit0); remote `sha256sum -c --quiet evidence/r123-source.sha256` also exited0. Manifest remains **e673b6d9e65063f178cdc3db35e190027009959bcafda123fbacd54b2df43d53**. `git diff --cached --check` exited0 after parent staged the candidate. No commits or source edits were made by this agent after its verification candidate; the staging operation did not change source bytes.

General SQL33317 and native RedisDB15 pair33318→33320 are now both explicitly released to parent. No test processes remain. Current implementation/test task is complete and reviewable. Parent's frozen all-package/performance/browser acceptance and final independent-review conclusion remain parent-owned; none is claimed by this report.
