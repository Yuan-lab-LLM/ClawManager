# Independent R1–R3 re-review

Review date: 2026-11-18. Scope: the correction wave following `/tmp/cm-database-whole-branch-rereview.md`, against the already approved database remediation specification and completion plan. This is a focused continuation of that whole-branch review; previously closed W1–W4, allocator, SSE, query Q1–Q4, persistence and isolated Runtime findings were not reopened without evidence.

## Current assessment

**R1–R3: closed. Focused independent re-review: PASS.** Source inspection and the completed same-source covering/native/race evidence support closure of all three Important findings. No new Critical or Important issue is confirmed in the reviewed changes. No cosmetic change is requested. The whole-branch code-review gate is clear; root's frozen full-suite/capacity/report acceptance remains separate and is not claimed complete.

The implementation addresses the shared causes: one metadata-first read path, one ordered prefix writer used by every bulk consumer, and native transaction ownership of the exact catalog identity. It retains the 8MiB budget, native IDs, financial ledger, owner scope and explicit incomplete-route errors.

## R1: bounded inline monthly reads

`backend/internal/historymaintenance/reader.go:114` selects metadata, the inline-presence flag and OCTET_LENGTH rather than inline payload bytes. The loop at `:154` admits only a row/byte-bounded prefix and records HasMore without decoding the excluded row. Accepted payloads are fetched at `:183` inside the same read-only repeatable-read transaction; stored length, remaining budget, SHA256 and JSON validity are checked before use. `log_routing.go:570` verifies existing canonical bytes directly, avoiding an unnecessary decoded/re-encoded body copy. NextID advances only after a successfully read record, so a byte-short page does not lose its continuation.

Reviewed tests: `repository/monthly_bounds_mysql_test.go:15` establishes a real full-schema active monthly route with twenty valid 2MiB legacy LONGTEXT bodies. The first excluded row has a deliberately wrong hash: the first page must succeed, the next must reject it, and after repair complete cursor traversal must contain all20 IDs exactly once. The unchanged 64MiB allocation ceiling guards against the prior roughly416MiB total allocation. `handlers/history_monthly_export_mysql_test.go:25` invokes the real Gin NDJSON Export handler against MySQL, verifies sequential IDs, <=8MiB payload bytes per page, continuation headers, and exactly20 rows across7 pages. Authentication is the declared test middleware supplying owner1; this is real handler execution, not a production authentication test.

## R2: progress and exact acknowledgement of a byte prefix

`historymaintenance/log_routing.go:59` requires ordered positive IDs, caps selected rows at500, writes the scanner's <=8MiB prefix, and returns only IDs through the final processed record when truncated. Single-record `WriteLogBatch` retains fail-closed all-or-error semantics. The source scanner permits a valid prefix before a later oversized row; the next call still fails explicitly on that row rather than skipping it.

All production callers were searched and inspected:

- `query_summary.go:119` and `query_cost_summary.go:131` select/materialize only returned IDs, then update their monotonic watermark and delete exactly those receipts in the same transaction.
- `observability_audit_summary.go:248` rebuilds initial backfill traces/end cursor from that prefix and cannot mark a byte-short batch complete. The pending drain at `:373` likewise restricts materialization and deletion to the returned IDs.
- `log_routing.go:230` returns the exact backfill prefix/cursor; `:674` clears only that prefix for chat/risk pending drains.
- `cmd/history-maintenance/main.go:126` marks log-backfill complete only on an empty batch, avoiding false completion when bytes stop a nonempty batch before its row limit.
- Repository/WAL/body-migration single-record calls retain the shared transaction and are not incorrectly treated as bulk partial success. Archive-derived summary consumers separately admit a byte prefix before hydration/proof updates.

Reviewed regressions cover the actual500-row scheduled invocation reconciler with valid20KiB TEXT error_message, both trigger-populated queues and pre-hook initial rows; variable2KiB/40KiB audit details/chat content through initial/pending/backfill callers; exact facts, preserved errors/messages, month rows, cursor and queued IDs; idempotent completion; and a9MiB individual legacy row retaining itself and later receipts after a preceding valid row commits. Cost/risk use the same writer and their actual source/projection paths are also covered by the registration matrix. No invalid20KiB risk VARCHAR example is used as evidence.

## R3: first registration and acknowledged source commit

`log_routing.go:74` discovers each present source row's month and rejects non-repeatable-read writer sessions. At `:109`, every touched month obtains `FOR SHARE` through `uk_history_kind_month` with the exact `(kind,month_utc)` equality, including absent keys. All these calls are inside the existing source/reconciliation transaction. The source/current-payload read and receipt acknowledgement follow that ownership.

Consequently a source-first transaction choosing the legacy route retains a shared missing-key gap until commit; `monthly.go:179` cannot insert the first catalog registration and complete its later backfill/verification/cutover across that decision. If registration wins first, the writer's current locking catalog read sees it and writes the month copy before acknowledgement. Existing registrations use compatible shared ownership between ordinary writers, sorted month acquisition, and current source reads after catalog ownership. Readers remain snapshot readers. No new global allocator or serving lock is introduced.

`repository/whole_branch_review_mysql_test.go:564` exercises all five kinds with both source-first and already-registered orderings. It holds the lower-ID source transaction after the production projection/receipt hook, commits the higher ID independently, concurrently invokes actual Backfill→Verify→Cutover, observes an engine lock wait in the owned schema, releases the source, then requires both stable IDs and zero remaining receipts. Risk uses its actual shared writer/receipt pair. The already-registered case can block on its existing monthly table metadata lock, which the test explicitly distinguishes; the missing-key case has the unique-index insert-intention observer.

## Evidence identity and limits

Current source manifest: `/tmp/cm-database-whole-branch-source.sha256`; SHA256 `e673b6d9e65063f178cdc3db35e190027009959bcafda123fbacd54b2df43d53`. Independent local `shasum -a 256 -c` completed with exit0; output `/tmp/cm-r123-review-source-check.log`. This is read-only source verification, not a local test/build. Implementer reports the identical remote `evidence/r123-source.sha256` verifies with exit0.

Current remote log directory: `/root/cm-database-completion-20261118/whole-branch-fixes/evidence/`. Completed covering/native/race results are recorded below. Earlier candidate's native8 PASS and intermediate v4 subtest passes are not substitutes for these current complete runs. Invalid intermediate fixtures and failed aggregate runs remain failures in the implementer report.

This reviewer made no source edits, builds, executable tests, commits, deployments or application mutations. Root's final frozen full-suite,900k capacity acceptance and HTML report remain separate gates; this focused review does not predeclare their success.

## Completed same-source verification

I directly read the remote raw covering/native/race outputs and `r123-final-summary.json`. Implementer reports each complete command exit0 and both local inventory comparison and remote per-file manifest verification exit0. I independently repeated the read-only local manifest check at the end: exit0, still the exact e673b6d9…d53 candidate above.

| Completed log | Executed leaf cases | Result |
|---|---:|---|
| `r123-final-covering.log` | 60 | PASS; repository157.395s, history7.502s, gateway15.569s, handlers9.261s, maintenance0.015s |
| `r123-final-native.log` | 8 | PASS107.415s; all eight native SQL/object/allocator/schema/Team compatibility cases |
| `r123-final-race.log` | 47 | PASS; repository163.653s, history3.978s, gateway16.985s, handlers22.896s |

All three complete logs have zero SKIP, zero FAIL and zero data-race reports. `cmd/history-maintenance` has `[no tests to run]` and is counted only as compilation, never as an executed leaf case.

The final ordinary R1 run allocated12,672,016 bytes for its bounded first page and traversed all20 records. The ten R3 registration cases passed in53.26s ordinary and54.18s under race. Actual HTTP export reported20 complete2MiB records across7 pages in both ordinary and race runs (race case21.72s). Native eight includes the complete6-kind archive/5-kind monthly typed restore18.35s and retired-ID allocator12.99s. These are observed completed current-source results, not projected passes or reused older-candidate evidence.

**Assessment:** ready to proceed to root's final frozen branch acceptance, with no further code correction requested by this review. This report supersedes the R1–R3 blocking verdict in the previous re-review; previously closed W1–W4 and other independent gates remain closed. It does not authorize deployment or substitute for the remaining full/capacity acceptance tasks.
