# Legacy gateway activity SQL fixture correction — 2026-11-18

DONE: the original8 target cases were reproduced failing on54, then passed with and without `-race` after adding only the missing real migration109 to the test fixture. Only local `ClawManager/backend/internal/handlers/gateway_activity_admission_test.go` was edited; no product source, lease/admission safety behavior, frozen final tree, final source manifest, or deployment changed. No commit was made. All Go/gofmt execution occurred on54.

## Root cause and baseline check

The fixture manually applied only `096_add_instance_auto_stop.sql`. Actual `InstanceAutoStopRepository.GetActivity` delegates to `readActivity` in `backend/internal/repository/instance_auto_stop.go`, whose active-request subquery already reads `q.lease_expires_at`. Real migration109 adds:

```sql
ALTER TABLE instance_model_activity_requests
    ADD COLUMN lease_expires_at DATETIME(6) NULL,
    ADD COLUMN last_heartbeat_at DATETIME(6) NULL,
    ADD COLUMN completion_reason VARCHAR(32) NOT NULL DEFAULT '',
    ADD INDEX idx_model_activity_lease (finished_at, lease_expires_at, instance_id);
```

The pre-change test, product repository, and migration109 are byte-identical to baseline `acf8665a`; `git diff acf8665a --` for these three files was empty before editing. Baseline/current pre-change SHA-256:

| File | SHA-256 |
|---|---|
| `handlers/gateway_activity_admission_test.go` | `e2357932f56785095bfda013a1de6e5a087a418e43b280e3e30257f61ef8fe12` |
| `repository/instance_auto_stop.go` | `412ac95edaee7e080131f5446392b72b53517b1b92c25a359e892f54cdc9f761` |
| `db/migrations/109_add_model_activity_leases.sql` | `8caa9a438d58e2a842ad582fb994acc04ed125415ec2b50ff46c996f5d68e167` |

This is an existing incomplete test schema exposed by enabling the legacy SQL scope, rather than a changed admission or lease safety contract. In every independent RED case, the HTTP409 / untouched limiter check passed and the subsequent unchanged activity assertion failed with MySQL1054, unknown `q.lease_expires_at`.

## Minimal correction and preserved assertions

The existing migration execution block now loops over096 followed by109, reusing the existing statement execution logic. No replacement schema or production fallback was added. The diff is10 added /8 removed lines from the extra loop and indentation.

All code beginning at `activity := repository.NewInstanceAutoStopRepository(s)` through the end of the test is byte-identical to the original fixture; this was checked explicitly. Thus all8 original combinations remain:

- `chat-stopped`, `chat-stale`
- `responses-stopped`, `responses-stale`
- `anthropic-stopped`, `anthropic-stale`
- `images-stopped`, `images-stale`

Every case still requires HTTP409, the limiter's request ID to remain empty before policy/provider work, `ActiveRequests == 0`, and `LastGatewayActivityAt == nil`. The existing other protocol-admission test is unchanged.

Current local and remote test-file SHA-256: `c33de159b453f1c05de10aab2b3c385ff3195ff593af96431dca3f8ac284bf39`. Local `git diff --check` passes.

## Isolated execution and raw evidence

The original v3 broad failure remains in root-owned `final/evidence/v3-legacy-sql-regression.jsonl`. Independent RED/GREEN/race ran only the exact target test in `/root/cm-database-completion-20261118/legacy-activity-fixture/ClawManager/backend`, copied from the frozen final backend and then given only this one test correction. The private legacy MySQL33347 fixture was used; each test invocation creates/drops only its own timestamp-named `cm_idle_http_*` database. No entire package or capacity suite was run by this task.

Common command, executed only via SSH on54:

```sh
env -u GOROOT GOTOOLCHAIN=local CGO_ENABLED=0 GOMAXPROCS=2 \
  GOPROXY=off GOSUMDB=off \
  GOPATH=/root/cm-nfs-multislot-20261105/cache \
  GOMODCACHE=/root/cm-nfs-multislot-20261105/cache/mod \
  GOCACHE=/root/cm-nfs-multislot-20261105/cache/build \
  TEST_IDLE_MYSQL_PORT=33347 \
  /root/cm-nfs-multislot-20261105/tools/usr/local/go/bin/go test \
  ./internal/handlers \
  -run '^TestGatewayActivityPublicProtocolsRejectStoppedAndStaleMySQL$' \
  -count=1 -timeout=3m -json
```

Race uses the same command with `CGO_ENABLED=1` and `go test -race`; Go's race instrumentation requires cgo. The test source is unchanged between ordinary GREEN and race.

| Attempt | Exit | Actual target leaves | Package elapsed | Raw log SHA-256 |
|---|---|---|---|---|
| Original fixture RED | 1 | 8 FAIL with1054; HTTP fence assertion passed first | 0.827s | `70184867d0dd6e4c8899911a1fa855738637fba3489c013b5bd459c13d88091f` |
| Corrected fixture GREEN | 0 | 8 PASS, no skips | 1.048s | `b248f007db5b17299d9e4a93e531235c08d06fe553ab742fac6cd40e10947daf` |
| Corrected fixture race | 0 | 8 PASS, no skips, no race warning | 2.177s | `89a7b5b33b1cff98f8aa9a1277e8629bfa6e48de0d6adf5c31b24259691f34f5` |

Remote evidence directory: `/root/cm-database-completion-20261118/legacy-activity-fixture/evidence/`.

- `activity-{red,green,race}.jsonl` and matching `.exit` retain complete raw output and exit status.
- `original-gateway_activity_admission_test.go.txt` retains the actual original failing test.
- `red-source-hashes.txt`, `green-source-hashes.txt` identify test, repository, and migration sources.
- `green-source.sha256` covers1878 backend `.go`/`.sql`/module files. Checks before race and after race passed; its SHA-256 is `c834c2af1f85e6e892552726cebe1b87138c6dddc4ad2264f714ccffcdb08abb`.
- `verification-summary.json` validates every exact leaf identity/status,1054 RED reason, no race warning, exit status, original assertion byte identity, and frozen-versus-sandbox source comparison. Its SHA-256 is `6c704ddff2a889cfddd86234542f7f1276de1c482236c46ababbbba4ede77fa9`.

The1878-file comparison with frozen `final/ClawManager/backend` confirmed that the only source difference is `internal/handlers/gateway_activity_admission_test.go`. Product source in the sandbox and frozen final tree remains identical. Evidence is also copied to `/tmp/cm-database-legacy-activity-fixture-evidence/` locally. This targeted development evidence must be followed by root's combined v4 freeze and complete final run.
