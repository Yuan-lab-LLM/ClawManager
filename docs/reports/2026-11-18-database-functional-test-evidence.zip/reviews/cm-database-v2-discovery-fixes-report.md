# Frozen v1 discovery corrections

Status: these two discovery corrections are complete; all ordinary focused and same-source race checks PASS. Root has separately requested the newly discovered TeamData fixture correction, tracked in a subsequent report. Root owns independent review, v2 freeze and full acceptance. No frozen final directory, application, Runtime source, production data or shared Redis ACL was changed.

## Scope and exact changes

Four local files, patch `/tmp/cm-database-v2-discovery-fixes.patch`:

1. `backend/internal/repository/cost_record_reporting_mysql_test.go`: only the affected invocation projection test switches from handwritten source DDL to existing `auditFullFixture`/full `db.Initialize` migrations. Real `ReconcileObservationSummaries` must project exactly1 initial row and24 later rows. Existing metadata/body omission, full model75-token aggregation and exact request/response detail assertions remain. Its now-unused partial-migration seed helper and import are deleted. No production repository fallback or error gate changes.
2. `backend/internal/services/managed_team_redis_capacity.go`: key-prefix, internal-namespace and key-length authorization refusals return a dedicated private sentinel. Adds one fixed CM-only, zero-key Lua error reply.
3. `backend/internal/services/managed_team_redis.go`: after the unchanged client command/script guard, that sentinel becomes the fixed backend `EVAL ... 0` error command. It passes through the existing single backend writer, so Redis orders NOPERM between earlier/later responses. The existing reader remains the only client writer. Context/malformed-command guards and transport failures keep their existing session-close behavior. No ACL or Runtime/client Lua allowlist additions.
4. `backend/internal/services/managed_team_redis_integration_test.go`: actual Redis7 pipeline exercises8 rounds/64 commands: accepted SET, denied internal HGET, accepted GET, denied cross-Team GET, denied mixed-prefix multi-key DEL, retained GET, denied internal HGETALL, accepted PING. It requires exact fixed NOPERM replies and preserves real capacity metadata. Direct client submission of the CM-only error script must still close under the original guard. The BLOCK fixture uses supported `inbox:blocking` instead of obsolete generic `blocking`, retaining actual consumer BLOCK/producer XADD/wakeup assertions.

The original two Runtime Lua constants, guard allowlist and ACL provisioning list are unchanged. The independent Runtime source was copied read-only from the already-frozen source into the independent sandbox for the actual emitted-Lua contract test; no Runtime edits occurred.

## Related-fixture audit

Searched all backend tests that construct the invocation repository and call `GetByID`. The only same-root omission was the corrected test. `observability_audit_summary_mysql_test.go` and `whole_branch_review_mysql_test.go` use full migrations. The durable invocation fixture in `observability_mysql_test.go` explicitly installs114 (locator/catalog) plus its later dependencies. `systembackup/history_allocator_mysql_test.go` and `systembackup/whole_branch_history_mysql_test.go` use full migration/native restore contracts. Other bare reporting fixtures exercise aggregate queries, not the new detail lookup. No broad fixture or product fallback edits were made.

## Isolated execution and exact commands

Remote root: `/root/cm-database-completion-20261118/fixture-v2-fix`; backend cwd `ClawManager/backend`; all logs under `evidence/`. The frozen `/root/cm-database-completion-20261118/final` source was never modified.

Go executable `/root/cm-nfs-multislot-20261105/tools/usr/local/go/bin/go` with:
`env -u GOROOT GOTOOLCHAIN=local CGO_ENABLED=0 GOMAXPROCS=2 GOPROXY=off GOSUMDB=off GOMODCACHE=/root/cm-nfs-multislot-20261105/cache/mod GOCACHE=/root/cm-nfs-multislot-20261105/cache/build`

SQL tests: `TEST_DATABASE_MYSQL_PORT=33327`, only random owned schemas after validating `cm_database_test_marker`. Parent explicitly released33327 after stopping v1 perf clients. Real Managed Redis: `TEST_MANAGED_REDIS_DISPOSABLE=1 TEST_MANAGED_REDIS_PORT=33338`, the dedicated ACL fixture explicitly released by parent after v1 test cleanup. Shared33318 ACL was not touched. For the emitted Runtime Lua contract, PATH prepends `/root/cm-slot-release-20261111/tools/bin` for remote Node.

Commands and executed evidence:

- `go test ./internal/repository -run '^TestSessionReportingInvocationProjectionOmitsBodies$' -count=1 -v -timeout=2m`: `session-projection-red.log` **exit1/0.257s**, exact1146 missing `history_log_locations`. After full-schema correction, `session-projection-green.log` **exit0/5.115s**.
- `go test ./internal/repository -run 'TestCostReporting|TestSessionReportingInvocationProjectionOmitsBodies|TestAuditErrorPreviewKeepsCompleteStoredDetail|TestWholeBranchMonthlyServingCutoverRollbackAndLateLegacy|TestWholeBranchActiveMonthBodyMigrationAndExpiry' -count=1 -v -timeout=3m`: `session-projection-covering.log` **exit0/21.388s**,11 executed leaf cases/no skips. This is after the unused helper removal.
- `go test ./internal/services -run 'TestManagedRedisReal7/(pipeline_errors_same_team_and_DB|BLOCK_and_wakeup)$' -count=1 -v -timeout=2m`: `managed-redis-red.log` **exit1/0.051s**, both original failures reproduced (lost SET reply EOF, obsolete generic XGROUP key EOF).
- `go test ./internal/services -run 'TestManagedRedisReal7/(policy_errors_keep_ordered_pipeline|BLOCK_and_wakeup|guard_EVAL)$' -count=1 -v -timeout=2m`: `managed-redis-policy-red.log` **exit1/0.059s**, new64-command pipeline loses first SET reply to EOF; corrected inbox BLOCK case already passes without product changes.
- First product follow-on, `managed-redis-green.log`, is deliberately retained as **FAIL**: the new assertion initially expected the Go error text to start directly with NOPERM, while `readRedisReply` wraps RESP errors with `errRedisServerReply`. The actual reply was already fixed NOPERM. The corrected assertion now requires the exact full wrapped fixed error, rather than accepting arbitrary errors. This failure is not counted as a pass.
- `go test ./internal/services -run '^TestManagedRedis' -count=1 -v -timeout=3m`: `managed-redis-final-green.log` **exit0/11.418s**, all selected real Redis/authorization/ACL/revocation/parser/script-contract tests passed. Exact leaf count below after final parsing.
- Final command, same env with `CGO_ENABLED=1` and both fixture variables: `go test -race -p=1 ./internal/repository ./internal/services -run '^TestManagedRedis|^TestSessionReportingInvocationProjectionOmitsBodies$' -count=1 -v -timeout=4m`, log `v2-discovery-race.log`, exit0. Repository6.263s/1 leaf and services12.778s/46 leaves;0SKIP/FAIL/race warnings.

## Source provenance

Four-file subset manifest `/tmp/cm-database-v2-discovery-source.sha256`, remote `evidence/source.sha256`, SHA256 `237e71230ea8e7d11902192c0ab42d0de39471925fe32ebe3809b1e4d94bf9b0`. This is explicitly a changed-file manifest, not the parent-owned future complete v2 freeze inventory. Remote per-file SHA check exited0. Individual final hashes:

```text
84491d574d81c96aaf96244363a25dbab9c4823475504ea08a87c7cbcbcd3f53  backend/internal/repository/cost_record_reporting_mysql_test.go
a0ccf935e217b257eb63096b2657bfe4d2beab9327fcc8e7791fa86c5fe3aaf8  backend/internal/services/managed_team_redis.go
1c4966610776667d422297c968c934e59b47d40a4d11b2bf181d0f5df43e5fcd  backend/internal/services/managed_team_redis_capacity.go
c6d0eac282e523939ffe0f9527afa1a1795747e3cfabc24d4cfa088d8a950764  backend/internal/services/managed_team_redis_integration_test.go
```

No source modifications are planned during final race or review. Root's v1 failures remain archived and v2 full rerun is still required; this focused work does not substitute for it.

## Final result

Runner **exit0**. `v2-discovery-race.log`: repository6.263s/1 leaf case and services12.778s/46 leaf cases. Both0SKIP/0FAIL/0race warnings. Ordinary source-projection covering21.388s/11 leaf cases and ManagedRedis11.418s/46 leaf cases also0SKIP/FAIL. Parent/subtest PASS entries are12,51 and52 respectively; leaf counts exclude parent containers. Runs overlap and are not summed as independent scenarios. Remote `evidence/summary.json` records package durations/counts and manifest hash.

Post-run local4-file SHA checks and remote per-file checks all passed, subset manifest remains237e71230ea8e7d11902192c0ab42d0de39471925fe32ebe3809b1e4d94bf9b0; `git diff --check` exit0. Reviewer directly read final logs and reported no confirmed Critical/Important finding, pending their final write-up.33327 and33338 released to root; no focused test processes remain. Frozen v1 source stayed untouched. No commits or deployments by this agent.
