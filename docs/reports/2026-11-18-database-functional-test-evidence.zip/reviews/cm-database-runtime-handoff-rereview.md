# Runtime final handoff re-review — 2026-11-18

## Verdict

**Runtime specification review: PASS. Runtime code-quality review: PASS. Ready for the Runtime source task gate: Yes.**

The Important accepted/queued Hermes handoff loss reported in `/tmp/cm-database-runtime-cas-review.md` is closed. No new Critical or Important finding was identified in this review. This is approval of the reviewed Runtime source, not an assertion that the enclosing CM task's final frozen integration suite has completed or that an image has been deployed.

## Scope and source identity

Read-only review of `/Users/mowen/code/src/github.com/iamlovingit/cm-github/.worktrees/AgentsRuntime-database`, the complete supplied change inventory and implementation diff in `/tmp/cm-runtime-handoff-final-review.patch`, the prior CAS review, the Fourth-review remediation section in `/tmp/cm-database-runtime-delivery-report.md`, production callers and the relevant regression sources. Used the requesting-code-review reviewer checklist and ponytail's actual-caller/minimal-change principle.

Local activities were source/document reading, Git inspection and hashing. No local tests, builds, source changes, commits, deployment or Runtime upgrade. Existing executable evidence was read on `root@10.130.81.54`; no suite was rerun. The ordinary sibling `/Users/mowen/code/src/github.com/iamlovingit/AgentsRuntime` reports an empty Git status.

Local and server54 `/root/cm-database-completion-20261118/runtime/AgentsRuntime` hashes match:

| File | SHA-256 |
|---|---|
| `plugins/hermes-redis-team/adapter.py` | `b93ea3d17143188d43e7f66e6ee7a245925c4dffe71f07b0a5f381998487038b` |
| `plugins/hermes-redis-team/test_context_handoff.py` | `c019b06554b7297e968be08973b7391e4d8515327856b270f187587b477f7021` |
| `plugins/hermes-redis-team/context_handoff_process_test.py` | `a24d8bdb1f6cb3527d01d3d8c33144d5f3b76a6c4f8252fbeecbdbabf9e4e1f2` |
| `plugins/openclaw-redis-team/dist/index.js` | `5a64fa3578cd26939564639e24fdb46d1be13a6f4e0cbeef45936251637a7ba3` |
| `opencode/team/bridge.mjs` | `a67acaa5ba8247fb0c422820a39722cb19a00d0cacb384650a4355713e0fcac5` |
| `opencode/team/build-protocol.mjs` | `9e37f13efc82d9da8f7a14f37c1e91da063ca5fd4caf1542af3d213441308952` |

## Closed finding and serving-path reasoning

### Journal is now the authoritative queued handoff

Hermes `adapter.py:4780-4798` records the full text, marker, original active message ID, root/assignment identity, revision and generation in `contextHandoff` before attempting the auxiliary file. The context capacity checks precede this acceptance, including the under-flock journal count at `2301-2307`. The journal update uses the already allocated two-bank slot. A failed queue write or a crash after the handoff commit no longer leaves only an accepted flag with no recoverable action.

`_load_context_notices` at `548` calls `recover_context` at `2323`. Recovery refreshes existing mirrors and rotates through a bounded journal page, rebuilding entries from durable `contextHandoff` plus current `contextDelivery`. The mirror can be absent entirely. This function is used by the production flusher, the acceptance path and the prepared-request hook; it is not a helper disconnected from serving traffic.

The actual consumer at `4404-4416` recognizes accepted serial handoffs, invokes the real flusher, and checks transport acceptance again after it. `_presence_loop` at `4184` independently calls that same flusher, so recovery does not depend on receiving a second copy of an already ACKed inbox item. Legacy unbound accepted handoffs remain retained at `4407-4409` instead of being ACKed or rebound.

### Original binding and atomic ownership remain intact

`_flush_context_notices` at `4802-4848` restores durable entries, only considers queued entries for steering, and checks original active message ID, root/assignment, revision, generation and lifecycle before submission (`4820`). A replacement execution cannot inherit the old notice. Scope/lifecycle mismatch can close only a still-queued observation; `context(..., "ignored")` refuses to override an already submitting or otherwise resolved owner (`2296-2297`).

Serial dispatch must win the flock-protected `admitted` to `started` comparison at `2271-2278`, and the real consumer checks that result at `4448` before control/native dispatch. Context submission must win its own comparison at `2293-2295`. An accepted queued context can claim only when its durable context has `serialHandoff`; a delayed queued observer that lost to serial execution cannot claim after that serial execution completes. No transient admission snapshot grants execution.

An explicit `steer(False)` returns the same serial handoff to its context queue (`4832`), preserving accepted ownership rather than reopening serial admission. It may call the explicitly declining steer API again, but does not repeat an accepted native submission or create another serial/model turn. The tests correctly distinguish that case from unknown acceptance.

### Ambiguity stays protected; positive native evidence can resolve it

The submitting commit precedes `agent.steer`. Process death before the side effect but after that commit is intentionally retained as ambiguous, as is death after the side effect but before its receipt. Neither missing auxiliary state nor restart authorizes replay. `_state(..., "accepted")` at `2261-2266` refuses transport finalization of submitting/unconfirmed handoffs, and the consumer's `started` branch returns without dispatch or XACK.

`_record_context_request` at `558-572` recovers entries from the journal and recognizes the exact recorded marker in an actual prepared request, including submitting/unconfirmed entries. It records `request_included` durably before writing the mirror. This supplies a positive recovery route without another steer. It does not infer non-execution from absent evidence.

The acknowledged queued handoff and native execution receipt remain distinct facts: transport can accept a fully recoverable queued notice before native injection. Such work remains in the durable journal and is serviced by the presence flusher. Uncertain submission encountered during transport finalization remains pending, rather than being mislabeled as an unexecuted failure.

### Existing durability and receipt boundaries remain closed

The earlier full-public-body, physical reservation and serial/context CAS fixes remain present. Node and Hermes retain full supported outcomes before optional artifact allocation; immutable publication identities survive response loss. Finite pending/receipt admission and two-bank fsync commits are unchanged by this remediation.

Hermes flush reloads under flock after Redis awaits, merging receipts without replacing newer decisions or resurrecting compacted/reclaimed rows. Exact accepted scope proof remains required for inherited completion closure. Full handoff contents are written into the result artifact before `contextHandoff` is removed from the compact receipt (`2504-2514`); compact identities cannot become context claimants. The compact transport exception therefore permits ACK of proven closure without allowing another native execution. Source-closure proof is still required before receipt deletion.

Node production watcher `index.js:6939-7057` uses the same journal as the serial consumer. Its queued observations stay admitted, submitting requires admitted ownership, and only positive native delivery states accept the identity. The real serial path checks `started` at `7199`. OpenCode packages and uses these implementations, with its public answer staged through the exported journal. There is no analogous accepted-before-recoverable-Hermes-queue transfer requiring another Node change.

## Evidence inspected

Logs below are under `/root/cm-database-completion-20261118/runtime/` on54. Tests use the marked isolated Redis fixture on loopback33328; source inspection confirms fixture guards and counted native callbacks rather than paid model execution.

- `handoff-hermes-final.log`: **88 tests, OK, 30.598 seconds**. The real-handler scenarios cover auxiliary write/fsync faults, mirror/marker loss, exact binding changes, declined steering, unknown native response, post-native journal failure, legacy records, capacity and ownership/compact-receipt guards.
- `handoff-process-final.log`: nine real `os._exit(72)` boundaries, followed by two concurrent fresh recovery processes. Queue-before/after, journal-after, claim-before, receipt-after and ACK-loss recover with nativeCalls1/pending0. Journal-before and claim-after retain nativeCalls0/pending1. Native-effect crash retains nativeCalls1/pending1. Exact request proof changes the latter to request_included/pending0 with nativeCalls still1.
- `handoff-real-enospc-final.log`: actual exhausted64MiB tmpfs, auxiliary allocation ENOSPC, durable retained handoff, subsequent concurrent recovery nativeCalls1/pending0. The source fills to `f_bavail == 0`; this is not a mocked allocation exception.
- `handoff-hermes-claim-final.log` and `handoff-durable-claim-race-test.log`: real handler/consumer races in both orderings, one owner, lost ACK/processed marker, zero restart execution; the Node uncertain winner remains pending.
- `handoff-durable-context-admission-test.log`: real watcher injection0 at256 pending admissions, injection1 after native submission with both mirror and marker lost, serial reexecution0.
- Existing Node consumer/context/contracts/build-check and durability/capacity/review-regression logs all report passing results. The capacity evidence retains501 completed receipts,256 pending bound and300 strict-scope multi-turn assignments. `handoff-opencode.log` reports23 passed,0 failed/skipped.
- `handoff-enospc-node.log` and `handoff-enospc-hermes-final.log`: full supported outcome preservation under real allocation exhaustion, pre/post bank-commit process crashes, later materialization and businessCalls1.
- Final `handoff-oom-{node,hermes}-{prepare,recover}-final.log`: real noeviction OOM with completed result retained, Redis AOF restart and fresh Runtime recovery, stable attempt, duplicate suppression, lost publication response and businessCalls1. `handoff-aof-context-final.log` independently retains queued and uncertain handoff semantics across that restart.

The new test sources use the actual Hermes `_handle_redis_message`, journal, flusher and prepared-request handler. Native steering is a deterministic counted callback; process-crash tests durably record that callback's invocation before exiting. Helper-level delayed-observer and compact-receipt tests complement, rather than replace, the real Redis/handler tests.

Also inspected the supplied parent integration evidence at `evidence/root-projection-bridge-green.jsonl`: `TestRuntimeJournalThroughManagedBridgeAndSourceProof` passes with realManagedRelay/realRuntimeJournal/exactSQLSourceProof prepare and recover records. This supports the already reported bridge/proof boundary; it is not a claim that the pending final frozen CM-wide suite has run.

## Findings and residual limits

**Critical: none. Important: none. Minor: none requiring a source change for this task gate.**

The deliberate limits remain material: one supervised Node gateway owns its private state; physical PVC sizing must accommodate the bounded reservations and retained artifacts; ambiguous external side effects require native proof or explicit reconciliation; native callback tests do not certify a newly built/deployed Runtime image. The final frozen integration verification belongs to the parent CM task. No image build, deployment or Runtime upgrade was requested or performed by this review.

No additional Runtime remediation is requested.
