# Final functional-test plan / HTML evidence review — 2026-11-18

Read-only review of the supplied runner, report recorder/generator/browser test, approved spec/completion plan, changed behavioral tests and prior Runtime/Redis/persistence reports. No final test, local interpreter/test/build, source change, commit or deployment was executed. This memo is the sole written artifact. CM W1–W4 remediation and its independent final review were still in progress while reading; this is a final-test-plan review, not another product audit.

## Gate and execution order

1. Finish W1–W4 and all development; independently review the combined CM source and retain the existing Runtime PASS review. Freeze both exact source trees, test sources, runner, fixture controllers and report tooling with one manifest. Verify local→54 and pre/post-command fingerprints. Any development edit after freeze invalidates affected final evidence; an earlier passing development run is background evidence only.
2. On54 only, prepare marked isolated MySQL/Redis/MinIO, confirm permissions and required markers; record tool/server versions and fixture configuration. Build maintenance CLIs and the frontend there. Never use application data/deployments as fault fixtures.
3. Run full backend once, corrected targeted fault/native scopes, race, Runtime suites and controlled fault phases, frontend/browser, then query/audit capacity serially without competing stress runs. Keep every attempt and exit status, including failed fixture attempts and their explanation. A failed attempt remains visible and is not silently replaced with its rerun.
4. Reconcile required coverage IDs, results, skips, actual metrics/EXPLAIN and evidence hashes. Generate HTML/JSON and full evidence ZIP; validate the actual delivered HTML offline with its browser script and inspect desktop/mobile screenshots. No deployment or Runtime upgrade is implied or authorized.

## Runner fixture corrections identified and now root-owned

The reviewed initial `/tmp/cm-final-functional-runner.py` omitted these globally. Root has acknowledged and is adding both; verify their final evidence rather than reopening the same finding:

- `CM_OBSERVABILITY_TEST_DSN`: both `TestGatewayExecutedResultSurvivesSQLProjectionOutageAndRestart` and `TestDurableInvocationRealMySQLDedupAndHydration` skip without it. Use the marked isolated33317 MySQL DSN. Both tests internally connect to `127.0.0.1:33317`, so pointing only the DSN elsewhere is incorrect. Do not print credentials.
- `CM_OBSERVATION_BACKFILL_BIN`: the backend phase builds the CLI, but only auditperf receives its path. `TestObservationBackfillCLIGateAndPreflight` therefore skips during the broad run. Set it to `final/bin/observation-backfill` after a successful build.

Focused final command, using the runner's existing54 environment plus those two values:

```sh
go test ./internal/aigateway ./internal/repository -run '^(TestGatewayExecutedResultSurvivesSQLProjectionOutageAndRestart|TestDurableInvocationRealMySQLDedupAndHydration|TestObservationBackfillCLIGateAndPreflight)$' -count=1 -timeout=10m -json
```

Require these three tests to PASS without skips, in addition to the full suite. Broad unrelated opt-in skips should be enumerated with real reasons; no need to enable every unrelated Kubernetes/destructive environment test merely to erase a skip count.

## Mandatory changed-behavior coverage

| Scope | Final required evidence / exact existing tests or action |
|---|---|
| E1 statistics | `TestCostReportingCountsEachEligibleRecordOnce`, `TestCostReportingModelAggregationUsesEligibleCostIdentity`, `TestCostReportingRejectsMixedCurrencies`, `TestCostSummaryOutOfOrderDedupAndWindow`, cost overview/session detail tests. Show raw fee identity/totals independently of display aggregation and budget ledger. |
| E2 query/UI | Full repository/handler/service tests for >1000 historical matches, same-time IDs, authorization, 30/90-day bounds, stable continuation, 409 stale population, long body chunks and 200-row/8MiB Trace. Run all four browser scripts, including the newly added held-page/double-Next test in `session-refresh.browser.mjs`. |
| E3 atomic projection | All `TestAtomicProjectionMySQL*`, especially `CommitConnectionFailure`, `CursorFailureRollsBackBusiness`, `ConcurrentInlineAndReplay`, `RedisEffectsWaitForCommitAndSurviveRestart`, `WatermarkRequiresResolvedHistory` and `LegacyPartialReplayFailsClosed`; plus `TestRuntimeJournalThroughManagedBridgeAndSourceProof`. Assert original IDs, no precommit external command, exact durable source proof and no duplicate business/fees after replay. Existing full/race filters include these atomic tests. |
| E4 durability | The two opt-in tests above; `TestJournal*` includes real SIGKILL of unpublished long frame; `TestEncryptedObjectsOwnerDedupVerifiedAndRestart`; native proof/expiry tests. SQL replay must not call upstream or budget finalizer again. Distinguish actual storage services from controlled in-memory object fault injection. |
| E5 Redis bounds | All `TestRedisReply*`, `TestRedisBus*`, `TestRedisReadFailureReason*`; real `TestManagedRedisReal7`; all capacity/maintenance tests. Require COUNT100→1 recovery with unchanged cursor, bad-connection discard and malformed/truncated non-retry; pending/unread protection, registration race, byte/key/cardinality limits, completion reserve, DLQ archive, closure and interrupted cleanup. |
| E6 backup residue | `test_backup_attempts.py -v`: active/stale/unknown identity, symlink/lock failures, finite batch and retry. Retention must preserve active attempts; an age-only deletion is not acceptable. |
| W1–W4 closures | Freeze/review the completed regressions and select `TestWholeBranch*` explicitly. Current source includes typed SQL archive metadata, lower-ID invocation/cost commit and registered-month new invocation tests. These are necessary but W1 also requires actual serving Get/List/Trace/new-write route evidence across month boundary, late write, cutover/rollback and native restore, not merely row presence in a month. Add final cases from the W1 remediation as completed. `session-refresh.browser.mjs` now includes held predecessor/double-Next behavior. |
| F1–F5 closures | `TestJournal*`, `TestMySQLRollback*`, `TestCancelledOutbox*`, `TestDeletedTeamClosure*`, `TestActualObjectArchiveCorruptionAndIsolatedRestore`, `TestObservationNativeProofAndExpiredSnapshot`. Preserve exact cancellation identity,500-row retention cap, proof destination constraints and expired restore behavior. |
| Native backup | Full `internal/systembackup` with both Redis endpoints, real MinIO and built backup verifier, including `TestTeamHistoryNativeBundleRestoresMonthlyObjectsAndImmutableKey`, dynamic month schema capture, corruption/missing object, isolated restore, proof invalidation and backup gate. Expected fixture-gated cases cannot be summarized as covered if skipped. |

The current race regex does **not** include `TestWholeBranch*`; add that prefix after the new fixes settle. The SQL-outage gateway/repository tests also are not selected by the current race filter; include them if their final implementation shares concurrency state. Do not claim all changed behavior was race checked merely because selected packages were passed to `go test -race`.

### Remaining E4 functional gap to close or disclose

The existing gateway SQL-outage regression renames `model_invocations` during a counted HTTP upstream call, reopens the filesystem journal and verifies four fact tables/externalCalls1. Its object store is a successful in-memory map. The repository test separately injects object upload failure during historical body migration. Neither is the matrix's **simultaneous SQL and object outage after upstream execution**, nor a full gateway admission/quota-before-upstream test. Add focused actual gateway-flow cases (counted upstream callback, journal restart, failed object backend, SQL failure, full quota) or explicitly leave these matrix requirements NOT_COVERED. Helper-level journal capacity alone cannot establish upstreamCalls0 at the HTTP admission boundary. Real MinIO archive tests remain useful independent storage evidence.

## Runtime and Redis faults remaining after final freeze

Runtime has an independent PASS review and existing actual claim/crash/ENOSPC/OOM+AOF evidence, including88 Hermes tests and23 OpenCode tests. These are established pre-freeze evidence, not unknown functionality. The runner covers normal suites, actual claim races and nine handoff crash boundaries; the controller still needs to record fresh final runs of:

- `RUNTIME_ENOSPC_ROOT=/mnt/cm-runtime-enospc node plugins/openclaw-redis-team/scripts/durable-enospc-test.mjs`
- Same isolated tmpfs setting with `python3 plugins/hermes-redis-team/durable_enospc_test.py` and `python3 plugins/hermes-redis-team/context_handoff_process_test.py` (the env selects its real ENOSPC case). Use fresh owned per-suite state; the reused-journal failure in prior evidence demonstrates why.
- `durable-delivery-redis-test.mjs prepare/recover` and `durable_delivery_redis_test.py prepare/recover` with fresh `RUNTIME_DURABLE_TEST_STATE`, distinct `RUNTIME_DURABLE_TEST_SUFFIX` and marked33328 URLs. Between phases, perform fixture-only AOF rewrite/restart; verify actual PONG after restart, not only potentially stale Ready. Preserve queued and uncertain handoff states through the same restart. Assert businessCalls1, retained PEL, stable attempt, exact publication ID, duplicate suppression and no replay of ambiguous native execution.
- The root-owned1GiB noeviction /3GiB container fixture using `cm-redis-budget-check.py prepare/recover`, AOF rewrite during writes, actual OOM, fixture container restart and full-payload hash validation. Previous successful budget validation must be rerun after freeze; preserve Redis INFO, cgroup peak and restart/exit evidence. Serial execution avoids contaminating capacity P95.

Native work remains deterministic counted callbacks. OpenCode/Hermes real model/SDK image execution, application release and Runtime upgrade are outside this final suite's demonstrated boundary and must be described accurately.

## HTML evidence review

Good current behavior: leaf execution counts avoid parent double counting; actual failures cannot be hidden by a skipped duplicate; package failures/missing package completion and nonzero exit are surfaced; JSON is escaped against `</script>` and DOM output uses `textContent`; screenshots are embedded. Non-Go suites count actual commands, not invented per-assertion test totals. The220-case synthetic UI test is tooling evidence; final report rendering still needs its own real artifact check.

Root states it is implementing pre/post source-manifest verification, suite manifest-hash matching, full raw evidence SHA/ZIP, static mandatory coverage IDs, nine required performance scenarios with fixed maximum targets, all-SKIP rejection and malformed Go-JSON rejection. These directly address the identified tooling gaps once their remote tests pass; they are root-owned fixes and are not repeated as new product findings.

Integrity findings from the initial reviewed generator, and final verification obligations:

1. **Empty matrix/all-SKIP false acceptance (root fix in progress).** Initial `generate_database_report.py:89-93` permits empty `coverage` and absent/empty `performance`; `all([])` is true. One successful command, or a completed Go package containing only SKIP cases, can therefore yield `accepted=true`. Final integrity tests must reject empty/missing coverage/scenario IDs, all-skipped required scope, omitted fault/controller coverage and relaxed performance targets. Check final coverage IDs actually require all planned phases/fault scopes rather than allowing one broadly named case to satisfy an entire category.
2. **Ignored malformed Go JSON (root fix in progress).** Initial `:27-31` drops JSON decode failures. A valid start/pass/completion plus corrupted nonempty line can be accepted. Require the new integrity test to make that incomplete. Existing truncated-package test alone only covers a missing completion for a started package.
3. **Performance provenance remains distinct from required IDs/limits.** Initial `:90-92` accepts manually supplied sample/P95/limit without a suite/test/log link. Even with nine fixed IDs and limits, bind each actual metric to final `MEASURED` output and retain source evidence/hash/line or test identity. A passing test function alone is not performance acceptance: existing capacity tests log times and correctness; the generator performs the threshold check. Retain actual EXPLAIN, sampled heap/RSS and SQL pool waits. Mark query fixture's direct-summary seeding separately from audit capacity's actual900000-source-row/backfill fixture.
4. **Completion metadata validation.** In addition to root's source-manifest/ZIP changes, require started/finished/elapsed/exit_code with finish>=start>=freeze and record-time evidence SHA/size agreement. This avoids a completed-looking record with incomplete lifecycle metadata. The recorder already writes completion data; test the generator rejects missing/inconsistent data.

The12000-character log tails are acceptable previews if labeled as truncated with original byte size/hash and the full raw log is available in the delivered evidence ZIP. Go cases currently lack the non-Go per-evidence hash; ensure final suite metadata supplies it. The standalone HTML/JSON currently contains only summaries, so do not label the JSON download a complete raw-log export.

Final offline command on54, after generating the actual final report:

```sh
CM_DATABASE_REPORT=/absolute/final-report.html REPORT_SCREENSHOT_DIR=/absolute/report-screenshots node docs/reports/test_database_report.browser.mjs
```

Use the runner's Playwright/Chrome env. Add/assert actual verdict text and numeric cards equal downloaded JSON, all rows across pagination reachable, combined category/status/search filters, log truncation labeling and full-log/ZIP availability. Existing browser test checks first/second page, individual filters, empty state, log expansion, JSON count/accepted/counts, mobile overflow and script errors. It does not verify complete JSON identity, source/evidence hashes, verdict correctness, every page or network independence; test those final artifact properties separately. Current HTML has no external assets, so offline rendering is structurally appropriate.

No final acceptance is asserted by this memo. Required final suites remain gated on finished/reviewed/frozen combined source.

## Updated tooling/controller re-review — before final freeze

**Verdict: updated report evidence tooling PASS for this ordinary source review. No Critical/Important report or controller defect identified. One concrete rerun defect remains in the backup-helper controller below. Final frozen application acceptance is still outstanding.** This section supersedes the earlier tooling gaps and E4 coverage-gap paragraph; it does not repeat the original plan review.

Read updated local report sources and both `/tmp/cm-final-*.py` controllers, their current54 report-tools copies, existing Runtime fault-script implementations and the E4 matrix delivery report. Remote actions only read files and the runtime-redis Pod arguments. No test/controller/build was executed by this reviewer. Read `report-generator-integrity4.log`:8 integrity tests OK, including positive complete fixture, relaxed-target refusal, source mutation, malformed JSON, truncated stream and metric identity. Read `report-ui-fixture-check2.log`:220 records, all pages, verdict/counts, combined filters, full JSON identity, no external requests/script errors and390px width PASS. This was explicitly a nonaccepted synthetic report (`evidenceZIPVerified:false`), not final acceptance.

Closed from the preceding review:

- Runner sets both required DSN/CLI variables, supplies source root/manifest to every recorded command, and its race selection now includes `WholeBranch` and `GatewayObservationMatrix` plus gateway package.
- Generator requires15 coverage IDs,9 measured performance IDs and18 suite IDs; empty matrices cannot pass. Fixed target ceilings prevent relaxed-limit acceptance. Metrics must match exact final suite/test output and parsed Go duration/sample values.
- Recorder verifies all frozen file hashes before/after, preserves original command exit, fails changed source as126, and records raw evidence SHA/size. Generator validates completion lifecycle, evidence hash/size and shared source manifest. Go corrupt lines become INCOMPLETE; hashes apply to Go and command records. Final accepted CLI output requires the actual adjacent ZIP hash to match.
- Offline UI checker now verifies every page, displayed verdict/cards, combined filters, complete downloaded JSON, no external requests and accepted ZIP hash/link. Final actual accepted artifact still must be run through that checker.
- E4 source now has the4 leaf actual-serving tests for normal/streaming dual storage failure and owner/global admission through both entrypoints. The supplied actual SQL/filesystem outage, exact replay/body/fee assertions and remote normal/race evidence close the earlier matrix gap. Source inspection confirms the final runner discovers/selects them. They still need the final combined-source rerun like all other cases.

Controller/caller checks:

- Runtime fault CLI/path/env names match actual scripts. ENOSPC uses a64MiB tmpfs and fresh per-script directory; scripts themselves verify real zero available blocks and committed result bytes. OOM prepare phases restore maxmemory before subsequent setup; each runtime uses a unique durable state/team suffix.
- Container restart checks appendonly, incremented restart count, preserved Pod UID, changed container ID and real PONG; forwards are replaced only after identifying the exact owned namespace/pod/port command. The existing runtime fixture uses appendfsync=always/noeviction and16MiB maxmemory. `SHUTDOWN NOSAVE` tests a controlled container/AOF restart; report it accurately, not as an unclean machine-power-loss test. Budget prepare separately executes an actual BGREWRITEAOF during writes.
- Queued and native-effect-uncertain handoffs survive that restart, use fresh concurrent recovery processes, then exact native proof resolves the uncertain case. Counted callbacks remain the stated native execution boundary.
- Redis budget rebuild is guarded by the exact owned marker, gives the new fixture1GiB noeviction/3GiB limit, and retains emptyDir across its container restart. The helper asserts fresh cardinality, real OOM, no eviction, sampled rewrite memory and cgroup peak, then reads and hashes every accepted64KiB payload after restart. The rejected key is checked absent. No obvious command/reply/path mismatch was found.
- Stock MySQL helper exercise decompresses and hashes the generated binary, uses inherited descriptor9, refuses a competing independent lock and reacquires after owner exit. Build/output stays on54; no application backup CronJob is installed.

### Minor, concrete controller rerun defect

`/tmp/cm-final-fault-controller.py:109` fixes helper preparation output at `ROOT/backup-helper-preparation`, while `prepare-backup-lock-helper.py` creates its `--output` directory with `exist_ok=False`. Thus a second `tools` phase using a fresh `CM_FINAL_RUN_TAG` (or a retry after the first preparation succeeded) fails with FileExistsError before the stock-image check. It cannot produce a fresh comparable retry even though the evidence recorder intentionally supports distinct retained attempts. Use a timestamp/tag-specific preparation directory, retaining the old one. This is a harness reproducibility issue, not evidence of a product locking failure.

No further scope or speculative hardening is requested. Copy the reviewed controllers/helper to the exact final/tools paths and freeze their bytes with the source, as already planned. Correct the small rerun issue before freeze or document a deliberately single-use tools phase; then proceed with the already planned frozen-source execution after the CM review gate passes.
