# Independent legacy restart fixture re-review

Date: 2026-11-18. Scope: the sole subsequent source change in `backend/internal/ownerrecords/sync_resilience_mysql_test.go`, specifically `TestSyncResilienceMySQLProductionScaleSource`. Read-only review; no local executable tests/builds, source changes, commits, deployment or running-test interference by this reviewer.

## Verdict

**PASS. The false failure is corrected and both restart paths are actually exercised. No remaining confirmed Critical/Important finding.** This is a test-only correction; no production owner-record logic or time/data/financial boundary was relaxed. Root's v5 complete freeze/rerun remains a separate required acceptance gate.

## Original failure and preserved intent

The original test assumed its initial full projection pass must leave pending work. On a healthy faster fixture it correctly processed all1000 owners, leaving0, then unconditionally required the cold worker's remaining count to be less than0. The independent RED log shows exactly `processed=1000 remaining_dates=0`, followed by `restart did not reduce persisted pending work 0 0`; this is an invalid fixture expectation, not a failed source projection.

I checked the diff and original phase:3200 instances,1000 owners,10000 initial calls, the existing late call, source coverage/repair checks,100000 then100050 token assertions and full projection progress remain intact. Production `syncProjectionBudget` remains60 seconds; the roughly12-second observed phase time is not that budget. Cold resumes retain their existing3-second budget. `git diff acf8665a --name-only -- backend/internal/ownerrecords` reports only this test file; no production ownerrecords file changed relative to the original base.

## Final test behavior

The new `resume` helper creates a fresh `Store{Session: s.Session}` each time and runs real `processDirty` with a3-second context and diagnostic counters. With positive pending work it requires a strict durable pending decrease and positive processed count. With no pending work it requires nil error, pending0, processed0, unchanged total record count and unchanged SUM(version). Every resume also checks source tokens remain100050.

The `drain` helper retains the actual returned remainder. Its number of calls is bounded by the initial pending+1, every positive iteration must strictly progress, and it explicitly requires zero before an **unconditional** idle cold-worker check. No sleep, forced timeout, queue deletion, process cache reuse or skipped assertion simulates a restart.

After the original backlog is actually zero, the test calls the production `markUsageDay` on41 existing owner/day identities. This re-marks durable work without adding source calls or tokens. It requires exactly41 pending records, invokes the real production `processDirtyPass` (selection limit40), and requires exactly1 remaining. A fresh cold worker must then process that persisted remainder; the drain helper requires zero and unconditionally tests idle again. This ensures a partial restart path exists even when the full1000-owner phase finishes quickly.

During review I found that the first draft still discarded the first resume's return value and conditionally skipped idle when its last resume remained partial. That would not guarantee both paths on slower machines. The sole test owner corrected it to the explicit drain/zero/unconditional-idle flow above before the final verification runs. The issue is closed; draft passes are not used as proof for the final source.

## Exact source and execution evidence

Final source SHA256:

`e586c8175e3cf4dc5100acbe0eb030f16ddb54e79b621ee149be9c97df5d7777`.

I directly checked both the local file and the server54 independent sandbox file; they match. The implementer's `verification-summary.json`, also directly read, records1878 source files compared with the frozen tree and only this test differing, plus byte-identical pre-restart scale/source/budget assertions. The frozen final tree was not modified by this test owner.

Remote evidence directory:
`/root/cm-database-completion-20261118/legacy-resume-fixture/evidence/`.

- `resume-red.jsonl`: original source, exit1, package13.810s; full phase11.245s processed1000 and remaining0, then the false0<0 restart failure.
- `resume-green.jsonl`: final source, exit0, package14.396s. Original full phase11.198s processed1000; actual idle-full-pass0→0/processed0; durable marks41→1; cold bounded-pass1→0/processed1; idle-bounded-pass0→0/processed0.
- `resume-race.jsonl`: final source, exit0, package22.108s. Original full phase16.847s processed1000; the same two empty-path checks and real41→1→0 partial-path sequence all executed.

I read those raw JSONL path events and final package outcomes, and independently scanned the two final runs:0skip,0fail,0data-race warnings. The recorded ordinary/race log hashes are respectively `b54802766c157c8e9452d9d39c7ead50c17ad27f3663d758b5931e34abeb443d` and `de42c5770a86666504234aa4863717fe9522a7f9e9bc84f10971315050d0c560`.

## Acceptance boundary

This focused gate is clear for v5 freeze. It proves the repaired test exercises both persisted-resume and already-complete behavior without weakening its original scale, budgets or accounting assertions. It does not convert the earlier v4 aggregate failure or explicitly stopped v4 capacity command into a pass, nor substitute for the final frozen complete rerun. Previous actual900k v3 SLO results remain separately identified evidence.
