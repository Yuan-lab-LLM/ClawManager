# Independent frozen-v1 discovery re-review

Date: 2026-11-18. Scope is the four-file correction following frozen-v1 backend failures: the session-reporting MySQL fixture and Managed Team Redis key-denial pipeline behavior. Prior whole-branch/R1–R3 review gates are not reopened by this focused review.

## Source assessment

**Focused independent review: PASS. Both frozen-v1 discovery findings are closed.** No new Critical or Important issue is confirmed. Actual current-source MySQL/Redis covering and race runs have completed successfully; no minor cosmetic correction is requested.

### Session reporting fixture

`backend/internal/repository/cost_record_reporting_mysql_test.go:81` now uses `auditFullFixture`, which initializes the actual schema, instead of a hand-written partial model_invocations table and selected migrations that omitted the new history_log_locations dependency. The obsolete seedReportingSummaries helper is removed. Actual `ReconcileObservationSummaries` must process exactly1 then24 rows before the respective reads.

The original behavior assertions remain: recent reporting has3 tokens and no request/response bodies; all25 calls aggregate to75 tokens for model b; exact GetByID still returns both original bodies. No production reporting implementation or expectation was relaxed to make the fixture pass. This better exercises the actual source→summary→read path.

### Redis pipeline correction

`backend/internal/services/managed_team_redis_capacity.go:11` introduces a private key-denial sentinel and a fixed CM-only script returning NOPERM. `:90` returns that sentinel for foreign-Team, overlength and disallowed internal keys. Key collection and the check of every supplied key still happen before any state command, capacity initialization or backend write. Mixed local/foreign DEL therefore rejects the entire command.

`backend/internal/services/managed_team_redis.go:291` converts only that sentinel into `EVAL <fixed-error-script> 0`, then uses the existing single backend writer. Redis produces the error on the same ordered response stream as preceding and following commands; the existing sole backend-reader goroutine remains the only writer to the downstream client. There is no direct competing client error write, new response buffering, extra backend connection, client-provided script text or key interpolation.

`guardManagedRedis` still runs before conversion. Its exact two Runtime script allowlist, ACL provisioning and command permissions are unchanged. A client supplying the new CM error script cannot invoke it directly. Other malformed/context-changing commands and infrastructure/capacity failures retain their existing failure handling. The existing protocol's sole `replay-source-closed` GET exception remains unchanged; other internal keys are denied.

### Regression coverage inspected

The new real Redis64-command pipeline repeatedly checks successful SET/GET/PING replies around denied foreign GET, actual internal HGET/HGETALL and mixed local/foreign DEL. It requires every reply in exact order, no successful metadata read, intact local values after refused DEL, and continued connection usability. The metadata exists and has ready=1 through the test's separate administrative connection, so refusal is tested against real data. HGET/HGETALL are appropriate for the actual internal hash; root explicitly accepted this over a weaker literal GET that would otherwise yield WRONGTYPE.

The original cross-Team pipeline test and known-Lua atomicity tests remain. A client-supplied copy of the private error script is added to the forbidden-command cases and must close the session. BLOCK/wakeup uses the supported `inbox:blocking` stream name while retaining group creation, blocking read, independent producer and actual wakeup assertions. No production stream classification or ACL was expanded for the test.

## Evidence boundary

No local builds/tests, product edits, commits, deployments or application-resource mutations were performed by this reviewer. Prior frozen-v1 failures and its stopped performance run are not counted as success. This focused gate does not replace root's new frozen full-backend/capacity acceptance.

## Completed verification

Reviewed baseline HEAD is `0459194c80cdb9fca73e3d9011828ffa3e4ffc7f` plus the four-file diff in `/tmp/cm-database-v2-discovery-fixes.patch`. The exact four-file manifest `/tmp/cm-database-v2-discovery-source.sha256` has SHA256 `237e71230ea8e7d11902192c0ab42d0de39471925fe32ebe3809b1e4d94bf9b0`. I independently checked all four local entries twice with exit0, including after race completion. Root/fixer report remote per-file equality; the previous frozen remote tree was not silently changed.

I directly read these remote raw logs under `/root/cm-database-completion-20261118/fixture-v2-fix/evidence/`:

- `session-projection-red.log`: actual missing history_log_locations, MySQL1146, FAILED0.257s.
- `session-projection-covering.log`: PASS21.388s, including the repaired test, cost/model/currency reporting, complete audit error preservation, monthly cutover/rollback and body migration/expiry. Implementer counts11 leaf cases.
- `managed-redis-red.log`: original selected integration cases fail with EOF, package FAILED0.051s.
- `managed-redis-policy-red.log`: added ordered pipeline fails at reply0 SET with EOF, package FAILED0.059s.
- `managed-redis-final-green.log`: all `^TestManagedRedis` selected tests PASS11.418s, including actual isolated Redis7 on33338, exact original Runtime scripts, ACL/account protection, pipeline/internal-key rejection, BLOCK/wakeup and cleanup.
- `v2-discovery-race.log`: repaired reporting case PASS; repository package6.263s. All Managed Redis selected tests PASS; services package12.778s.

Independent scanning of the final covering/Redis/race logs found zero skipped cases, zero failed cases and zero data-race warnings. I also checked the final denied-reply assertion: it compares the complete expected wrapped `NOPERM managed Team key access denied` text, not merely a generic error or a permissive substring. The earlier `managed-redis-green.log` failure came from expecting an unwrapped error prefix; it remains a failed intermediate run and is not counted as a pass.

**Assessment:** this focused correction is ready for root's next frozen acceptance run. No permission, ACL, internal-namespace, Runtime Lua or capacity-budget weakening was introduced. Final whole-backend and capacity success must still be established on the next freeze; this report does not claim it.

## Addendum: TeamData fixture correction — PASS

Root requested this additional test-only review after the complete frozen-v1 backend run. The only additional changed file is `backend/internal/systembackup/pipeline_integration_test.go`; no production backup implementation changed.

At line121, a TeamDataOnly fixture with fake Kubernetes adapters now uses the actual in-process `CaptureFunctionalBundle` and `PublishFunctionalArtifact` path rather than the generic capture CLI, which lacks that fixture mode and otherwise attempts to open an absent Kubernetes auth file. Non-TeamData capture still uses the supplied CLI. Published snapshot validation, artifact integrity verification, the independent verification job and the actual external restore CLI remain active. This removes an invalid fixture invocation without replacing capture/restore with fabricated results.

At line209, the obsolete hardcoded75-table assertion is replaced by production `requireBusinessSQLInventory`. I inspected that function: it requires every trusted Registry mysql_dump entry and every validated registered monthly table, then rejects an unexpected total. It is not merely a nonempty/minimum-count assertion. The test clones the real restore report's table map and deletes each table separately, requiring rejection every time; the original report is not mutated. Current real output has125 tables and all125 single-table omissions are rejected. Succeeded/complete/non-acceptance status, two history parts, SQL readback, interrupted-task state/result preservation, original workspace bytes, restored Redis isolation and subsequent permission/data assertions are retained.

Directly read raw evidence in the same remote evidence directory:

- `team-data-capture-red.log`: original TeamData fixture fails with `open : no such file or directory` in4.93s; unchanged publication recovery independently passes1.31s. Aggregate run remains FAIL.
- `team-data-inventory-red.log`: after only correcting capture dispatch, actual restore CLI reaches complete with125 tables and nil error, but old75 assertion fails13.30s. Aggregate run remains FAIL.
- `team-data-final-green.log`: three cases PASS, systembackup14.697s: TeamData13.39s, publication recovery1.25s, valid-but-incomplete SQL rejection0.03s.
- `team-data-final-race.log`: the same three cases PASS, systembackup17.140s: TeamData14.13s, publication recovery1.76s, incomplete SQL rejection0.14s. Both ordinary and race log the exact125-table inventory and every single-table omission rejection.

Independent scan of these two final logs found0SKIP,0FAIL and0data-race warnings. They use the healthy isolated storage endpoint; the earlier frozen-v1 port-forward reset/S3 failures remain failed infrastructure-affected evidence, not retroactively counted as a pass. Publication received no source correction.

Final five-file changed-source manifest `/tmp/cm-database-v2-final-source.sha256` has SHA256 `eb853d05aae934c61c46a8555987179de6d7cf257677a64dbebeb99f50eac718`. I independently checked all five entries after reading the completed race output: exit0. This is the focused changed-file inventory, not a substitute for root's next complete freeze manifest.

**Final focused verdict remains PASS:** both original discoveries and this additional obsolete TeamData fixture are closed; no new confirmed Critical/Important issue and no weakened product or test acceptance boundary. Root may proceed to the v2 frozen full acceptance run. No v2 full/performance success is claimed by this review.
