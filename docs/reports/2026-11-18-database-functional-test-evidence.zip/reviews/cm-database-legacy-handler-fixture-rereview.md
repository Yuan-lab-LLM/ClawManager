# Independent focused review: legacy handler migration109 fixture

Verdict: PASS for this single-file fixture correction; no confirmed Critical/Important finding. Reviewer did not edit product or test source and did not rerun tests; independently inspected diff/source and parsed the implementation agent's raw54 execution artifacts.

Scope: `backend/internal/handlers/gateway_activity_admission_test.go`, SHA256 `c33de159b453f1c05de10aab2b3c385ff3195ff593af96431dca3f8ac284bf39` (local and tested remote file match).

The old fixture applied production096, but repository activity reads already refer to `q.lease_expires_at`, added by production109. The fix applies actual109 after096 using the same statement executor. It changes neither product fallback nor admission/lease behavior. The localhost numeric-port guard, unique random schema and cleanup remain. All8 existing chat/responses/anthropic/images × stopped/stale cases retain exact409 response, no policy/provider request, ActiveRequests0 and LastGatewayActivityAtnil assertions. Independently compared the entire source tail beginning with `activity := repository.NewInstanceAutoStopRepository(s)`: byte-identical to the original.

Independent read of raw artifacts under `/root/cm-database-completion-20261118/legacy-activity-fixture/evidence`:

| Artifact | Exit | Leaf results | Package duration | SHA256 |
|---|---:|---|---:|---|
| activity-red.jsonl |1|8FAIL, each MySQL1054|0.827s|70184867d0dd6e4c8899911a1fa855738637fba3489c013b5bd459c13d88091f|
| activity-green.jsonl |0|8PASS,0SKIP|1.048s|b248f007db5b17299d9e4a93e531235c08d06fe553ab742fac6cd40e10947daf|
| activity-race.jsonl |0|8PASS,0SKIP, no race warning|2.177s|89a7b5b33b1cff98f8aa9a1277e8629bfa6e48de0d6adf5c31b24259691f34f5|

The command and offline Go environment are retained in `evidence/report.md`; exact selected test is `^TestGatewayActivityPublicProtocolsRejectStoppedAndStaleMySQL$`, actual disposable MySQL33347. Ordinary/race preserve the same test source. Separate `.exit` files match each expected process result. Independently recomputed raw log hashes above and compared1878 backend Go/SQL/module files against frozenv3: the only difference is this test file. Frozen app/source was not modified by these development tests.

This focused approval covers the fixture correction. Final combined v4 acceptance remains root's separate complete same-source run; these development results are not a substitute for it.
