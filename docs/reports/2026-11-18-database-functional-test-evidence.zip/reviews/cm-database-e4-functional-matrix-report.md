# E4 actual gateway functional matrix — 2026-11-18

DONE: non-streaming and actual streaming dual-outage durability, plus owner/global admission through both service entrypoints, now pass on10.130.81.54 with and without `-race` (4 leaf cases, no skips). The streaming extension exposed a genuine terminal SSE delimiter bug; the separate product-fix owner corrected it, and the strict functional regression now passes. Only `ClawManager/backend/internal/aigateway/observability_failure_matrix_test.go` was added by this task. No product file, existing test, deployment, image, Runtime, application database, or commit was changed by this task.

## Implemented cases

`TestGatewayObservationMatrixExecutedResultSurvivesSQLAndObjectOutage/{stream=false,stream=true}`

- Uses `db.Initialize` and the complete embedded normal migration sequence, a fresh owned `cm_gateway_matrix_<timestamp>` database, real SQL-backed model/session/invocation/chat/cost/audit services, and the actual `ChatCompletions` serving path. The fixture refuses any MySQL endpoint other than explicitly enabled localhost33317 with the `cm_database_test_marker` schema. Only its newly created database is dropped.
- A counted HTTP provider first receives the real request, then installs an owned SQL `SIGNAL` trigger on `observability_event_receipts` and replaces its owned production `ObjectStorageService.LocalFallback` directory with a regular file. The completed provider body contains a long UTF-8 result that requires encrypted object externalization. No successful in-memory object backend is used.
- The original response remains HTTP200, has the exact provider body and request identity, and reports `X-ClawManager-Persistence: durably-recorded`, appropriate because the complete result is durable in the WAL even while SQL projection and object publication fail. The test independently probes that both real faults are active.
- The streaming variant enters actual `StreamChatCompletions` with a real flushing `httptest.ResponseRecorder`, two long content delta frames, a finish reason, a separate3/4/7 usage frame and a fully delimited `[DONE]` event. It verifies exact client SSE bytes, an actual flush, the declared `X-ClawManager-Persistence` durable trailer, complete raw SSE in the WAL/object body, and `IsStreaming=true` both in the WAL and after serving-read hydration. All shared outage/restart/replay/accounting assertions run for both stream variants.
- Exactly four pending completion facts remain in terminal WAL state: invocation, assistant chat, cost, and completed audit. An authenticated separate snapshot is replayed for inspection without acknowledging the original journal. It verifies the exact original provider request and full response, assistant content, 3/4/7 token usage, completed state, USD, unit prices2/5 per million, and fee0.000026.
- Reopening `NewJournal` and replaying with both faults still active acknowledges zero facts. Restoring only SQL still acknowledges zero facts while objects remain unavailable. All four facts remain pending. Restoring both services delivers exactly four, then zero on the second replay.
- After both recovered replay passes, each fact has exactly one receipt with the original payload digest, a positive original ID, and exactly one matching business row. Entire-request cardinality independently remains one invocation, one cost, one assistant message, and one completion audit (the initial user chat and request-received audit are separate expected admission facts).
- Actual serving repository reads hydrate the exact provider result and long assistant content from non-null encrypted object references. The stored fee, currency, tokens and linked invocation identity remain correct. Reusing the request identity returns `ErrRecoveryRequired` before another upstream execution. Provider calls, token finalization and budget settlement each equal1, and the settled amount equals the single durable SQL cost.

`TestGatewayObservationMatrixAdmissionFullRejectsBeforeProvider/{owner,global}`

- Uses a fresh fully migrated owned database and the actual `ChatCompletions` / prepare / preflight path.
- A first accepted HTTP call blocks after reaching the provider, retaining its durable preallocated20MiB completion channel. The owner case reserves40MiB globally and20MiB per owner, so the same owner's rejection is independent of spare global capacity. The global case reserves20MiB globally and rejects a different owner, proving the global boundary separately.
- Second requests through both `ChatCompletions` and actual `StreamChatCompletions` return `ErrOverloaded`, no response, zero newly admitted SQL identities, and no additional provider call. Rejected calls have a bounded context so a broken admission guard fails rather than hanging behind the held provider.
- The previously accepted call is then released while capacity remains full and finishes HTTP200 with its durable persistence header. Its invocation and cost each appear exactly once with7 tokens. Provider calls remain1.

## Executions and evidence

All Go/gofmt/test/race execution occurred only on54. Go was `go1.26.8 linux/amd64`. The remote source directory is `/root/cm-database-completion-20261118/e4-matrix/ClawManager`; evidence is beside it under `/root/cm-database-completion-20261118/e4-matrix/`.

Common remote environment:

```sh
env -u GOROOT GOTOOLCHAIN=local CGO_ENABLED=0 GOMAXPROCS=2 \
  GOPROXY=off GOSUMDB=off \
  GOPATH=/root/cm-nfs-multislot-20261105/cache \
  GOMODCACHE=/root/cm-nfs-multislot-20261105/cache/mod \
  GOCACHE=/root/cm-nfs-multislot-20261105/cache/build \
  CM_OBSERVABILITY_TEST_DSN='root@tcp(127.0.0.1:33317)/mysql?parseTime=true' \
  /root/cm-nfs-multislot-20261105/tools/usr/local/go/bin/go \
  test ./internal/aigateway -run '^TestGatewayObservationMatrix' -count=1 -timeout=5m -json
```

The race command uses the same environment with `CGO_ENABLED=1` and `go test -race`; Go's race instrumentation requires cgo, and `/usr/bin/gcc` is installed on54.

Original pre-streaming development runs (retained; superseded by the complete matrix below):

| Attempt | Result | Retained evidence |
|---|---|---|
| Initial targeted `-v` | Exit1; owner subtest passed; two fixture/assertion mistakes | `first-test.log` |
| Corrected targeted `-v` | Exit0; both scopes and owner/global passed,11.454s | `second-test.log` |
| Final current test source `-json` | Exit0;3 leaf cases PASS, no skips,11.639s | `verified-test.jsonl` |
| Same frozen backend snapshot `-race -json` | Exit0;3 leaf cases PASS, no skips,12.646s | `verified-race.jsonl` |

The initial attempt is preserved: SQL `DECIMAL` roundtripping requires a numeric fee tolerance, rather than comparing float bit patterns; updating the reused fixture model must retain its original `CreatedAt`. These were test construction errors, corrected solely in the new test. No product defect was found in the original non-streaming/admission scope. Expected SQL45000 fault stack output is deliberate evidence of the active projection trigger.

The complete1869-file backend `.go`/`.sql`/`go.mod`/`go.sum` manifest was generated before final JSON verification. `sha256sum -c` passed before race and again after race, with all entries OK. It is a development snapshot; the root's combined final freeze must rerun both new cases after all product work completes.

| Artifact | SHA-256 |
|---|---|
| Original pre-streaming test source | `dc6b4954e515af6a0c3fadd5bb438ac57a6977ba0450ea529ed6aa8691f7a99c` |
| `backend-source.sha256` | `8b7ce934a057efa0d88c485b45fa8d6318871d46ab19bef597e776468495005b` |
| `verified-test.jsonl` | `e07b032236d793ca07a9cc29d382b252b4f417560461a4082864b14e906e94f0` |
| `verified-race.jsonl` | `a2fe63af61e21087e01909d5b2dcf11ab0b47c6c08aabb7a8bfa1e514c5b11ef` |
| `first-test.log` | `02c93ce50ad0b6757df3174af2e9a1b80d16dcefa347ff7eeb840b1817c7a2c5` |
| `second-test.log` | `57a1ea94fc9d6cfb6390664a866a59072faf9f18cc5eba90022a5fc5fd42a65f` |

Source checks are retained in `source-check-before-race.log` and `source-check-after.log`. Local evidence copies are `/tmp/cm-database-e4-functional-matrix-evidence/`.

## Streaming extension: actual product RED → GREEN

The remote source was refreshed with the current normal migration123 before adding the streaming table case. A new actual gateway run failed with exit1 in `streaming-first-test.jsonl`:

```text
TestGatewayObservationMatrixExecutedResultSurvivesSQLAndObjectOutage/stream=true
client streaming terminal event lacks complete SSE delimiter:
got tail ...usage...\n\ndata: [DONE]\n
```

The provider sent `data: [DONE]\n\n`. `service.go:proxyOpenAIStream` wrote the `[DONE]` data line and immediately returned on `inspection.Done`, dropping the following blank frame delimiter from the actual client response and raw response persisted by `recordSuccess`. The completed SSE event is incomplete for consumers that dispatch only after the blank line. This is a real product bug exposed by the added functional check; it was reported to root and the sole product-fix owner before any product edit. This task does not own or edit `service.go`. The strict complete-frame assertion remains in place.

The independently runnable extended owner/global admission case already passes (exit0,8.669s) in `streaming-admission-test.jsonl`, proving quota refusal through both real service entrypoints without another provider call. `streaming-red-source.sha256` and `streaming-red-hashes.txt` preserve the exact failing backend/source identity.

The product owner corrected the shared proxy to forward the blank SSE delimiter after `[DONE]` before returning; EOF after a previously seen `[DONE]` remains accepted for existing compatibility. No bytes are synthesized, and normal LF/CRLF delimiters and the existing1MiB durable response limit remain supported. The owner's focused LF/CRLF unit RED/GREEN is retained separately in `whole-branch-fixes/evidence/stream-frame-{red,green}.log`.

After syncing the corrected complete backend (including normal migration123), these final development checks passed on the same1872-file source snapshot:

| Command scope | Result | Evidence |
|---|---|---|
| `go test ./internal/aigateway -run '^TestGatewayObservationMatrix' -count=1 -timeout=5m -json` | Exit0;4 leaf PASS, no SKIP;17.480s | `streaming-verified-test.jsonl` |
| Same scope with `CGO_ENABLED=1 go test -race` | Exit0;4 leaf PASS, no SKIP;18.500s | `streaming-verified-race.jsonl` |

The four leaves are `ExecutedResultSurvivesSQLAndObjectOutage/stream=false`, `/stream=true`, `AdmissionFullRejectsBeforeProvider/owner`, and `/global`, each under the `TestGatewayObservationMatrix` prefix. Both admission leaves execute a real rejected stream call as well as the normal rejected call. Ordinary and race commands use the same common54 environment listed above. The reproducible actual-stream RED used `-run '^TestGatewayObservationMatrixExecutedResultSurvivesSQLAndObjectOutage$/stream=true$'`; the separate admission pass used `-run '^TestGatewayObservationMatrixAdmissionFullRejectsBeforeProvider$'`.

`sha256sum -c streaming-source.sha256` passed before normal execution, before race, and after race; all1872 entries remained OK. The current test source is identical local and54; whitespace checking passed. All new raw logs, manifests and source-check outputs are copied to the local evidence directory listed above.

| Current artifact | SHA-256 |
|---|---|
| Current new test source, local and54 | `7db00278ac621fc53ac5c099e97af537d1ab48b516772e64ab517dcd2d7befc8` |
| Corrected product `service.go` used in verification | `0f4bf8569e74c1a6d0d0d30fabca4ad0d0d607cdbd7c5cf0031f124348348759` |
| `streaming-source.sha256` | `80054af5ef9e907eee6e3e7fda6cf79b6992268579198771335dffd36c4efbd6` |
| Actual product RED `streaming-first-test.jsonl` | `c3dc3ae851b873db4ca83494a11103879d7b1ef9cbdfebd51693f81bb23bb94b` |
| `streaming-admission-test.jsonl` | `ce97e192a52d9d573a028d93492522620ce814ef63aac773f379b3c892ed259b` |
| Final complete matrix `streaming-verified-test.jsonl` | `72527af69fa073ef52dd4568ea4ffc367948d367541b65f0cebe791ca1548d65` |
| Final complete matrix `streaming-verified-race.jsonl` | `50ee6fca836b0476ba2487e9198feeb1ca7b69eed55c11fbc3f80badad21dca0` |

## Boundaries and final-run integration

The provider is a deterministic counted HTTP fixture; this does not claim real model/SDK execution. The SQL fault is an actual server-side projection-receipt rejection, not a stopped MySQL process. The object fault is the production filesystem storage implementation with an actual filesystem path failure, not a stopped shared MinIO process. Journal restart means reopening and authenticating the durable journal in the same test process; process-SIGKILL coverage remains the independent existing journal suite. Budget settlement uses a counted existing test budget service; durable fee rows and linkage use real MySQL. The verified scope covers non-streaming and streaming completion through their distinct serving paths.

Add `TestGatewayObservationMatrix` to the root's final targeted and race regexes. The normal full backend suite discovers it automatically when `CM_OBSERVABILITY_TEST_DSN` is supplied. These are final required E4 coverage, not substitutes for separate MinIO native backup/object, SIGKILL WAL, native proof, or full admission handler tests outside the gateway service.
