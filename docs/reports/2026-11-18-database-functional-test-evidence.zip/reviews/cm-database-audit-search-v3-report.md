# V3 audit search and capacity fixture correction

Status: actual repository search RED/GREEN, complete semantic covering, final native8 and race all PASS. Product edits are local and transferred only to independent `/root/cm-database-completion-20261118/audit-search-v3/ClawManager`. Frozen `final` source and v2 evidence remain untouched. Parent owns independent review, v3 freeze and complete real-source capacity rerun.

## Confirmed failures and root cause

The complete v2 audit test executed900000 actual source records through production CLI backfill, including interruption/resume. Its process exited0 because its old assertions only checked result correctness. The fixed report acceptance rejected search30 P95=1.613602101s against500ms; search90=1.039453171s was within2s. Raw evidence remains `final/evidence/v2-audit-capacity.jsonl`.

The first independent full-migration diagnostic uses900000 explicitly synthetic report rows with the same trace/date/model distribution, not source-backfill acceptance. Current statistics selected a full table scan plus users lookup; COUNT took about0.75s. Forcing PRIMARY or ignoring the count index still took0.74s. Removing the users join yielded0.68s; dropping LOWER still failed the target. These experiments were not shipped. The original actual `ListAuditReportPage` with20 samples failed30days at772.254556ms;90days was1.098556447s. This confirms that merely changing a join/hint is insufficient. The diagnostic is visibly named and labelled synthetic throughout; it does not replace the parent's final production-backfill run.

The accepted solution adds one covering index and divides search COUNT into disjoint model-matching and remaining-field branches, summed in one statement under the existing read-only repeatable-read transaction/fence. The first branch uses only the covering index. The second applies NOT(model-match) as an index condition before fetching message and current user data. Original LOWER/COALESCE/LOCATE substring predicates, NULL behavior, fields, status/model filters, cursor/fence, readiness gates and pagination are retained. No term-specific branch or capacity-model special case exists.

Actual EXPLAIN ANALYZE on900000 diagnostic rows proves the model branch is covering; the remaining branch returns0 before any users lookup for this all-model-match distribution. Twenty samples: model-only P95=180.510094ms, remaining P95=148.633076ms, complete summed COUNT P95=320.869718ms. More importantly, complete actual `reporter.ListAuditReportPage` after the change, including readiness/fence/count/page, passed20 samples:30days362.95978ms≤500ms and90days1.057457207s≤2s. These are full method measurements, not sums of separate SQL timings.

This audit query is the administrator-only `/admin/ai-audit` route (`server/main.go` Auth/SetUserInfo/NewAdminAuth); request/service/repository query structs have no UserID/InstanceID filters and actual WHERE does not use them. The index was not expanded for nonexistent scope fields. Username search remains a current users-table predicate and is exercised after an actual rename. Instance/owner-scoped history and Trace use separate unchanged authorization paths.

The query-capacity fixture had a separate pathological setup plan: optimizer started from roughly447k resolved facts, then temporary sorting for each500 receipts; v2 was explicitly stopped by parent and retained. The fixture now uses STRAIGHT_JOIN twice to start at the pending primary-key scan, then cost/fact primary-key lookups. All exact matching predicates and500 limit remain. On the retained real v2 database, after verifying no old connections/transactions, one actual transaction temporarily made four source/fact pairs disagree on trace, invocation, cost and resolved. All four receipts stayed. Exactly500 other verified receipts were deleted in26.491563ms, pending558500→558000; all four original fact values were restored before commit. No database was cleared.

## Exact source changes

Six modified/new files, patch `/tmp/cm-database-audit-search-v3.patch`:

- `backend/internal/db/migrations/118_add_audit_trace_reports.sql`: one `idx_audit_report_model_search(sort_at,requested_model,actual_provider_model,sequence_id,id,status)` index. Parent explicitly approved changing this never-deployed branch migration instead of adding124.
- `backend/internal/repository/observability_audit_reporting.go`: disjoint model/remaining search COUNT using that index; page predicates/query remain equivalent.
- `backend/internal/repository/observability_audit_search_mysql_test.go`: actual full-migration source writers, production reconciliation, independent original-SQL semantic oracle and every page ID. Covers overlapping fields, current usernames/rename, NULL/missing owner, all original search fields, Unicode, literal%/_, absent term, status/model filters and cursors. No simplified handmade schema.
- `backend/internal/repository/observability_audit_capacity_mysql_test.go`: existing real-source20-sample capacity scenarios now fail for30day P95>500ms and90day P95>2s. No data volume/timing/threshold relaxation.
- `backend/internal/repository/query_capacity_mysql_test.go`: two JOIN→STRAIGHT_JOIN changes plus one explanatory comment; same500 and all receipt identity/value predicates.
- `backend/internal/systembackup/whole_branch_history_mysql_test.go`: after actual native isolated restore, requires the exact six-column search index, proving trusted restore schema preparation recreates it.

`schema.json` was regenerated on54 via actual full migrations (`schema-regenerate.log`, PASS5.195s). It remains byte-identical because the existing native row/schema contract records columns and primary keys, not secondary indexes. No fabricated schema change was introduced. The normal non-UPDATE contract test and actual restored-index assertion are included in native8.

## Commands and raw evidence

All logs under `/root/cm-database-completion-20261118/audit-search-v3/evidence/`. Go `/root/cm-nfs-multislot-20261105/tools/usr/local/go/bin/go`, environment `env -u GOROOT GOTOOLCHAIN=local CGO_ENABLED=0 GOMAXPROCS=2 GOPROXY=off GOSUMDB=off GOMODCACHE=/root/cm-nfs-multislot-20261105/cache/mod GOCACHE=/root/cm-nfs-multislot-20261105/cache/build`. Tests/builds only54. Development capacity uses only dedicated marked33337. Native8 uses general marked33317 and reserved Redis DB15 source33318→33320 plus isolated MinIO33319; private credentials are loaded in `audit-search-v3/run_backup.py`, never printed.

- `go run ./cmd/audit-search-diagnostic`: `query-shape-diagnostic.log`; raw diagnostic source retained in independent sandbox. Full migrations, synthetic900k seed, original count variants, plans and timings; no claim of source backfill.
- `go run ./cmd/audit-search-diagnostic cm_audit_diag_1794947475049501366 collation`: `collation-diagnostic.log`; discarded diagnostic only.
- `go run ./cmd/audit-search-cover-diagnostic`: `covering-count-diagnostic.log`; actual plans/EXPLAIN ANALYZE plus20 samples for separate and complete COUNT. Diagnostic schema only.
- Original production code: `CM_AUDIT_DEVELOPMENT_DIAGNOSTIC=1 go test ./internal/repository -run '^TestDevelopmentAuditSearchThreshold$' -count=1 -v -timeout=3m`: `repository-search-red.log`, exit1/36.988s,30day772.254556ms against500ms. The temporary test is retained only in sandbox and explicitly uses synthetic reports; it is not part of application source.
- Changed production code: `TEST_DATABASE_MYSQL_PORT=33337 CM_AUDIT_DEVELOPMENT_DIAGNOSTIC=1 go test ./internal/repository -run '^TestDevelopmentAuditSearchThreshold$|^TestAuditSearchCountMatchesOriginalSubstringPredicate$|^TestAuditSummary' -count=1 -v -timeout=4m`: `repository-search-green.log`, exit0/44.100s, complete actual30/90day method metrics above; full-schema semantic and existing audit summary/cursor/concurrency cases also pass.
- `go run ./cmd/capacity-pending-diagnostic`: `pending-join-diagnostic.log`, exit0. Retained v2 owned database `cm_database_test_1794946418032154124` on33327, original/bounded EXPLAIN, four mismatch retention assertions and exact500 commit. No other database touched.
- `TEST_SYSTEM_BACKUP_MYSQL_PORT=33317 UPDATE_SYSTEM_BACKUP_SCHEMA=1 go test ./internal/systembackup -run '^TestSchemaContractMatchesFreshMigrations$' -count=1 -v -timeout=2m`: `schema-regenerate.log`, exit0/5.195s. No schema.json diff.
- Built current independent `bin/system-backup-artifact` on54, exit0, for actual native verification.
- Final native8: `go test ./internal/systembackup -run 'TestWholeBranch|TestSchemaContractMatchesFreshMigrations|TestAuditTriggerCaptureAllowlistAndInertRestore|TestMonthlyCaptureRejectsUnregisteredAndFreezesCatalog|TestTeamDataMonthlyNativeSchemaRestore|TestTeamHistoryNativeBundleRestoresMonthlyObjectsAndImmutableKey|TestObservationNativeProofAndExpiredSnapshot' -count=1 -v -timeout=5m`; `final-native.log`, actual runner exit0, PASS113.889s,8leaf/0SKIP/0FAIL.
- Final same-source race: `CGO_ENABLED=1 TEST_DATABASE_MYSQL_PORT=33337 go test -race -p=1 ./internal/repository -run '^TestAuditSearch|^TestAuditSummary|^TestAuditErrorPreview' -count=1 -v -timeout=5m`; `final-race.log`, actual runner exit0, PASS22.044s,17leaf/18PASSentries/0SKIP/0FAIL/0race warnings. This includes the final minor test-helper parameter correction; production code is identical to the measured GREEN. Ordinary covering44.100s likewise17leaf/18PASSentries/0SKIP/FAIL; overlapping runs are not summed as distinct scenarios. Parsed names/counts/package durations/rawlog hashes: `evidence/final-summary.json`.

## Provenance and remaining parent work

Manifest `/tmp/cm-database-audit-search-v3-source.sha256` (remote `evidence/source.sha256`) SHA256 `a9565f20c3609517482dbcee919e12f6f0f4ce25a0f8dcd74442f7ba3c97a76a` covers the six changed source files plus unchanged generated native schema. This is a changed-file/contract subset, not a replacement for the parent's full frozen inventory. Source differs from v2 intentionally; never claim current product source is the old4b5053 manifest. Parent retains v2 failure/aborted setup evidence and will freeze v3 only after independent review, then rerun complete backend/race and actual900000-source production-CLI capacity. Parent explicitly waived repeating that same12–15minute final capacity command before freeze once full-method diagnostic/semantics/native/race evidence is complete. No current full-source capacity PASS is claimed here.

Final native output:

```text
final-native.log exit 0
--- PASS: TestAuditTriggerCaptureAllowlistAndInertRestore (11.08s)
--- PASS: TestWholeBranchNativeRestorePreservesRetiredPublicIDFloor (12.93s)
--- PASS: TestMonthlyCaptureRejectsUnregisteredAndFreezesCatalog (0.87s)
--- PASS: TestObservationNativeProofAndExpiredSnapshot (35.39s)
--- PASS: TestSchemaContractMatchesFreshMigrations (6.23s)
--- PASS: TestTeamDataMonthlyNativeSchemaRestore (12.89s)
--- PASS: TestTeamHistoryNativeBundleRestoresMonthlyObjectsAndImmutableKey (15.70s)
--- PASS: TestWholeBranchFullSchemaArchiveMonthlyNativeRestore (18.77s)
ok clawreef/internal/systembackup 113.889s
```

No further product edits after the final source manifest. General33317/DB15 and audit33337 are released to parent after successful completion; the intentionally retained diagnostic schema on33337 and the original capacity schema on33327 are not deleted. No focused test process remains. Independent review has the full patch and evidence, and parent will own final freeze/acceptance.

Independent focused review now **PASS**, no confirmed Critical/Important: `/tmp/cm-database-final-performance-rereview.md`. Reviewer directly read source, final logs, plans, receipt assertions and independently checked final hashes. This closes the implementation/covering/native/race gate; it deliberately does not substitute for root's final actual-source capacity acceptance.
