# Legacy production-scale resume fixture correction — 2026-11-18

DONE: the original production-scale test failure was reproduced on54, then the test-only correction passed normally and with `-race`, exercising both actual empty-queue and persisted-remainder cold-start paths. Only local `ClawManager/backend/internal/ownerrecords/sync_resilience_mysql_test.go` was edited. No product source, production/test budget, input population, frozen final tree, or frozen manifest was changed; no commit was made. All Go/gofmt execution occurred only on54.

Current local and54 test-file SHA-256: `e586c8175e3cf4dc5100acbe0eb030f16ddb54e79b621ee149be9c97df5d7777`.

## Original failure and baseline

Root's unchanged v4 broad legacy run reported `restart did not reduce persisted pending work 0 0`. The preceding real full production-scale phase had already completed all1000 owners within its original budget, leaving zero pending dates. The unconditional `remainingAfterRestart >= remaining` then rejected a correct empty restart because `0 >= 0`.

The complete ownerrecords directory was unchanged from baseline `acf8665a` before this task. The original test file is byte-identical to that baseline, SHA-256 `6e5ff5fc0b6f7f2a89022df1ba0e55b4b5d2c3d8c588d92ac3eddd8e6932fcf0`. Product `dirty.go` remains `f5624d612d841e2d4e1cc874dca1d525222d79f61b760307162fd15d7ec1360c`; `sync_budget.go` remains `088ba64e2b47e580fbcf200d830fdbaaec85f8770978dfa0915797fbabdde46b`.

Independent original-source RED on33347 reproduced the same failure (exit1, package13.810s). Its projection log showed `owners=1000 processed=1000 remaining_dates=0 elapsed=11.245220954s`; it then failed exactly at the original0-versus0 assertion. This is a test throughput assumption, not evidence of a product recovery or accounting failure.

## Corrected contract

The entire test prefix through the original full projection phase is byte-identical to the old source. The3200 instances,1000 owners,10000 initial calls, original late50-token call,100000/100050 token checks, coverage/replay checks, full-phase progress check, `syncSourceBudget`, and `syncProjectionBudget` are preserved. Cold workers still have the original3-second context limit.

The revised tail uses real production queue operations:

1. Each cold resume instantiates a fresh `Store{Session: s.Session}`. If pending work exists, the pending count must strictly decrease and at least one owner must be processed. Allowed deadline/yield behavior is unchanged. Every resume verifies source-accounting tokens remain exactly100050.
2. A finite loop, bounded by the starting pending count plus1, uses those same3-second cold workers until the old remainder is explicitly zero. No queue is cleared or rewritten to claim completion. Strict decrease prevents a stalled worker from consuming the loop bound silently.
3. After zero is established, an unconditional additional cold worker must return without error, keep pending count0, process0 owners, and leave both total record count and summed record versions unchanged. Thus a fast full pass is accepted while a supposedly idle worker that requeues or reprocesses completed work fails.
4. To prove restart recovery independently of machine throughput, the test calls the real `markUsageDay` entrypoint for41 existing owner/date identities. No instance, source call, owner, or token is added. The old queue is already empty, so exactly41 persisted pending dates must exist.
5. One real bounded `processDirtyPass`, which selects at most40 dates, must leave exactly1 durable pending date. A fresh cold worker then strictly advances that work to zero, using the same finite-loop rule and original3-second limit. Another unconditional empty cold worker proves no requeue, reprocessing, row drift or version drift after recovery.

No sleep, artificial slowdown, shorter production work selection, cleared backlog, fake in-memory queue, expanded production budget, or conditional empty-path skip is used. The original final100050 source-token assertion remains, and is also checked after every individual cold resume.

The first review correctly identified that merely adding a conditional idle check could skip empty-path validation on slower machines and mix old pending work with the41 markers. The final implementation consumes and validates every resume result, explicitly drains the old queue, and makes both idle validations unconditional.

## Actual path evidence

Both final ordinary and race runs logged all these states:

```text
projection_scale owners=1000 processed=1000 remaining_dates=0
projection_restart phase=idle-full-pass path=empty remaining_before=0 remaining_after=0 processed=0
projection_bounded_restart pending_before=41 pending_after=1
projection_restart phase=bounded-pass path=partial remaining_before=1 remaining_after=0 processed=1
projection_restart phase=idle-bounded-pass path=empty remaining_before=0 remaining_after=0 processed=0
```

The original full phase took11.19794161s in ordinary verification and16.846852292s with race instrumentation. No original phase budget or cold-worker limit was changed. Both real empty and positive-pending branches were executed, rather than inferred from a passing parent test. Multi-iteration slow-machine drainage is governed by the checked strict-decrease bound; no artificial slowdown was introduced to force extra iterations.

## Commands and complete retained attempts

Source sandbox: `/root/cm-database-completion-20261118/legacy-resume-fixture/ClawManager/backend`, copied from unchanged frozen v4 before editing its one test. Each invocation creates/drops its own timestamp-named schema through the existing fixture on private legacy33347. No package-wide suite was run.

```sh
env -u GOROOT GOTOOLCHAIN=local CGO_ENABLED=0 GOMAXPROCS=2 \
  GOPROXY=off GOSUMDB=off \
  GOPATH=/root/cm-nfs-multislot-20261105/cache \
  GOMODCACHE=/root/cm-nfs-multislot-20261105/cache/mod \
  GOCACHE=/root/cm-nfs-multislot-20261105/cache/build \
  NB_KEYS_TEST_MYSQL=127.0.0.1:33347 \
  /root/cm-nfs-multislot-20261105/tools/usr/local/go/bin/go test \
  ./internal/ownerrecords \
  -run '^TestSyncResilienceMySQLProductionScaleSource$' \
  -count=1 -timeout=5m -json
```

Race uses `CGO_ENABLED=1` and `go test -race`, with the same final source and all other settings unchanged. Go race requires cgo; no local executable test or build was run.

| Attempt | Exit/result | Evidence filename |
|---|---|---|
| Original unchanged test | Exit1; original0>=0 failure;13.810s | `resume-red.jsonl` |
| Initial helper draft build | Exit1 before executing tests; corrected `int` helper argument to match existing `resilienceInt`'s `int64` | `resume-green-build-error.jsonl` |
| Intermediate first draft ordinary | Exit0;14.164s, actual empty+positive paths; superseded after review strengthened all-machine path coverage | `draft-resume-green.jsonl` |
| Intermediate first draft race | Exit0;22.184s; superseded for the same review reason | `draft-resume-race.jsonl` |
| Final ordinary | Exit0; test14.39s/package14.396s; no skips | `resume-green.jsonl` |
| Final race | Exit0; test21.09s/package22.108s; no skips or race warning | `resume-race.jsonl` |

Every raw command attempt and matching `.exit` is retained under `/root/cm-database-completion-20261118/legacy-resume-fixture/evidence/`. Intermediate source manifests are retained as `draft-*`; none of the failed or superseded attempts was silently overwritten. Root's broad v4 failure artifact is unchanged.

| Final/raw artifact | SHA-256 |
|---|---|
| Actual original RED `resume-red.jsonl` | `79201c54a4a06b347456e37d3a068b6591fb1fe6a6c3069346fcd70b31fa32d4` |
| Final `resume-green.jsonl` | `b54802766c157c8e9452d9d39c7ead50c17ad27f3663d758b5931e34abeb443d` |
| Final `resume-race.jsonl` | `de42c5770a86666504234aa4863717fe9522a7f9e9bc84f10971315050d0c560` |
| Final1878-file `green-source.sha256` | `3236846060b4313d5e8c9c25462c4623c1ae114f09c7c53b262d7576d5a26f1c` |
| `verification-summary.json` | `5ab7584c18abec95b3b84206e8baabb4aa24bffbc6ccdf2f64e6dc4180ae198b` |

`sha256sum -c` passed before race and after race. The1878-file `.go`/`.sql`/module comparison with frozen final confirmed the sole difference is `internal/ownerrecords/sync_resilience_mysql_test.go`; product source and budgets are identical. `verification-summary.json` checks exact RED reason, actual final partial+empty log states, no skips/race warning, exit statuses, unchanged original scale/full-phase source prefix and source-file difference. Local whitespace checking passes. Local raw copies are `/tmp/cm-database-legacy-resume-fixture-evidence/`.

These are targeted development results. Root owns integration, independent review closure and a new complete frozen final run; this task does not claim global final acceptance or mutate the old v4 evidence.
