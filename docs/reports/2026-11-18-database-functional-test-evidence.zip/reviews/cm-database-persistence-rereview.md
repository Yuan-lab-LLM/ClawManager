# Persistence/capacity F1–F5 independent re-review

Date: 2026-11-18. Repository: `ClawManager`, branch `database`, uncommitted changes over `71d723ac`. Inputs: the original five-finding report, both fix reports, current source and `/tmp/cm-database-completion-review-v2.patch`. Reviewed the actual current production paths rather than treating the reports as proof of closure. No repository edits, local executable tests/builds, commits, deployments or cleanup were performed.

## Verdict

**Spec: with one remaining fix. Quality: with fixes / not ready to merge this persistence wave yet.** F1, F2, F4 and F5 are closed within this review scope. F3's quota-release and bounded payload-retention functionality is present, but its promised exact cancellation identity check is incomplete under the production SQL collation.

Critical findings: none established. Important findings: one. No cosmetic findings.

## Important: F3 still accepts a different source identity under case-insensitive SQL comparison

Locations:

- `backend/internal/repository/team_dispatch_outbox.go:91`
- `backend/internal/historymaintenance/cancelled_outbox.go:21`
- Production collation: `backend/internal/db/migrations/120_add_team_outbox_cancellations.sql:8`
- Contrasting byte-exact replay check: `backend/internal/repository/history_outbox_receipt.go:29`

The new admission exclusion and cancellation-pruning query use `c.source_event_id=o.source_event_id` with the table's `utf8mb4_unicode_ci` collation. Their destination and message joins likewise have no byte-exact guard. This is weaker than the permanent cancellation writer and replay validator, which compare source identities as Go strings.

A concrete counterexample is the existing regression's retained last payload, except its receipt source is changed from `source-500` to `SOURCE-500` instead of to `wrong-source`. All other original proof/closure/age prerequisites remain unchanged. The new SQL predicates accept this different source, remove its outstanding count/bytes and authorize physical payload deletion. An enqueue replay of the original source subsequently rejects that same receipt as an identity conflict. Thus retention can destroy the remaining payload without a receipt matching the identity used by replay.

I verified the comparison on the isolated server54 MySQL fixture, using only read-only SQL. The fixture marker count was 1. This expression returned `1` for collation equality and `0` for byte-exact equality:

```sql
SELECT _utf8mb4'source-500' COLLATE utf8mb4_unicode_ci
         = _utf8mb4'SOURCE-500' COLLATE utf8mb4_unicode_ci,
       BINARY _utf8mb4'source-500' = BINARY _utf8mb4'SOURCE-500';
```

The reported existing tests cover a wholly different source and a payload hash mismatch; they do not cover a case-only identity mismatch. This finding does not assume that ordinary native cancellation itself manufactures bad receipts. It concerns the explicit fail-closed guarantee for unmatched/corrupt receipts that this fix and its regression tests claim to enforce.

**Required correction:** retain indexed identity joins, add byte-exact checks for the cancellation identity components used as authorization, and exercise case-only source mismatch in both real `CreateEventOutbox` admission and scheduled `Tick` payload retention. Keep the mismatched payload counted and retained, and leave all permanent receipts intact. Review destination/message matching consistently with the intended identity contract; do not fix this by weakening replay validation.

## Closure assessment and strengths

| Old finding | Status | Independent source assessment |
|---|---|---|
| F1: unpublished long WAL frame followed by shorter retry corrupts replay | Closed | `Journal.appendAt` writes the next four-byte zero sentinel with ciphertext, fsyncs both before publishing the current length, and reserves the sentinel in the physical capacity check. The new SIGKILL regression uses the actual shorter delivered control append, checks no unpublished-event resurrection and verifies reusable reservation. |
| F2: monthly rollback races source deletion | Closed | Rollback locks the month catalog before its deleted-source count and state mutation in one transaction. `deleteVerified` locks and rechecks active state in its deletion transaction. Save uses the matching Team → catalog → archive-evidence order; verification also owns the catalog row. Both race directions have specific real-MySQL evidence. |
| F3: cancelled work permanently consumes pending quota and retains payload | Partially closed | Proven cancellations now leave outstanding count/bytes; cancelled payloads have their own retention path under the existing gate and shared 500-row Tick budget. It preserves cancellation receipts, requires deleted-Team closure, and does not invent delivery. Exact source matching remains incomplete as above. |
| F4: body/orphan proof has no production writer | Closed | The actual `system-backup-artifact --operation record-observation-restore-proof` entrypoint authenticates the published artifact and invokes complete isolated native verification before opening source/control connections. Private in-memory verified identities cannot be supplied by deserializing a report; Team-only backup cannot authorize this path. Source/control must identify the same physical database, the source must match the signed origin, and each batch takes serving-gate admission. Object identities use byte-exact owner/key/hash checks. The runbook documents concrete source-side execution and grants. |
| F5: valid body expiry breaks the next native backup | Closed | Signed SQL inventory authenticates exact field release plus object identity and recovery/proof metadata. Canonical expired references remain preserved and are omitted only through that evidence; missing live references still fail. SQL-string archive fields are parsed, ordinary known body plaintext stays opaque, and object traversal retains explicit item/byte/depth bounds. |

The F4/F5 extension also closes the requested adjacent lifecycle gaps: GC commits logical release and outgoing edge release before remote object deletion; a pending physical purge is retryable after a lost delete acknowledgement; a newer registration extends retention under the same row lock. Active archive roots and indexed child edges hold only their real dependencies. Unknown legacy roots fail closed for the owner's objects until authenticated inventory completion; completeness markers distinguish verified zero-child archives. New archive indexing locks the parent and child identities before releasing the reference to its caller. Migration 122 is included in native history classification and schema-contract evidence.

The F4 production command is an operator path, not a newly scheduled recovery drill. That is consistent with the original requested remedy, which explicitly allowed a concrete operator entrypoint. Rollout still must supply the documented source writer/control credentials and invoke the command after an isolated restore. Likewise, logical deletion in a versioned source bucket creates a delete marker; it does not automatically reclaim noncurrent ciphertext. The report/runbook now explicitly distinguish those facts and provide a disabled, prefix-scoped lifecycle template rather than silently altering customer storage policy.

## Verification evidence and limits

I read the relevant test implementations and directly inspected existing server54 log tails, including:

- `/tmp/cm-persistence-f1-f3-final.jsonl`: final repository suite passes; fix report inventories 24 passing cases across its covering command.
- `/tmp/cm-persistence-f1-f2-race.jsonl`: WAL and both monthly interleavings pass under the race detector.
- `/tmp/cm-object-proof-final.log`: native history/schema/proof suite passes.
- `/tmp/cm-object-proof-physical-final.log`: expanded native proof/expiry test passes, including real versioned-object observations.
- `/tmp/cm-object-proof-team-writer-final.log`: actual Team deletion archive/readback test passes.

These are reviewed existing execution evidence, not tests independently rerun by this reviewer. The only new remote check was the read-only collation comparison against the marker-owned fixture; no application data was touched. Local `git diff --check` returned success. Source review covered CLI wiring, gate/source identity ownership, object dependency and expiry resolution, WAL publication, month transactions, cancellation admission/pruning, and the associated tests. Separate query fixes and root E3 work were excluded except for their shared source/schema interfaces.

No claim is made that these focused tests prove total throughput at 10,000 active instances. This review verifies the persistence safety and bounded-work semantics in scope; full integrated capacity acceptance remains with the root agent. No new capacity tuning, weakened budgets, identity relaxation, silent drops or broad retention-policy changes are recommended.

## Residual F3 final re-review — closed

Date: 2026-11-18. This addendum supersedes the earlier F3 finding and the persistence-wave "with fixes" verdict above. **F1–F5 are now closed within the reviewed scope; no remaining Critical or Important finding in this persistence review.** The earlier F1/F2/F4/F5 assessments are unchanged. This is not whole-branch approval or integrated capacity acceptance; concurrent W1–W4 changes are outside this addendum.

I independently read the final five files listed in `/tmp/cm-database-cancellation-exact-fix-report.md`. Both admission and retention retain their ordinary indexed `(team_id,destination,message_id)` equality predicates and add byte-exact comparisons for destination, message ID, source event ID and payload digest. Retention additionally compares cancellation proof to native closure proof byte-for-byte. The canonical lowercase guard combined with the existing 64-hex-character validation rejects uppercase proof strings even when both proof columns have the same uppercase value. No normalization, replay relaxation, changed capacity threshold, removed gate or expanded deletion budget was introduced.

The tests exercise behavior through real entrypoints: `CreateEventOutbox` against 75,000 cancelled rows using production Unicode CI collation; seven independent actual `Service.Tick` mismatch cases, each followed by successful retention after restoring exact identities; and native Team cleanup producing 501 cancellations, with held-gate/recent-age refusal, a 500-row deletion batch, retention of `SOURCE-500`, and final deletion only after the exact source is restored. Permanent cancellation facts, absence of invented delivery facts, replay rejection and stale-callback safety remain asserted.

I inspected the actual RED, GREEN and covering JSON logs. The RED contains the expected 3 top-level and 12 subcase failures. The focused GREEN has 3 top-level plus 12 subcase passes. The covering run has 17 top-level plus 12 subcase passes, with no failure or skip. Evidence paths: `/tmp/cm-cancellation-exact-red.jsonl`, `/tmp/cm-cancellation-exact-green.jsonl`, `/tmp/cm-cancellation-exact-covering.jsonl`. These are reviewed existing server54 results; no test was rerun for this addendum.

All five current local file hashes match the report and `/tmp/cm-cancellation-exact-source.sha256` on server54. An independent remote `sha256sum -c` against the actual isolated tested source returned OK for all five files. The three remote log hashes also match the report. Local `git diff --check` returned success. Only this external review report was updated; no repository source, tests, data, commits or deployment state was changed.
