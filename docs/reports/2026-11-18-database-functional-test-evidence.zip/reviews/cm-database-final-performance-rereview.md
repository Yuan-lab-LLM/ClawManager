# Independent final performance correction re-review

Date: 2026-11-18. Scope: audit search COUNT/index, the synthetic query-capacity receipt loop, their semantic/capacity tests, and native restored-index coverage. This is a focused continuation of the earlier reviews; no previous closed gate is reopened without evidence.

## Verdict

**Focused code/semantics/native/race review: PASS. No new confirmed Critical or Important finding.** The corrections are ready for root's v3 freeze and final actual-source capacity acceptance. This is not a final performance acceptance: the development900k report fixture is explicitly synthetic, and the complete900k source→production CLI backfill→20-sample workload must still run on the final freeze. The original500ms/30-day and2s/90-day thresholds are retained and now asserted directly by the capacity test.

## Audit search equivalence

In `backend/internal/repository/observability_audit_reporting.go:135`, only the searched COUNT plan changes. Let A be the existing requested/actual model substring predicates and B the existing current username/trace/request/provider/event/message predicates. Original A OR B is counted as two disjoint populations, A and NOT A AND B, combined with UNION ALL and SUM. The model predicates still use LOWER(COALESCE(...,'')), so A cannot be SQL NULL; negation does not drop an unknown-valued row. Overlap across both models or other fields is counted once. COUNT always produces one row per branch, including empty populations, so SUM returns0 rather than an absent result.

I checked generated parameter ordering: each branch receives its own identical date/status/model/fence arguments; the first has two search arguments, the second has two model-negation plus six remaining-field arguments. The page query independently receives the original eight-field OR and unchanged keyset continuation. The copied count-argument slice prevents later page arguments from corrupting it.

Both branches remain inside the existing single read-only REPEATABLE READ transaction with readiness checks and the original sequence fence. Status/model/date boundaries, cursor filter binding, limit, error preview and ordering are unchanged. Username is still read from the current users row through LEFT JOIN in the remainder; a missing/NULL/deleted user does not exclude a model or other-field match. Renaming a user does not leave a denormalized searchable name.

The actual `/admin/ai-audit` route in `backend/cmd/server/main.go:1417` retains Auth, SetUserInfo and NewAdminAuth. Handler/service/repository request types expose Search/Status/Model/Cursor/Range/Limit, with no UserID/InstanceID filter dropped by this refactor. Owner-scoped history and trace routes are unchanged. The index therefore does not need invented owner/instance columns for this actual query.

`observability_audit_search_mysql_test.go` uses complete migrations and production source writers/reconciliation. Its independent original SQL predicate supplies the expected ordered trace IDs; the optimized method is traversed through every page and total. Coverage includes13 text cases, overlap, owner NULL/missing, username rename, Unicode, literal%/_, all original searchable fields, no match and combined status/model filtering. Existing cursor/fence/range and concurrent-source tests remain selected. No search field, literal substring semantics or case handling was removed.

## Index, plan and restore/rollback

The approved unreleased migration118 adds one secondary index at `118_add_audit_trace_reports.sql:20`:

`(sort_at, requested_model, actual_provider_model, sequence_id, id, status)`.

The model branch can satisfy all its conditions from that index. The remainder uses the same index condition to discard model matches before fetching message/current-user data. I directly read the diagnostic execution plan: the remainder's model-negation range returned0 for the declared all-model-match distribution and the users PK lookup was never executed. This explains that measured scenario's improvement; it does not establish arbitrary-term universal latency.

This is an additive index and query-plan change, without row conversion, authority change or persisted cursor format change. Older code can ignore the additional index. The new FORCE INDEX requires the revised schema: root explicitly authorized modifying this not-yet-deployed branch migration; this review does not authorize applying new code to an older already-migrated schema without that index. Missing-index errors are not silently replaced by incomplete results.

The54 fresh migration/schema regeneration passed5.195s. The unchanged schema.json reflects its existing columns/primary-key contract, not omission of a required secondary-index edit. `whole_branch_history_mysql_test.go:203` now verifies, after actual isolated native import/verification, that the search index exists with all six columns in exact order. Its complete native case and the remaining seven compatibility tests passed on the current candidate. No restore startup, read-only verifier, trusted schema or allocator boundary changed.

## Receipt-cleanup fixture correction

`query_capacity_mysql_test.go:115` changes only the two joins to STRAIGHT_JOIN and adds a comment. Source/fact ID, trace_id, invocation_id, estimated_cost and resolved=TRUE predicates, ORDER BY pending ID, LIMIT500, derived-table deletion and affected-row termination are unchanged. It constrains the confirmed pathological resolved-fact-first plan to pending primary-key order followed by cost/fact PK verification. This is only fixture setup; it does not change a product query or move setup time into/out of a measured request interval.

My prior independent live diagnosis is `/tmp/cm-database-v2-query-fixture-diagnostic.md`. The fixer's additional actual retained-v2-fixture probe checked four independently mismatched facts (trace, invocation, amount, resolved); each pending receipt remained. Exactly500 other verified receipts were deleted,558500→558000, in26.491563ms, with the original four fact values restored before commit. I read these raw assertions. No pending blanket-clear, trigger disable,500-limit relaxation or missing verification was introduced.

## Source identity and directly read evidence

Current subset/contract manifest `/tmp/cm-database-audit-search-v3-source.sha256` has SHA256 `a9565f20c3609517482dbcee919e12f6f0f4ce25a0f8dcd74442f7ba3c97a76a`. It contains the six changed/new files plus unchanged schema.json. I independently checked every local entry twice with exit0, including after final native/race completion; final output `/tmp/cm-database-audit-search-v3-review-hash-check.log`. This is not root's full freeze inventory.

Remote raw logs were read at `/root/cm-database-completion-20261118/audit-search-v3/evidence/`:

- `repository-search-red.log`: actual full repository method on explicitly synthetic900k report rows,20 samples,30-day P95=772.254556ms, failed500ms;90-day1.098556447s. Aggregate FAIL36.988s remains failure.
- `repository-search-green.log`: same complete repository method,30-day P95=362.95978ms and90-day1.057457207s; full-schema original-predicate equivalence and existing audit regressions PASS. Package44.100s. These are complete-method timings, not sums of separately timed queries.
- `covering-count-diagnostic.log`: independent plan and separate/combined COUNT timings support the mechanism; they are not substituted for the complete method or final source-backfill benchmark.
- `pending-join-diagnostic.log`: all four mismatch retention assertions and exact500 verified receipt deletion above.
- `final-race.log`: semantic search, cursor/fence/range, legacy/cold sources, concurrent/rollback projection and complete error-preview regressions PASS22.044s.
- `final-native.log`: eight actual native tests PASS113.889s, including full-schema archive/monthly restore18.77s with the new restored-index assertion, allocator12.93s, exact triggers/inert restore11.08s, frozen catalog0.87s, native proof35.39s, fresh schema6.23s, TeamData12.89s and encrypted TeamHistory15.70s.

Independent scanning of the final GREEN/race/native logs found0SKIP,0FAIL and0data-race warnings. Earlier v2 actual-source audit search30 P95=1.613602101s remains a failed performance criterion even though the old test process exited0; the new explicit assertions prevent that false acceptance. The stopped v2 query setup run also remains incomplete, not a pass.

This reviewer performed no builds, tests, product edits, database mutations, commits, deployments or test-process interference. Only source/report/log/hash reads and this review artifact were performed. No minor cosmetic changes are requested. Proceed with final full-source freeze, complete actual-source capacity rerun and its unchanged acceptance gates before claiming the task complete.
