# Read-only v2 query-capacity fixture diagnosis

Date: 2026-11-18. Scope: the still-running frozen-v2 `TestQueryCapacityTenThousandInstancesNinetyDays`, owned mysql-perf on server54/33327, schema `cm_database_test_1794946418032154124`. No source/test/threshold change, DDL/DML execution, process cancellation or interference with33317/33337 was performed. Only source reading, metadata/transaction/process inspection, plain EXPLAIN and a nonlocking pending aggregate were used. The owned database marker was verified present.

## Finding: current long phase is receipt cleanup with an unsuitable join plan

`backend/internal/repository/query_capacity_mysql_test.go:115` loops a receipt-backed DELETE in batches of500. Source creation and both cost facts/day materialization precede this loop. The20 product-query samples, their measured P50/P95, and `ANALYZE TABLE` follow it. Thus time inside this loop is fixture setup, not a measured product-query duration.

At UTC2026-11-17 20:31:28, the schema's active thread292 was executing exactly this DELETE; thread291 was sleeping. `information_schema.innodb_trx` showed RUNNING, `trx_wait_started=NULL`,2,338,799 locked rows and0 modified rows at that instant. This is active large work, not an observed lock wait/deadlock.

At UTC20:31:44.810145, actual nonlocking pending aggregate was:

- count566,000;
- minimum ID391676;
- maximum ID957675.

A preceding metadata snapshot estimated568,000 pending and895,104 cost facts. Other table estimates were stale (for example cost_records268,134) because the fixture's explicit ANALYZE occurs after cleanup; these are not asserted as exact current source counts. The active SQL/source order and approximately900k facts show the test has entered the100%-population setup cleanup, before that population's query samples. Parent-reported10%/30% P95 values remain actual earlier query samples; they must not be conflated with total elapsed setup time.

## Actual plain EXPLAIN comparison

The running/original DELETE is:

```sql
DELETE FROM observation_cost_pending
WHERE id IN (
  SELECT id FROM (
    SELECT p.id
    FROM observation_cost_pending p
    JOIN cost_records c ON c.id=p.id
    JOIN observation_cost_facts f
      ON f.id=c.id AND f.trace_id=c.trace_id
      AND f.invocation_id=c.invocation_id
      AND f.estimated_cost=c.estimated_cost AND f.resolved=TRUE
    ORDER BY p.id LIMIT 500
  ) verified
);
```

Observed original inner plan:

| Order | Table | Access/index | Estimated rows | Extra |
|---|---|---|---:|---|
|1|f|ref / idx_cost_fact_pending|447552|Using temporary; Using filesort|
|2|c|eq_ref / PRIMARY|1|Using where|
|3|p|eq_ref / PRIMARY|1|Using where; Using index|

The outer plan materializes at most500 selected IDs and deletes pending by primary key. However, the inner optimizer plan first considers a broad resolved-fact population and sorts matching pending IDs. Repeating this for every500 deletions rescans a large fact population hundreds/thousands of times; the500 result limit does not bound the work leading up to it. This matches the large transaction lock footprint and current elapsed setup behavior.

I issued only a plain EXPLAIN of a candidate with the two inner `JOIN` tokens changed to `STRAIGHT_JOIN`. All join conditions, verification predicates, ordering,500 limit, derived-table wrapper and DELETE target remain identical. Observed candidate inner plan:

| Order | Table | Access/index | Estimated rows | Extra |
|---|---|---|---:|---|
|1|p|index / PRIMARY|500|Using index|
|2|c|eq_ref / PRIMARY|1|Using where|
|3|f|eq_ref / PRIMARY|1|Using where|

The broad fact scan and temporary/filesort disappear; the outer materialized500/PK-delete plan remains. No candidate DELETE or EXPLAIN ANALYZE was executed. This is plan evidence, not a runtime speedup measurement or a capacity PASS.

## Minimal recommended correction for the sole fixer

Constrain these two joins with `STRAIGHT_JOIN` in this synthetic fixture loop only. Preserve every durable-fact equality, resolved=TRUE, ORDER BY p.id, LIMIT500 and affected-row termination check. This addresses the actual optimizer ordering without bulk-clearing pending, disabling hooks/readiness, raising limits, changing product SQL or relaxing acceptance thresholds.

After root finishes/classifies the current frozen run, the fixer should reproduce the plan on an isolated fixture and run the actual capacity test on the corrected frozen candidate. The100%20-sample query/cost measurements and all correctness assertions remain required. Current pending cleanup progress and EXPLAIN do not justify declaring an unexecuted100% query result or overriding the25-minute command timeout. The running v2 process was left untouched.
