# Whole-branch spec and quality review

2026-11-18. ClawManager `database`, base `acf8665a`, HEAD `71d723ac` plus current shared uncommitted implementation. Requirements read first: approved `docs/superpowers/specs/2026-11-17-database-capacity-remediation-design.md` and completion plan `docs/superpowers/plans/2026-11-18-database-remediation-completion.md`. Reviewed the current production source, supplied review patch/reports, original Q1–Q4 findings and fix report, and persistence F1–F5 re-review. This is a read-only code review; no application changes, tests/builds on this machine, commits or deployment. Remote actions were reading existing evidence and the cached MySQL driver's type-conversion source. The new reproduction cases below are source-derived and have not been executed by this reviewer.

## Verdict

**Spec: incomplete. Quality: not ready to merge.** Four Important findings remain in the integrated CM paths. None establishes a Critical security defect or confirmed destruction of production data. The monthly routing requirement is an unimplemented part of the approved design, not an approved scope reduction. Root confirmed no narrower monthly-mirror semantics were authorized.

Q1 and Q2's specific corrections close the original findings; Q4 closes the moving-window refresh defect. Q3's repository population validation is sound for the append-only facts reviewed, but a client path still bypasses it (W4). W2 independently identifies the same late-commit hazard outside Q2's audit-only queue.

The separate residual persistence F3 case-sensitive cancellation finding is already owned by another fix agent. Its correction was not supplied during this review and is not duplicated as a new finding. F1/F2/F4/F5 closure is supported by the preceding independent persistence review; that report remains the detailed authority for those paths. Runtime's isolated worktree and its pending protocol fixes remain root-owned review scope. Final frozen integrated tests and HTML acceptance report remain outstanding, as root explicitly stated.

## Strengths

- E3 has a concrete owned SQL boundary: Team-row lock, transaction-scoped repository, durable event/business receipts and cursor, original-envelope recovery, and fail-closed legacy watermark certification. The root integration correction leaves the three native outbox callers pending during projection and rejects accidental direct delivery through both the normal sender and reliable append helper. This addresses the confirmed rollback/Redis leak without manufacturing delivery or changing original business IDs.
- E4 admission uses encrypted physical WAL reservation before provider execution, durable event identities, permanent projection receipts, owner-bound encryption and verified body reads. Replay projects facts without calling the provider or the budget finalizer again. The reviewed gateway behavior distinguishes executed responses from delayed persistence.
- Query paths materially improve on the baseline: transactional daily rollups, fee identity, SQL filter/count and stable immutable audit sort, explicit 30/90-day windows, bounded Trace metadata and separately authorized bodies. Readiness failures and stale continuations are visible failures rather than silently partial successes.
- Redis admission and maintenance preserve pending/unread consumers, verify projection watermarks, retain durable dedup/closure evidence, and avoid time-only trimming. Deleted-Team cleanup records producer inventory, settlement, archived chunks and exact namespace progress. Backup changes retain native owner/identity and executable-object restrictions rather than replacing them with caller assertions.

## Important findings

### W1. Monthly cutover does not route actual serving reads or new log writes

**Locations:** `backend/internal/historymaintenance/reader.go:40`, `:101`; `backend/internal/historymaintenance/worker.go:378`, `:382`; `backend/internal/historymaintenance/monthly.go:310`; `backend/internal/repository/trace_page.go:150`; `backend/internal/repository/observability.go:325`.

`save` writes a reference copy into a UTC monthly table and a full locator/metadata row into the global `history_archive_records`. `VerifyMonth` changes the catalog state to `active`, but `Get` and `ListPage` still read only the global table. Trace cold metadata also reads that same global table. New invocation/audit WAL projection still inserts into the original fixed source table; ordinary legacy Create does likewise. Searching all production monthly catalog/table references found consumers in maintenance and native backup, but no catalog-controlled serving read or source-write routing.

This is useful verified archival, but it is not Task 3's registered monthly log write/read routing, cross-month serving cutover and rollback. The global high-cardinality history metadata remains the serving store and monthly tables add duplicate reference storage. A successful monthly verification currently changes deletion eligibility, not the query route.

**Reproduction/acceptance:** use full migrations, archive and activate a month, then trace actual SQL for authorized ID/detail, cross-month list, Trace and a new log write. The current paths never read/write the active month as their serving source. Implement the approved route with stable public IDs, late writes, bounded cross-month cursors, explicit cutover/rollback and native backup/restore compatibility; do not relabel reference mirrors as completed monthly routing.

### W2. Legacy invocation and cost transactions can commit behind permanent backfill watermarks

**Locations:** `backend/internal/repository/query_summary.go:110`, `:121`, `:125`; `backend/internal/repository/query_cost_summary.go:126`, `:137`, `:140`; contrasting audit-only queue: migration `121_guard_observation_reconciliation.sql:11`.

Invocation and cost maintenance select `id > after_id` and permanently advance the cursor to the largest visible ID. A lower allocated ID held by an old writer can commit after catchup passes a higher visible ID. Unlike `audit_events`, neither source has a transactional pending queue. A raw/old-version write bypasses the new repository summary hook. Further maintenance never visits the missed ID, and readiness remains true. Day rebuild cannot repair the hole: invocation rebuild reads existing summary facts and cost overview rebuild now deliberately reads receipted cost facts only.

The rollout explicitly supports coexisting old audit writers; the same old application also writes invocations/costs. An approved legacy import with lower explicit IDs has the same problem. New-version transactional Create is not the failing path. Invocation archival may eventually discover the omitted call after its online lifetime, but that does not make online reporting correct; costs have no equivalent archive recovery path.

**Reproduction:** after migrations, connection A begins and inserts a legacy invocation (or cost) with ID N but does not commit. Connection B inserts N+1 with a different trace and commits. Run actual maintenance through N+1. Commit A, run maintenance again, and check source vs session/admin/cost totals and CLI readiness. The N row remains unreceipted and omitted. Repeat with process restart and a lower-ID zero-token call. Add commit-visible catchup or an enforced old-writer cutover contract for both sources; do not treat AUTO_INCREMENT allocation as commit order or perform unbounded historical rescans.

### W3. Actual archive serialization breaks typed reconciliation and drops report fields

**Locations:** `backend/internal/historymaintenance/worker.go:276`, `:294`, `:298`, `:455`; `backend/internal/repository/query_summary.go:170`, `:184`, `:196`; `backend/internal/repository/observability_audit_summary.go:246`; `backend/internal/models/model_invocation.go:37`, `:39`.

Three related defects occur at the real SQL-to-archive boundary:

1. `scanSources` computes `Metadata` before converting `is_streaming` from SQL `int64` to JSON boolean for `Payload`. Thus ordinary model metadata contains `"is_streaming":0` or `1`, but archive reconciliation unmarshals it into `ModelInvocation.IsStreaming bool` and returns a type error. This blocks summary proof and source retirement. The cached actual MySQL driver on server54 confirms TINYINT is decoded as `int64` in both text and prepared-result paths (`packets.go:844`, `:1241`).
2. `tokens_per_second` is `DECIMAL(12,4)` in migration 056. The generic byte-to-string conversion serializes a non-null value as a JSON string in both metadata and payload, whereas the model requires `*float64`. Typed archive hydration and reconciliation then fail even after the boolean ordering is corrected.
3. `summaryMetadata` omits audit `message` and invocation `error_message`. If archival materializes a legacy row before hot backfill reaches it, the archive branch inserts a fact with an empty message/error. Later hot batches skip existing IDs; audit fact insertion uses `INSERT IGNORE`. They do not repair those omitted fields. The archive may receive `summary_verified_at` despite a report differing from the source. Full object bytes remain available, so this is not an allegation that the original body is destroyed.

Existing history fixtures define a simplified model table without `is_streaming`; summary/audit fixtures manually seed metadata that omits the problematic type or already includes the missing message. Those tests do not execute the real integrated boundary.

**Reproduction/acceptance:** use full migrations and actual model/audit repositories or legacy SQL rows; archive through real `Backfill`/`Tick`, reconcile through real workers, then typed GetByID/Trace/history hydration and native restore. Include streaming true and false, non-null decimal throughput and null, long error, audit-only message, and a row beyond the first 500 hot-backfill IDs. Normalize source types before generating either JSON representation; preserve all fields needed for durable reports and verify materialized values before writing summary proof. Verify all applicable archive kinds, not only hand-authored metadata.

### W4. Instance pagination can bypass the new population guard while a page is loading

**Locations:** `frontend/src/components/InstanceSessionUsagePanel.tsx:149`, `:477`, `:493`; backend fallback at `backend/internal/repository/observability_session_reporting.go:232`.

The instance panel keeps Next/Previous enabled while its request is loading. `loadUsage` sends `pageCursors.current[requestPage]` without requiring it to exist. With at least three pages, click Next from page 1, hold page 2's response, then click Next again. No page-3 cursor has been learned, so the second request has `page=3` and no cursor. The backend intentionally interprets that as OFFSET pagination and does not run a continuation population comparison. The generation guard discards page 2's response, including a possible `409 cursor_stale`.

If a delayed in-window call changes session ordering between these requests, this path silently skips or repeats rows while appearing to continue the original chain. It bypasses the exact correctness guarantee introduced by Q3; it is not merely a loading indicator issue.

**Regression/fix:** delay the page-2 response, attempt a second Next, and introduce an in-window late event. Require either only the valid cursor request followed by visible 409, or blocked navigation until the predecessor response supplies its cursor. Navigation must not manufacture a missing continuation using OFFSET. Cover both session/admin controls; the instance control is the confirmed persistent exposure.

## Q1–Q4 independent gate

| Finding | Gate | Current source assessment |
|---|---|---|
| Q1 rebuild double count | Closed | Overview rebuild now selects receipt-backed ledger IDs; shared source/day fences precede actual INSERT, exclusive rebuild fence spans replacement and commit. Fixed slots bound lock metadata and ordinary writers share the fence. |
| Q2 late audit-only rows | Closed for original audit case | Exact AFTER INSERT trigger commits a pending ID with the old source transaction; drain has no high watermark, initial catchup removes only processed queue IDs, and serving readiness refuses pending facts. Native capture trusts only the exact trigger contract; isolated restore omits executable hooks. W2 separately covers unprotected invocation/cost sources. |
| Q3 mutable session/admin ordering | Repository fix closed; end-to-end gate open | Same repeatable-read request compares population count/totals and metadata membership with cursor state and returns explicit 409 for changed ordering. It is correctly described as version-checked continuation, not retained cross-request MVCC. W4 bypasses continuation by issuing a cursorless non-first page. |
| Q4 refresh freezes upper bound | Closed | Refresh advances the bounded window, resets cursors/page, invalidates old requests and reloads selected detail. First-page auto-refresh and visible older-page pause preserve the chain. |

## E3 integration correction assessment

Read `team_projection_atomic.go`, `team_projection.go`, `team_service.go` changed native callers and `team_redis_capacity.go`. `createRootCoordinationRecovery`, dependency reminder and leader-mediated result notification leave native SQL obligations pending when `commandHook` is present. `deliverTeamEventOutbox` and `xAddReliableOnce` independently refuse precommit delivery; queued non-native command obligations remain in the SQL projection transaction. Postcommit sender uses durable reliable append identity. This closes the reviewed root rollback leak; no new finding was established in this correction. Source receipts, legacy audit and committed-watermark conditions remain intact.

I read existing server54 `root-projection-bridge-green.jsonl`; its final services result is PASS (17.658s), including real managed-bridge/source-proof behavior. This is reviewed execution evidence, not an independent rerun.

## Evidence inspected and limits

- Existing query final source-fence log: repository PASS 13.742s, gateway PASS 0.316s. The earlier `query-review-final-functional.log` includes the documented gateway fixture SQL-comment split failure; its later dedicated result, not that failed log, is the gateway closure evidence.
- Existing query UI final log: both real rendered admin and instance routes PASS against explicitly mocked APIs, including moving windows, cursor chain, 409/export refusal,503 retry and mobile. W4's delayed predecessor/double-next case is not covered there.
- Existing query capacity log: PASS 300.910s for declared synthetic 10,000 instances/90-day fixture. Fix report records admin100% P95 1.791633s, single-instance session 9.834ms and Trace 10.501ms. These are the supplied measured workload results, not production throughput or proof of arbitrary cardinality/distributions. Final frozen-source rerun remains root-owned.
- Existing native-backup final log: PASS 117.541s including complete six-part Team capture and isolated SQL/object restore with unrelated AI exclusion and corruption refusal. The missing full-schema archive-to-summary integration is precisely why W3 was not caught by those separate positive tests.
- Existing persistence independent review closes F1/F2/F4/F5 and retains F3's byte-exact cancellation issue. No code-review pass is inferred for the pending F3 or Runtime updates.

The architecture is substantially improved, but same-source focused suites do not prove complete integrated serving behavior. Before final acceptance, the four findings need concrete regressions and independent re-review, then the frozen combined functional/race/native restore/browser suite and requested standalone HTML report. Keep the raw budget ledger, request/owner identities, recovery holds and native Runtime upgrade boundaries unchanged.

## Minor

No cosmetic findings promoted. The report concentrates on material behavior and approved-scope completion.
