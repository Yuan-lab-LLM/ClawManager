# Whole-branch W1–W4 independent re-review

Date: 2026-11-18. ClawManager `database`, HEAD `71d723ac` plus the current uncommitted implementation. Reviewed `/tmp/cm-database-whole-branch-rereview.patch`, the current files, `/tmp/cm-database-whole-branch-fixes-report.md`, the approved design/completion requirements and the previous four findings. The complete supplied backend/frontend source manifest verifies locally with exit0: `/tmp/cm-database-whole-branch-source.sha256`, manifest hash `51403dbbe04019676592ed356e1bb210113ea6bcc0101a2fc019fbf217d5a8e2`; verification output is `/tmp/cm-rereview-source-check.log`.

No repository files, application resources, commits, deployment or Runtime images were changed. No tests/builds were run by this reviewer. Remote commands read existing execution logs. New findings below are source-confirmed with concrete proposed regressions, not newly executed test results.

## Verdict

**Original W1–W4: closed for their reported defects. Whole branch: still not ready to merge; three new Important monthly budget/registration defects require correction. Critical: none established.**

The original monthly-mirror gap is now materially corrected: five observational kinds have actual transactional month writes, catalog-controlled serving, old-ID resolution and operational backfill/verify/cutover/rollback. This is an explicit gray dual-write design retaining native allocators, compatibility sources and rollback copies; it is not physical database isolation or an exclusive write cutover. Original financial cost records remain authoritative and are not put through archival deletion.

The remaining issues concern resource safety, maintenance progress for valid larger historical rows, and first-month registration concurrency. Neither requires weakening the 8MiB limit, deleting pending work, changing business/owner identity, or touching core budget/Runtime upgrade protocols.

## Original finding gates

| Finding | Re-review result | Independent current-path assessment |
|---|---|---|
| W1 month mirrors did not serve | Closed, with new bounded-work findings R1/R2 below | `WriteLogBatch` is reached by repository/WAL inserts and actual reconcilers. Registered month rows hold canonical payload/metadata, with native IDs and narrow location lookup. `MonthlyGet`, `LogDetails`, archive list/export and Trace metadata now select active catalog routes in read-only repeatable-read transactions. Missing/corrupt active routes or committed pending legacy work fail visibly. CLI commands perform bounded bidirectional verification and explicit route cutover; rollback returns route authority only while source copies remain intact. |
| W2 lower-ID late legacy invocation/cost commit | Closed | Exact INSERT triggers now cover invocation and cost as well as audit; chat/risk have their own queues. Catchup unions committed queue IDs with the bounded forward source window, never decreases the watermark, and clears processed IDs in the projection transaction. Serving readiness also checks pending queues. The original lower allocated ID / later commit case has real two-connection RED/GREEN evidence. |
| W3 SQL/archive type and field fidelity | Closed | `scanSources` normalizes SQL BOOLEAN and DECIMAL before producing both representations; canonical payload LONGTEXT preserves decimal lexemes, with JSON metadata and checksum verification. Audit message and full invocation error are retained. Archive-generated typed facts now match the full production model, and duplicate summary proof checks report values instead of accepting a sparse identity subset. Full-migration tests exercise archive-first IDs501/502, typed Get/Trace, all applicable kinds and native encrypted restore. |
| W4 double Next bypassed population cursor | Closed | Both actual pages block navigation while loading and require a learned predecessor cursor; state updaters recheck cursor existence, and the request function refuses a cursorless non-first page. Returned next-cursor state is cleared before replacement. The browser regression holds page2, attempts a second Next and checks visible late409; no OFFSET continuation is sent. Q3 repository validation and Q4 refreshed-window behavior remain intact. |

Original Q1/Q2 and Q4 remain closed; Q3 now has both the repository population check and the previously missing UI continuation guard. E3's three native outbox deferred-delivery guards are unchanged and retain the prior closure.

## New Important findings

### R1. Monthly archive list loads all inline payloads before applying the 8MiB page budget

**Location:** `backend/internal/historymaintenance/reader.go:144` through `:171`, especially payload decode at `:157` and accumulation at `:163`.

The query now selects `payload_json` from active monthly tables. The first loop scans, decodes, canonicalizes and stores **every** `limit+1` row in `records`. Only the second loop applies `page.Bytes+r.Bytes > MaxPageBytes`. Each legitimate month payload may be nearly8MiB and the endpoint permits200 rows, so a request can retain roughly201×8MiB of payload plus temporary decode/canonicalization allocations before returning an8MiB response. This defeats the promised request-memory bound and can exhaust an application container.

This is reachable with valid source schema: legacy `model_invocations.request_payload`/`response_payload` are LONGTEXT and `log-backfill` can copy them into a registered month before body migration. The CLI can backfill and verify individual rows below8MiB and then activate the month; no corrupt row or quota bypass is required. Ordinary newer gateway externalization reduces typical sizes but is not a precondition enforced on this supported legacy path. The old object-only reader accumulated small metadata and fetched bodies only after the page-byte check, so the new inline serving branch introduces the over-allocation.

**Regression:** create a registered active month from valid legacy calls with, for example, twenty distinct ~2MiB inline payloads, using bounded backfill/verification batches. Query actual `ListPage(limit=200)` and export. Assert a bounded payload-read/decode working set, correct `HasMore`/`NextID`, and complete continuation over all rows. A row beyond the accepted prefix must not be eagerly decoded merely to discover it does not fit.

**Correction:** enforce cumulative payload bytes while consuming the SQL cursor, before decoding/appending the next payload. Prefer selecting bounded metadata/IDs before fetching large inline content where needed; allow only a bounded lookahead. Keep the response limit and exact continuation, and do not silently discard remaining rows.

### R2. A valid oversized aggregate batch permanently stalls automatic reconciliation

**Locations:** `backend/internal/historymaintenance/log_routing.go:117`; `backend/internal/historymaintenance/worker.go:329`; `backend/internal/repository/query_summary_batch.go:33`; callers `backend/internal/repository/query_summary.go:116` and `backend/cmd/server/database_maintenance.go:100`.

`WriteLogBatch` calls `scanSources(..., requireAll=true)`. If the selected rows together exceed8MiB, it returns `monthly batch exceeds8MiB; source/queue retained`. The enclosing transaction rolls back all progress. Actual background invocation/audit/chat/cost reconciliation supplies fixed batches of up to500 IDs and retries that same selection after failure; there is no byte-aware prefix selection or smaller-batch retry.

A deterministic, full-schema example is500 legacy model invocations with a20KiB `error_message` each, all inside a registered month. Each field fits the real TEXT column and each row is individually far below8MiB, but the selected batch exceeds10MiB. `ReconcileObservationSummaries(...,500)` repeatedly aborts before inserting facts or advancing/clearing its cursor/receipts. `error_message` is not a body field handled by `MigrateObservationBodies`, so that worker does not resolve the condition. Readiness and active monthly routes can remain blocked indefinitely despite healthy SQL/storage and sufficient per-event capacity. Valid large LONGTEXT request/chat history can likewise stall until a separate body migration happens; correctness must not depend on that incidental order.

Earlier informal messages used a20KiB risk `match_summary` example; that example is explicitly withdrawn because production defines `VARCHAR(500)`. The model-error example above is valid under the actual migrations and is the required reproduction.

**Regression:** insert500 valid raw/legacy invocations with20KiB errors, register their month, and call the actual scheduled-size reconciler more than once. Require positive bounded progress, exact eventual500 facts/receipts, correct totals and complete preserved errors. Cover the shared batch consumers with variable body sizes and exact queued-ID settlement. An individual oversized row must remain an explicit blocker; a collection of individually valid rows must progress as smaller bounded batches.

**Correction:** choose/process a byte-bounded prefix or adaptively split/retry the selected IDs. Advance and acknowledge only the identities actually materialized; retain the remainder for subsequent calls. Do not raise the memory cap, clear unprocessed receipts, or require operators to manually lower every scheduled batch.

## Additional changes reviewed

### Native allocator floors

The additional native restore fix is correctly limited to seven enumerated monthly-capable source kinds. Capture records allocator floors in the authenticated SQL snapshot header; old snapshot fallback derives floors from native, monthly and archived stable IDs. Unknown source names, invalid/overflowing numeric identities and declared allocators without a matching native AUTO_INCREMENT column are refused.

Preparation validates the isolated restore database and trusted static schema, requires the relevant native tables to be empty, and applies generated identifier-quoted `ALTER ... AUTO_INCREMENT` only there. Import does not gain a DDL path. Verification reads `SHOW CREATE TABLE` through the existing read-only boundary and compares current engine state to the authenticated floor, avoiding cached information_schema statistics. Normalization preserves the header. Normal `cm_restore_*` service startup remains prohibited. I found no new trust/identity relaxation in these paths.

The actual regression retires highest source ID2 while retaining live ID1, captures/restores, verifies the floor and invokes the repository to obtain ID3. The current-source native log reports this case PASS12.74s, including deliberately primed stale metadata statistics. This supports the additional fix and does not substitute for root's final integrated acceptance.

### SSE terminal delimiter

`proxyOpenAIStream` now writes the terminal data line and its actual blank LF/CRLF delimiter before returning. Existing compatible EOF after a known terminal outcome remains accepted; no replacement bytes or removed response limit were introduced. The real streaming E4 dual-outage test verifies exact downstream bytes and raw persisted SSE through SQL/object failure, reopened journal and replay. No new Important finding was established in this correction.

### Persistence and Runtime boundaries

Read the final F3 addendum in `/tmp/cm-database-persistence-rereview.md`: all F1–F5 are independently closed, with byte-exact admission/retention identities, preserved permanent cancellations and real scheduled Tick evidence. Read the separate Runtime handoff re-review: its Critical/Important list is empty after the independent actual-handler, process-crash, ENOSPC and Redis-full recovery review. This report does not claim to have repeated that entire isolated Runtime review.

The E4 matrix report records4 leaf cases with ordinary/race passes, both gateway entrypoints, simultaneous actual SQL/object faults, owner/global admission and no repeat execution. Its budget settlement uses the declared counted test budget service, while durable costs/identities use real SQL. Native object/backup and process-SIGKILL coverage remain separately evidenced. The current root DLQ functional source covers receipt/object failures and group-registration race; its final frozen rerun is still a root acceptance task.

## Evidence and completion limits

I directly read current existing server54 tails:

- `whole-branch-fixes/evidence/final-native-green.log`: PASS107.369s;8 selected native tests, including full-schema six-kind archive/five-kind active routing and real SQL/encrypted object restore. Reported individual native allocator case PASS12.74s.
- `whole-branch-fixes/evidence/final-covering-green.log`: gateway PASS40.833s; maintenance package PASS0.015s; report records repository97.114s/history18.220s. Its `cmd/history-maintenance` entry says **[no tests to run]**, which is compilation coverage, not a functional case pass.
- `whole-branch-fixes/evidence/w4-final-browser.log`: actual admin and instance rendered routes PASS with the declared controlled API fixtures.
- Supplied source manifest verifies exactly against the current local source. The earlier failed native batch and general isolated fixture OOM are explicitly retained in the implementer report; neither is counted as a product pass.

The selected tests prove the original four fixes and new allocator/SSE behaviors for their cases. They do not cover R1's large cumulative reader allocation or R2's individually-valid/aggregate-oversized scheduled batch. No duplicate suites were rerun. Final frozen full package/race/native/browser and900k capacity runs plus the standalone HTML report remain root-owned and are not claimed complete here.

## Assessment

**Ready to merge: No, with the three corrections in R1–R3.** The approved functional routes now exist, and original correctness findings are closed. Complete the new boundary regressions and independent re-review before final whole-branch acceptance. No cosmetic changes requested.

## Addendum: R3 first-registration race independently reported during review

Root relayed the sole fix owner's newly identified catalog-registration interleaving while this report was being finalized. Current-source inspection confirms it; the owner's deterministic RED was still in progress at this report boundary and is not represented as executed evidence here. **This adds a third Important finding and supersedes the two-finding count above. Original W1–W4 closure and the not-ready verdict are otherwise unchanged.**

**Locations:** `backend/internal/historymaintenance/log_routing.go:56`, `:78`, `:123`; source receipt clearing in `backend/internal/repository/observability_audit_summary.go:63`, and equivalents for other kinds.

`WriteLogBatch` takes an ordinary catalog snapshot. If there are no month registrations it returns nil; if this source month is absent it skips that row and returns nil. The caller then clears its pending receipt in the same still-uncommitted source transaction. No shared catalog row/gap ownership protects the observed absence against first registration.

**Interleaving:** source transaction A inserts lower IDN, observes no registration for its month, skips the month copy and clears its pending receipt, then pauses before COMMIT. Another connection registers the month, backfills/verifies/cuts over the committed source population (which may include higher IDN+1). A subsequently commits. Its source row now belongs to an active monthly route, but its month row/location and pending receipt are absent. Monthly serving hides the fixed source by active-route predicates; the committed row is silently absent from lists and its ID read fails. A permanent forward summary watermark can already be aboveN.

**Required correction/regression:** serialize source month-routing decisions with first registration, including missing catalog entries, or retain a commit-visible receipt until monthly materialization is proven. Do not merely add another nonlocking readiness check. Exercise actual source/WAL or repository insert, held precommit writer, independent prepare/backfill/verify/cutover and final commit; assert exact row visibility and receipt state for each relevant kind. Root is consolidating this with R1/R2 into the same fix wave.
