# Query review Q1–Q4 fixes

All four Important findings implemented in the shared ClawManager working tree; no commit, deployment, Runtime upgrade, or application-data operations. Local work was source/document editing, gofmt, git/digest checks and image inspection only. Execution/builds used root@10.130.81.54, checkout `/root/cm-database-completion-20261118/query-fixes`, marked disposable fixtures. Parent owns the final frozen integration suite, independent review and full functional HTML report.

## Changes and boundaries

**Q1.** `rebuildCostDay` now rebuilds overview rows only from ledger IDs already receipted in `observation_cost_facts`. Migration121 adds 256 preseeded `observation_summary_day_locks(day_slot SMALLINT UNSIGNED PRIMARY KEY)` rows. Ordinary legacy/WAL source writers and bounded invocation/cost reconciliation acquire shared day fences before source/fact insertion; a day rebuild holds the corresponding exclusive fence until commit. Reporting acquires no fence. Days256apart share a repair slot, so a repair can delay those writers; ordinary writers do not serialize on this shared fence. Exact and legacy fee associations and explicit mixed-currency rejection remain intact. Source timestamp precision crossing midnight is covered by pre-insert leases for the adjacent second. The final Create-before-source regression caught and fixed the last source INSERT/day-fence inversion.

**Q2.** Migration121 adds `observation_audit_pending(id BIGINT PRIMARY KEY)` and the exact `observation_audit_enqueue` AFTER INSERT trigger on audit_events. The queue commits with raw old-version inserts, including a lower allocated ID committed after initial catchup. New-version transactional projection removes its queue row in the same transaction. Maintenance continues draining <=500 committed IDs without a monotonically advancing queue cursor or repeated historical sweeps. Initial audit backfill removes only its exact processed IDs from the queue. Missing hot rows can be settled after their existing archive materialization. Serving/CLI readiness checks pending entries and refuses a partial successful report.

The queue is registered as history/mysql_dump/normalize; lock slots are internal metadata_only/reference_only. Fresh schema.json includes migrations121 and122 (122 is persistence-agent-owned). Backup source executable validation permits only the exact trigger name, INSERT/AFTER/audit_events/ROW attributes, current database, current-account definer and full whitespace-normalized single INSERT body. Unknown/changed triggers, routines and events remain rejected. Isolated restore schema generation omits this trusted trigger; RestoreMySQL still refuses every target executable object, so imported audit rows cannot execute hooks or manufacture queue entries. Capture using a different definer account is deliberately rejected, not silently trusted.

**Q3.** Session/admin cursors now carry a population version receipt: eligible invocation count (including zero-token events), session/token/cost/currency totals and order-independent SHA256 membership receipt for instance names/identity or session IDs/titles. Each comparison and page run in the same repeatable-read snapshot. Frozen-window changes, including backdated lower-ID late commits, fail with HTTP409 `cursor_stale` and explicit refresh/restart instructions; they never return an apparently complete page or partial successful CSV. Ordinary events after the frozen Until and hot-to-cold movement do not invalidate it. Metadata/search changes also invalidate it. This is **version-checked continuation with explicit restart**, not a retained MVCC result snapshot. No raw AUTO_INCREMENT commit-order claim, global read lock, result cap or UI sort change was introduced. Trace/cost existing ID-fence behavior was not expanded into a strict commit-order snapshot claim by this fix wave.

**Q4.** Manual refresh and first-page auto refresh open a current time window and reset cursor/page state; previous/next preserve the current chain. Auto refresh pauses on older pages with visible text explaining that Refresh returns to current results. Same-second explicit refresh still reloads. Request generations prevent an older in-flight response overwriting new results. Selected session detail uses the refreshed bounds. Filters/time range/instance changes reset cursor scope.409 prevents CSV download;503 remains retryable. The previously unused InstanceSessionUsagePanel now has real entry points in existing lite/pro instance details, default collapsed; existing owner authorization remains in the endpoint. Shared collapsible header wraps on narrow screens so controls are not clipped.

## Regression evidence

Evidence directory: `/root/cm-database-completion-20261118/evidence/`.

- `query-review-red2.log`: Q1 original USD2/count1 became USD4/count2; Q2 audit-only late writer and held lower-ID commit both disappeared; Q3 session/admin continuations silently returned no remaining item after reordering.
- `query-review-ui-red2.log`: moving clock + manual Refresh never displayed new facts on the real built admin route.
- `query-review-trigger-red.log`: old strict source validator rejected migration121's trigger. Follow-up exact allowlist and inert restore checks passed; unknown/modified trigger bodies remain rejected.
- `query-review-create-fence-red.log`: original source writer inserted a raw ledger row while waiting on a rebuild day fence; NOWAIT probe returned3572. Final source hooks move the shared fence ahead of INSERT.
- `query-review-functional3.log`:7 focused cases PASS3.973s: initial rebuild-before-receipt, both concurrent rebuild/backfill orderings, replay, late legacy audit commits, mutable session/admin order, actual lower-ID zero-token transaction committed after pageone then projected by the actual maintenance path, cold removal and outside-window continuation.
- `query-review-final-functional.log`: repository PASS72.636s and handlers PASS0.025s. Includes metadata membership invalidation, pending-audit readiness, existing exact/legacy/currency/session/cost/Trace/audit/durable regressions. The gateway fixture in this first multi-package run failed because its new selective DDL loader split a SQL comment containing a semicolon; follow-up fixture strips comment lines and uses utf8mb4_unicode_ci like production.
- `query-review-gateway-final.log`: real gateway executed-result/SQL-outage/restart regression PASS0.790s.
- `query-review-auth-services-final.log`: handlers PASS0.025s, services PASS0.020s. Includes explicit wrong-owner refusal for both instance usage list/detail, existing instance/admin/detail/fee aggregate service cases, archive owner/body boundaries and409 response mapping.
- `query-review-trigger-green.log`: strict trigger/source-schema, fresh121/122 contract and full-schema Team restore PASS31.057s.
- `query-review-native-backup-final.log`: strict trigger checks, full-schema Team SQL restore, monthly native restore and native six-part Team capture/publish/isolated SQL+object restore PASS117.541s; hydrated bodies retained, unrelated AI object excluded, tampering refused. Source Redis33318/DB15; isolated target33320/DB15 was explicitly authorized by root and confirmed empty before run; no FLUSH. Earlier same-source/target fixture run correctly refused nonempty restore target (`query-review-native-backup.log`); it is not counted as success.
- `query-review-ui-final-build.log`: remote TypeScript --noEmit and production Vite build PASS.
- `query-review-ui-final.log`: real `/admin/session-usage` and `/instances/9` production routes PASS with explicitly mocked API data. Browser clock advances/new rows; manual and automatic refresh; older-page preservation; detail/filter/time-range reset; stale response fence;409 partial CSV refusal;503 retry;390px mobile. API mocks verify UI wiring/interaction, not live HTTP storage integration. SQL and handler/service regressions supply the backend evidence separately. Screenshots `/tmp/cm-session-refresh-{admin,instance}{,-mobile}.png` on54; mobile instance visually inspected after responsive fix.

The test-only held-writer fixture initially waited on existing same-day summary/source locks; corrected to a raw old-writer transaction with projection after commit. Intermediate stopped/timed-out processes were owned test processes; their uniquely identified temporary schemas were subsequently removed by fixture cleanup. No application or other agent schema was dropped.

## Commands

All Go execution uses:
`env -u GOROOT GOTOOLCHAIN=local CGO_ENABLED=0 GOMAXPROCS=2 GOPROXY=off GOSUMDB=off GOMODCACHE=/root/cm-nfs-multislot-20261105/cache/mod GOCACHE=/root/cm-nfs-multislot-20261105/cache/build /root/cm-nfs-multislot-20261105/tools/usr/local/go/bin/go`

Working directory: query-fixes/backend. Functional env: `TEST_DATABASE_MYSQL_PORT=33317 CM_OBSERVABILITY_TEST_DSN='root@tcp(127.0.0.1:33317)/mysql?parseTime=true'`.

Focused final multi-package run:
`go test ./internal/repository ./internal/handlers ./internal/aigateway -run 'Test(QueryReview|QuerySummary|CostSummary|CostOverviewSQL|CostReporting|SessionSQL|AdminSessionSQL|SessionReportingInvocation|SessionUsageWindow|Observation|Trace|Audit|DurableInvocationReal|GatewayExecutedResult)' -count=1 -timeout=5m`

Final source fence run:
`go test ./internal/repository ./internal/aigateway -run 'Test(QueryReview|CostSummaryRealCreateBeforeInvocation|DurableInvocationReal|GatewayExecutedResult)' -count=1 -timeout=2m`

Read-only capacity fixture33327:
`TEST_DATABASE_MYSQL_PORT=33327 CM_QUERY_CAPACITY_TEST=1 go test ./internal/repository -run TestQueryCapacityTenThousand -count=1 -timeout=20m -v`

Native backup command and credential-safe environment assembly: `/root/cm-database-completion-20261118/query-fixes/run-native.py` (reads the existing owned MinIO credentials file, never prints credentials). It invokes only the explicit native tests listed above on disposable databases/buckets and isolated Redis DB15.

Browser in query-fixes/frontend:
`CM_PLAYWRIGHT_MODULE=/root/cm-migration-ui-fix4/browser-tools/node_modules/playwright CM_CHROME_PATH=/root/cm-uiux08-20261111/browser/root/opt/google/chrome/chrome /root/cm-nfs-multislot-20261105/tools/usr/local/go/bin/node scripts/session-refresh.browser.mjs`

## Capacity rerun

`query-review-capacity.log` PASS300.910s. Synthetic10000instances x90days, one invocation/active-instance/day;20samples/endpoint, P95 sorted19th. Dedicated33327 MySQL4CPU/8Gi container,4Gi buffer pool as in original evidence. The numbers below are this fix wave's measured read-query results, not production RPS claims. Latest pre-source-INSERT fence hook adjustment happened after this run; it does not change serving SQL, but parent explicitly owns another frozen-source acceptance after independent review.

| Scenario | P50 | P95 | Maximum |
|---|---:|---:|---:|
| Admin10% /90000facts |279.344ms|293.403ms|303.711ms|
| Admin30% /270000facts |629.476ms|672.958ms|675.674ms|
| Admin100% /900000facts |1.651488s|1.791633s|1.794413s|
| Cost900000ledger/300000selected |946.114ms|965.065ms|1.046295s|
| Single-instance session |7.811ms|9.834ms|10.469ms|
| Trace metadata page |7.950ms|10.501ms|13.303ms|
| Admin fractional30day |1.666866s|1.716107s|1.717068s|
| Cost fractional30day |1.310147s|1.330222s|1.356919s|

All common-list500ms/admin-summary2s targets pass. Measured Go peak heap6,756,416bytes (10ms sampling); process peak RSS36,096KiB; SQLpool wait_count0/wait_duration0/max_open4. MySQL storage TABLE_ROWS remains an estimate, not exact population; actual fixture inserts/checks establish900000facts. Actual plans/storage remain in the same log. This is the established unfiltered synthetic distribution plus fractional-window scenario; arbitrary customer distributions were not benchmarked.

## Source identity / handoff

33 critical implementation/UI/test files are listed in `/tmp/cm-database-query-review-files.txt`. Local manifest `/tmp/cm-database-query-review-source-sha256.txt` matches remote `evidence/query-review-source-sha256.txt` byte-for-byte. Manifest SHA256: `ea4c7f46431833d34209eae592ae761a54a5d679a7c3447269dcfdcdfdbf1a82`. Root-owned audit count/index edits and persistence-agent122 changes were preserved. Shared manifests contain those integrated files as actually tested, not only isolated hunks.

Final source-fence result is appended below once the in-progress focused command completes. No further implementation changes planned; independent review and parent final frozen integration/HTML remain required.

Final source-fence command completed: `query-review-source-fence-final.log` repository PASS13.742s, aigateway PASS0.316s. This includes the original Q1/Q2/Q3 regressions, metadata/commit-order/cold cases, both repair interleavings, real Create-before-source fence, real cost-before-invocation, durable projection/hydration and real gateway SQL outage/restart. All changes are now ready for independent review. No outstanding assigned fix or verification failure remains; the parent-owned frozen integrated acceptance and HTML report are not claimed complete by this report.
