import argparse, hashlib, json, os, socket, subprocess, time
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('phase',choices=['prepare','recover']);p.add_argument('--state',required=True);a=p.parse_args()
class Redis:
 def __init__(self): self.sock=socket.create_connection(('127.0.0.1',33348),timeout=15);self.file=self.sock.makefile('rb')
 def read(self):
  line=self.file.readline();kind=line[:1];value=line[1:-2]
  if kind==b'-':raise RuntimeError(value.decode())
  if kind==b'+':return value.decode()
  if kind==b':':return int(value)
  if kind==b'$':
   size=int(value)
   if size<0:return None
   raw=self.file.read(size);assert self.file.read(2)==b'\r\n';return raw
  if kind==b'*':return [self.read() for _ in range(int(value))]
  raise RuntimeError(repr(line))
 def cmd(self,*args):
  args=[x if isinstance(x,bytes) else str(x).encode() for x in args]
  self.sock.sendall(b'*'+str(len(args)).encode()+b'\r\n'+b''.join(b'$'+str(len(x)).encode()+b'\r\n'+x+b'\r\n' for x in args));return self.read()
 def info(self,section):return dict(line.split(':',1) for line in self.cmd('INFO',section).decode().splitlines() if ':' in line)
r=Redis();assert r.cmd('GET','cm:test:redis-budget:isolated')==b'cm-database-completion-20261118'
assert r.cmd('CONFIG','GET','maxmemory')==[b'maxmemory',b'1073741824'];assert r.cmd('CONFIG','GET','maxmemory-policy')==[b'maxmemory-policy',b'noeviction']
def cgroup_peak():
 return int(subprocess.check_output(['kubectl','-n','cm-database-completion-20261118','exec','redis-budget','--','cat','/sys/fs/cgroup/memory.peak'],text=True).strip())
def key(i):return 'cm:test:redis-budget:data:'+str(i)
path=Path(a.state)
if a.phase=='prepare':
 assert r.cmd('DBSIZE')==1,'fresh owned fixture required'
 data=os.urandom(65536);revised=os.urandom(65536);count=0
 while int(r.info('memory')['used_memory'])<805306368:r.cmd('SET',key(count),data);count+=1
 initial=count;r.cmd('BGREWRITEAOF');samples=[]
 for i in range(initial//3):
  r.cmd('SET',key(i),revised)
  if i%64==0:samples.append(r.info('memory'))
 until=time.monotonic()+60
 while r.info('persistence').get('aof_rewrite_in_progress')=='1':
  assert time.monotonic()<until,'AOF rewrite exceeded deadline';samples.append(r.info('memory'));time.sleep(.1)
 assert r.info('persistence')['aof_last_bgrewrite_status']=='ok'
 rejected=False
 for _ in range(10000):
  try:r.cmd('SET',key(count),data);count+=1
  except RuntimeError as error:
   assert 'OOM' in str(error),str(error);rejected=True;break
 assert rejected,'noeviction capacity was not reached'
 assert r.cmd('GET',key(count)) is None,'rejected write changed database'
 assert r.cmd('DBSIZE')==count+1,'accepted keys were evicted'
 peak=cgroup_peak();assert peak<3*1024**3,peak
 state=dict(keys=count,revised_keys=initial//3,data_sha256=hashlib.sha256(data).hexdigest(),revised_sha256=hashlib.sha256(revised).hexdigest(),cgroup_peak_bytes=peak,max_sampled_rss_bytes=max(int(x['used_memory_rss']) for x in samples),memory=r.info('memory'),persistence=r.info('persistence'),rewrite_samples=len(samples),noeviction_oom=True)
 path.write_text(json.dumps(state,indent=2));print(json.dumps(state),flush=True)
 r.cmd('CONFIG','SET','maxmemory','1073741824');r.cmd('WAITAOF','1','0','10000')
else:
 state=json.loads(path.read_text());assert r.cmd('DBSIZE')==state['keys']+1
 for i in range(state['keys']):
  raw=r.cmd('GET',key(i));assert raw is not None
  expected=state['revised_sha256'] if i<state['revised_keys'] else state['data_sha256'];assert hashlib.sha256(raw).hexdigest()==expected,i
 peak=cgroup_peak();assert peak<3*1024**3
 print(json.dumps(dict(aof_container_restart=True,verified_full_payload_keys=state['keys'],verified_bytes=state['keys']*65536,evicted_keys=int(r.info('stats')['evicted_keys']),cgroup_peak_bytes=peak,memory=r.info('memory'),persistence=r.info('persistence'))))
