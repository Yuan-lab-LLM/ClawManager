"""Execute recorded final checks on54 after the controller freezes reviewed sources."""
import argparse, json, os, subprocess, sys
from pathlib import Path

root=Path('/root/cm-database-completion-20261118/final')
cm=root/'ClawManager';runtime=root/'AgentsRuntime';evidence=root/'evidence';evidence.mkdir(parents=True,exist_ok=True)
go='/root/cm-nfs-multislot-20261105/tools/usr/local/go/bin/go'
node='/root/cm-nfs-multislot-20261105/tools/usr/local/go/bin/node'
parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['backend','race','queryperf','auditperf','frontend','runtime','tools','runtimefaults','redisbudget']);a=parser.parse_args()
freeze=json.loads((root/'code-freeze.json').read_text())
assert freeze['development_complete'] and freeze['review_passed'],'development/review gate is not complete'
env=os.environ.copy();env.pop('GOROOT',None)
env.update(PATH=str(Path(go).parent)+':'+env['PATH'],GOTOOLCHAIN='local',CGO_ENABLED='0',GOMAXPROCS='2',GOPROXY='off',GOSUMDB='off',GOMODCACHE='/root/cm-nfs-multislot-20261105/cache/mod',GOCACHE='/root/cm-nfs-multislot-20261105/cache/build')
env['CM_OBSERVABILITY_TEST_DSN']='root@tcp(127.0.0.1:33317)/mysql?parseTime=true'
env['CM_OBSERVATION_BACKFILL_BIN']=str(root/'bin/observation-backfill')
creds=json.loads(Path('/root/cm-database-completion-20261118/fixtures/minio-credentials.json').read_text())
env.update(TEST_DATABASE_MYSQL_PORT='33317',TEST_SYSTEM_BACKUP_MYSQL_PORT='33317',TEST_SYSTEM_BACKUP_REDIS_PORT='33318',TEST_SYSTEM_BACKUP_REDIS_TARGET_PORT='33320',TEST_SYSTEM_BACKUP_REDIS_DATABASE='15',TEST_SYSTEM_BACKUP_MINIO_PORT='33319',TEST_SYSTEM_BACKUP_MINIO_USER=creds['access_key'],TEST_SYSTEM_BACKUP_MINIO_PASSWORD=creds['secret_key'],CM_HISTORY_MINIO_CREDENTIALS='/root/cm-database-completion-20261118/fixtures/minio-credentials.json',TEST_TEAM_CONTEXT_REDIS_URL='redis://127.0.0.1:33318/0',TEST_MANAGED_REDIS_DISPOSABLE='1',TEST_MANAGED_REDIS_PORT='33338',TEST_SYSTEM_BACKUP_VERIFY_EXE=str(root/'bin/system-backup-artifact'),RUNTIME_DURABLE_SOURCE=str(runtime/'plugins/openclaw-redis-team/dist/index.js'),RUNTIME_PUBLIC_FIXTURE=str(root/'public-delivery-fixture.json'),CM_PLAYWRIGHT_MODULE='/root/cm-migration-ui-fix4/browser-tools/node_modules/playwright',CM_CHROME_PATH='/root/cm-uiux08-20261111/browser/root/opt/google/chrome/chrome')
(root/'bin').mkdir(exist_ok=True)
failures=[]
def run(slug,name,category,command,cwd=None,kind='command',extra=None):
 suite_id=slug
 slug=os.environ.get('CM_FINAL_RUN_TAG','v1')+'-'+slug
 current=env.copy();current.update(extra or {})
 args=[sys.executable,str(cm/'docs/reports/run_database_evidence.py'),'--record',str(evidence/(slug+'.meta.json')),'--evidence',str(evidence/(slug+'.jsonl' if kind=='go-json' else slug+'.log')),'--name',name,'--suite-id',suite_id,'--category',category,'--kind',kind,'--cwd',str(cwd or cm/'backend'),'--source-manifest',str(root/'source-manifest.json'),'--source-root',str(root),'--',*command]
 code=subprocess.run(args,env=current,check=False).returncode
 if code:failures.append(slug)
 return code

if a.phase=='backend':
 run('build-backup-cli','原生备份 CLI 构建','构建',[go,'build','-o',env['TEST_SYSTEM_BACKUP_VERIFY_EXE'],'./cmd/system-backup-artifact'])
 run('build-observation-cli','观察报表回填 CLI 构建','构建',[go,'build','-o',str(root/'bin/observation-backfill'),'./cmd/observation-backfill'])
 run('build-all','全部后端与维护命令构建','构建',[go,'build','./cmd/...'])
 run('runtime-public-fixture','真实 Runtime 完整正文发布夹具','Runtime 与权限',[node,'plugins/openclaw-redis-team/scripts/durable-review-regression-test.mjs'],runtime)
 run('backend-full','完整后端功能回归（真实隔离存储）','后端整合',[go,'test','./...','-p','2','-count=1','-timeout=30m','-json'],kind='go-json')
elif a.phase=='race':
 run('backend-race','变更相关并发与数据竞争','并发与恢复',[go,'test','-race','./internal/observability','./internal/historymaintenance','./internal/repository','./internal/services','./internal/aigateway','./internal/systembackup','-run','Test(Journal|EncryptedObjects|MySQLRollback|CancelledOutbox|QueryReview|WholeBranch|GatewayObservationMatrix|LiveTeamDLQ|AuditSummary|AtomicProjection|DurableTeamDispatch|DeletedTeamRedisCleanup|TeamReceiptClosure|QuiescentTeamTrim|ManagedRedis|RuntimeJournalThrough)','-p','1','-count=1','-timeout=20m','-json'],kind='go-json',extra={'CGO_ENABLED':'1'})
elif a.phase=='queryperf':
 run('query-capacity','1 万实例 / 90 万调用与费用性能','容量与性能',[go,'test','./internal/repository','-run','^TestQueryCapacityTenThousand','-count=1','-timeout=25m','-json'],kind='go-json',extra={'TEST_DATABASE_MYSQL_PORT':'33327','CM_QUERY_CAPACITY_TEST':'1'})
elif a.phase=='auditperf':
 run('audit-capacity','1 万实例 / 90 万实际审计源回填与查询','容量与性能',[go,'test','./internal/repository','-run','^TestAuditCapacityActualSourceBackfillAndQueries$','-count=1','-timeout=25m','-json'],kind='go-json',extra={'TEST_DATABASE_MYSQL_PORT':'33337','CM_AUDIT_CAPACITY_TEST':'1','CM_OBSERVATION_BACKFILL_BIN':str(root/'bin/observation-backfill')})
elif a.phase=='frontend':
 front=cm/'frontend'
 run('frontend-types','前端完整类型检查','前端',[node,'node_modules/typescript/bin/tsc','-b','--force'],front)
 run('frontend-build','前端生产包构建','前端',[node,'node_modules/vite/bin/vite.js','build'],front)
 for name,command in [('version',['scripts/app-version-display.test.mjs']),('instance-access',['--test','src/hooks/useInstanceDesktopAccess.test.mjs']),('runtime-management',['--experimental-strip-types','--test','scripts/runtime-management.test.mjs']),('hermes-navigation',['--experimental-strip-types','--test','src/lib/hermesDesktopFrame.test.mjs','src/lib/hermesSessionNavigation.test.mjs']),('opencode-entry',['scripts/opencode-default-entry.test.mjs']),('team-creation',['--experimental-strip-types','scripts/team-creation-policy.test.mjs']),('workbench',['--experimental-strip-types','--test','scripts/workbench-state.test.mjs'])]:
  run('frontend-'+name,'前端 '+name+' 回归','前端',[node,*command],front)
 for name in ['audit-list-pagination','cost-pagination','trace-pagination','session-refresh']:
  run('browser-'+name,'实际页面 '+name+' 浏览器回归','浏览器',[node,'scripts/'+name+'.browser.mjs'],front)
elif a.phase=='runtime':
 extra={'REDIS_TEAM_TEST_URL':'redis://127.0.0.1:33328/0','HERMES_REDIS_TEST_URL':'redis://127.0.0.1:33328/0','RUNTIME_PUBLIC_FIXTURE':str(root/'runtime-public-fixture-standalone.json')}
 run('runtime-hermes','Hermes 全部测试','Runtime',[sys.executable,'-m','unittest','discover','-v','-s','plugins/hermes-redis-team','-p','test_*.py'],runtime,extra=extra)
 tests=sorted(str(x.relative_to(runtime)) for x in (runtime/'opencode/team').glob('*.test.mjs'))
 run('runtime-opencode','OpenCode 全部协议测试','Runtime',[node,'--test',*tests],runtime,extra=extra)
 for name in ['durable-delivery-test','durable-delivery-capacity-test','durable-claim-race-test','durable-context-admission-test','durable-review-regression-test','team-active-context-test','team-consumer-regression-test','team75-contract-test','build-check']:
  run('runtime-node-'+name,'Node '+name,'Runtime',[node,'plugins/openclaw-redis-team/scripts/'+name+'.mjs'],runtime,extra=extra)
 for filename in ['durable_claim_race_test.py','context_handoff_process_test.py']:
  run('runtime-hermes-'+filename[:-3],'Hermes 真实处理器 '+filename,'Runtime',[sys.executable,'plugins/hermes-redis-team/'+filename],runtime,extra=extra)
elif a.phase=='tools':
 run('report-integrity','HTML 报告证据完整性与防注入','测试报告',[sys.executable,'-m','unittest','-v','test_generate_database_report.py'],cm/'docs/reports')
 run('backup-partial-shell','备份残留身份与锁故障测试','备份与恢复',[sys.executable,'deployments/k8s/sites/nine-node-production/tests/test_backup_attempts.py','-v'],cm)
 run('backup-helper-stock-image','实际 MySQL 镜像锁继承与重入','备份与恢复',[sys.executable,str(root/'tools/final-fault-controller.py'),'backup-helper-stock-image'],cm)
elif a.phase=='runtimefaults':
 run('runtime-faults','Runtime 实际 ENOSPC / OOM / AOF 与进程恢复','Runtime',[sys.executable,str(root/'tools/final-fault-controller.py'),'runtime-faults'],runtime)
elif a.phase=='redisbudget':
 run('redis-budget','1GiB Redis 无淘汰 / 重写 / 容器重启 / 全载荷校验','容量与性能',[sys.executable,str(root/'tools/final-fault-controller.py'),'redis-budget'],cm)
print(json.dumps({'phase':a.phase,'failures':failures}));raise SystemExit(bool(failures))
