"""Owned server54 fixtures only: final Runtime/AOF/ENOSPC and Redis memory checks."""
import argparse, json, os, re, shutil, signal, subprocess, sys, tempfile, time
from pathlib import Path

ROOT=Path('/root/cm-database-completion-20261118/final')
NS='cm-database-completion-20261118'
RUNTIME=ROOT/'AgentsRuntime'
NODE='/root/cm-nfs-multislot-20261105/tools/usr/local/go/bin/node'
parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['runtime-faults','redis-budget','backup-helper-stock-image']);a=parser.parse_args()
assert json.loads((ROOT/'code-freeze.json').read_text())['review_passed']
def call(command,expected=0,env=None,cwd=None):
 print(json.dumps({'command':command,'expected_exit':expected}),flush=True)
 code=subprocess.run(command,env=env,cwd=cwd,check=False).returncode
 assert code==expected,(command,code,expected)
def kube(*args,check=True):
 result=subprocess.run(['kubectl','-n',NS,*args],text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if check and result.returncode:raise RuntimeError(result.stderr)
 return result.stdout.strip()
def pod(name):return json.loads(kube('get','pod',name,'-o','json'))
def redis_cli(name,*args):return kube('exec',name,'--','redis-cli','--raw',*args)
def forward(name,port):
 # Retire only this owned fixture's old loopback forward, never a business listener.
 result=subprocess.check_output(['ss','-lptn',f'sport = :{port}'],text=True)
 for process_id in set(re.findall(r'pid=(\d+)',result)):
  process_id=int(process_id);command=Path(f'/proc/{process_id}/cmdline').read_bytes().replace(b'\0',b' ').decode()
  assert 'kubectl' in command and 'port-forward' in command and NS in command and name in command and str(port) in command,command
  os.kill(process_id,signal.SIGTERM)
  for _ in range(30):
   if not Path(f'/proc/{process_id}').exists():break
   time.sleep(.1)
 log=(ROOT/'evidence'/f'forward-{name}-{time.time_ns()}.log').open('w')
 process=subprocess.Popen(['kubectl','-n',NS,'port-forward','--address','127.0.0.1','pod/'+name,f'{port}:6379'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 log.close()
 import socket
 for _ in range(100):
  assert process.poll() is None,'fixture port-forward exited'
  try:
   with socket.create_connection(('127.0.0.1',port),timeout=.2):return
  except OSError:time.sleep(.1)
 raise RuntimeError('fixture forward unavailable')
def ready(name,minimum_restart=0):
 deadline=time.monotonic()+60
 while time.monotonic()<deadline:
  state=pod(name);container=state['status'].get('containerStatuses',[{}])[0]
  if container.get('restartCount',0)>=minimum_restart and container.get('state',{}).get('running'):
   if kube('exec',name,'--','redis-cli','--raw','PING',check=False)=='PONG':return state
  time.sleep(.4)
 raise RuntimeError('owned Redis did not recover')
def restart(name,port,marker,value):
 before=pod(name);assert redis_cli(name,'GET',marker)==value
 status=before['status']['containerStatuses'][0];start=time.monotonic()
 assert redis_cli(name,'CONFIG','GET','appendonly').splitlines()==['appendonly','yes']
 kube('exec',name,'--','redis-cli','SHUTDOWN','NOSAVE',check=False)
 after=ready(name,status['restartCount']+1)
 assert after['metadata']['uid']==before['metadata']['uid']
 assert after['status']['containerStatuses'][0]['containerID']!=status['containerID']
 forward(name,port);assert redis_cli(name,'GET',marker)==value
 event=dict(pod=name,uid=after['metadata']['uid'],before=status,after=after['status']['containerStatuses'][0],recovery_seconds=time.monotonic()-start)
 (ROOT/'evidence'/f'{name}-restart-{time.time_ns()}.json').write_text(json.dumps(event,indent=2));print(json.dumps(event),flush=True)

if a.phase=='runtime-faults':
 env=os.environ.copy();env.update(REDIS_TEAM_TEST_URL='redis://127.0.0.1:33328/0',HERMES_REDIS_TEST_URL='redis://127.0.0.1:33328/0')
 assert redis_cli('runtime-redis','GET','cm:test:runtime-durable:isolated')=='runtime-durable-20261118'
 mount=Path('/mnt/cm-runtime-enospc-final');mount.mkdir(exist_ok=True)
 if not os.path.ismount(mount):call(['mount','-t','tmpfs','-o','size=64m,mode=0700','cm-runtime-enospc-final',str(mount)])
 assert subprocess.check_output(['findmnt','-n','-o','FSTYPE','--target',str(mount)],text=True).strip()=='tmpfs'
 stat=os.statvfs(mount);assert stat.f_blocks*stat.f_frsize==64*1024*1024
 for name,command in [('node',[NODE,'plugins/openclaw-redis-team/scripts/durable-enospc-test.mjs']),('hermes',[sys.executable,'plugins/hermes-redis-team/durable_enospc_test.py']),('handoff',[sys.executable,'plugins/hermes-redis-team/context_handoff_process_test.py'])]:
  directory=Path(tempfile.mkdtemp(prefix=name+'-',dir=mount));current=env.copy();current['RUNTIME_ENOSPC_ROOT']=str(directory)
  call(command,env=current,cwd=RUNTIME);shutil.rmtree(directory)
 suffix='-frozen-'+str(time.time_ns());states=ROOT/'runtime-fault-state';states.mkdir(exist_ok=True)
 cases=[('node',[NODE,'plugins/openclaw-redis-team/scripts/durable-delivery-redis-test.mjs']),('hermes',[sys.executable,'plugins/hermes-redis-team/durable_delivery_redis_test.py'])]
 for name,command in cases:
  current=env.copy();current.update(RUNTIME_DURABLE_TEST_SUFFIX=suffix,RUNTIME_DURABLE_TEST_STATE=str(states/(name+suffix)))
  call([*command,'prepare'],env=current,cwd=RUNTIME)
 context_command=[sys.executable,'plugins/hermes-redis-team/context_handoff_process_test.py']
 for fault in ['queue_after','native_effect']:
  directory=states/(fault+suffix);directory.mkdir()
  call([*context_command,'prepare',str(directory),fault],expected=72,env=env,cwd=RUNTIME)
  for mirror in directory.glob('.hermes-redis-team/context-*.json'):mirror.unlink()
 restart('runtime-redis',33328,'cm:test:runtime-durable:isolated','runtime-durable-20261118')
 for name,command in cases:
  current=env.copy();current.update(RUNTIME_DURABLE_TEST_SUFFIX=suffix,RUNTIME_DURABLE_TEST_STATE=str(states/(name+suffix)))
  call([*command,'recover'],env=current,cwd=RUNTIME)
 for fault in ['queue_after','native_effect']:
  directory=states/(fault+suffix)
  command=[*context_command,'recover',str(directory),fault]
  children=[subprocess.Popen(command,env=env,cwd=RUNTIME) for _ in range(2)]
  assert all(child.wait()==0 for child in children)
  call([*context_command,'verify',str(directory),fault],env=env,cwd=RUNTIME)
  if fault=='native_effect':
   call([*context_command,'proof',str(directory),fault],env=env,cwd=RUNTIME)
   call([*context_command,'verify',str(directory),'proof_resolved'],env=env,cwd=RUNTIME)
 print(json.dumps(dict(realENOSPC=True,realContainerAOFRestart=True,providerCallsPerIdentity=1,queuedHandoffRecovered=True,uncertainHandoffRetained=True,exactNativeProofResolved=True)),flush=True)
elif a.phase=='redis-budget':
 existing=json.loads(kube('get','pod','redis-budget','-o','json'))
 assert redis_cli('redis-budget','GET','cm:test:redis-budget:isolated')==NS
 kube('delete','pod','redis-budget','--wait=true','--timeout=30s')
 manifest=dict(apiVersion='v1',kind='Pod',metadata=dict(name='redis-budget',namespace=NS,labels={'cm-test':'database-functional-budget'}),spec=dict(restartPolicy='Always',containers=[dict(name='redis-budget',image='172.16.1.12:5010/redis:7-alpine',args=['redis-server','--maxmemory','1gb','--maxmemory-policy','noeviction','--appendonly','yes','--appendfsync','everysec','--auto-aof-rewrite-percentage','0','--save','','--dir','/data'],resources={'limits':{'memory':'3Gi','cpu':'2'}},volumeMounts=[dict(name='data',mountPath='/data')])],volumes=[dict(name='data',emptyDir={'sizeLimit':'8Gi'})]))
 subprocess.run(['kubectl','-n',NS,'apply','-f','-'],input=json.dumps(manifest),text=True,check=True)
 new=ready('redis-budget');assert new['metadata']['uid']!=existing['metadata']['uid']
 redis_cli('redis-budget','SET','cm:test:redis-budget:isolated',NS);forward('redis-budget',33348)
 state=ROOT/'evidence'/('redis-budget-state-'+str(time.time_ns())+'.json')
 command=[sys.executable,str(ROOT/'tools/redis-budget-check.py')]
 call([*command,'prepare','--state',str(state)])
 restart('redis-budget',33348,'cm:test:redis-budget:isolated',NS)
 call([*command,'recover','--state',str(state)])
elif a.phase=='backup-helper-stock-image':
 output=ROOT/('backup-helper-preparation-'+str(time.time_ns()))
 call([sys.executable,'deployments/k8s/sites/nine-node-production/prepare-backup-lock-helper.py','--go','/root/cm-nfs-multislot-20261105/tools/usr/local/go/bin/go','--output',str(output)],cwd=ROOT/'ClawManager')
 import base64,gzip,hashlib
 prepared=json.loads((output/'mysql-backup-lock-helper.json').read_text());raw=gzip.decompress(base64.b64decode(prepared['binaryData']['flock.gz']))
 assert hashlib.sha256(raw).hexdigest()==prepared['metadata']['annotations']['clawmanager.io/binary-sha256']
 assert pod('mysql')['spec']['containers'][0]['image'].startswith('172.16.1.12:5010/mysql:')
 binary=ROOT/'bin/flock';binary.write_bytes(raw);binary.chmod(0o700)
 target='/tmp/cm-functional-flock-'+str(time.time_ns())
 call(['kubectl','-n',NS,'cp',str(binary),'mysql:'+target])
 shell="""set -eu; helper="$1"; lock="$helper.lock"; chmod 700 "$helper"; (exec 9>"$lock"; "$helper" -n -x 9; if sh -c 'exec 8>"$1"; "$2" -n -x 8' sh "$lock" "$helper"; then exit 91; fi); (exec 9>"$lock"; "$helper" -n -x 9); rm -f "$helper" "$lock"; echo inherited-lock-competitor-refused-and-reclaimed"""
 call(['kubectl','-n',NS,'exec','mysql','--','sh','-c',shell,'sh',target])
