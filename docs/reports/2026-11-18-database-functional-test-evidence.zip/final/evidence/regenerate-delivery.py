"""Record and validate a reporting-only correction without changing the app freeze."""
import collections
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path('/root/cm-database-completion-20261118/final')
delivery = root / 'report-delivery-tools'
frozen = root / 'ClawManager/docs/reports'
hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(delivery.glob('*.py'))}
delta = [name for name in hashes if (frozen / name).exists()
         and (frozen / name).read_bytes() != (delivery / name).read_bytes()]
assert set(delta) == {'generate_database_report.py', 'test_generate_database_report.py'}
diff = ''.join(''.join(difflib.unified_diff((frozen / name).read_text().splitlines(True),
    (delivery / name).read_text().splitlines(True), fromfile='frozen/' + name, tofile='delivery/' + name))
    for name in sorted(delta))
(root / 'evidence/report-delivery-source.diff').write_text(diff)
tool_manifest = root / 'evidence/report-delivery-tools-manifest.json'
tool_manifest.write_text(json.dumps(hashes, indent=2) + '\n')

def run(*argv, cwd=None):
    print('RUN', ' '.join(map(str, argv)), flush=True)
    subprocess.run(list(map(str, argv)), check=True, cwd=cwd)

run(sys.executable, frozen / 'run_database_evidence.py',
    '--record', root / 'evidence/v5-report-delivery-integrity.meta.json',
    '--evidence', root / 'evidence/v5-report-delivery-integrity.log',
    '--name', '报告交付解析与完整性九项回归', '--suite-id', 'report-delivery-integrity',
    '--category', '测试报告', '--cwd', delivery, '--source-root', root,
    '--source-manifest', root / 'source-manifest.json',
    '--', sys.executable, '-m', 'unittest', '-v', 'test_generate_database_report.py')
freeze_path = root / 'code-freeze.json'
freeze = json.loads(freeze_path.read_text())
freeze['source']['report_delivery'] = dict(
    stage='功能测试冻结完成后，仅修正报告解析工具；冻结应用/测试树与原始日志保持原样。',
    changed_report_files=sorted(delta),
    tooling_manifest_sha256=hashlib.sha256(tool_manifest.read_bytes()).hexdigest(),
    tooling_manifest='final/evidence/report-delivery-tools-manifest.json',
    tooling_sources='delivery/report-tools/',
    regression_evidence='report-delivery-label-red.log / v5-report-delivery-integrity.log',
    scope='四个实际日志标签去除错误的 scenario= 预设；阈值、样本、原始证据绑定和判定逻辑未修改。')
freeze['limitations'].append(
    '功能冻结后的报告生成校验发现四个日志标签预设与真实输出不符，严格拒绝生成。'
    '交付工具单独修正解析标签并增加独立真实标签回归；其源码、差异、SHA、RED/GREEN及独立复审在 ZIP。'
    '原冻结应用/测试源码清单与全部真实测试日志未改写，未把报告工具后续修正冒充为功能冻结前版本。')
freeze['regressions'].append(dict(problem='报告工具四项性能标签不匹配',
    before='最终交付 composer 拒绝 admin_fractional；独立真实标签回归四项均 RED，日志保留。',
    after='报告工具仅修正四个匹配标签；九项回归与真实十项日志绑定通过，固定性能阈值未放宽。'))
sys.path.insert(0, str(delivery))
from generate_database_report import read_cases
suites = [json.loads(p.read_text()) for p in sorted((root / 'evidence').glob('v5-*.meta.json'))]
assert all(s.get('exit_code') == 0 for s in suites)
cases = [c for s in suites for c in read_cases(s)]
freeze['environment']['execution_summary']['suites'] = len(suites)
freeze['environment']['execution_summary']['counts'] = dict(collections.Counter(c['status'] for c in cases))
freeze_path.write_text(json.dumps(freeze, ensure_ascii=False, indent=2) + '\n')
run(sys.executable, root / 'cm-package-final-evidence.py')
run(sys.executable, delivery / 'compose-delivery-report.py', '--tag', 'v5',
    '--bundle', '2026-11-18-database-functional-test-evidence.zip', '--output', root / 'report-manifest.json')
run(sys.executable, delivery / 'generate_database_report.py', '--manifest', root / 'report-manifest.json',
    '--output', frozen / '2026-11-18-database-functional-test-report.html')
