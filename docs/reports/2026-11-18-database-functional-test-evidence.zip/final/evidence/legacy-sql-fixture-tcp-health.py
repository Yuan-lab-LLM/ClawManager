import socket, struct
s = socket.create_connection(('127.0.0.1',33347),timeout=5)
s.settimeout(5)
def read_exact(n):
    result=b''
    while len(result)<n:
        part=s.recv(n-len(result))
        if not part: raise RuntimeError('short MySQL packet')
        result+=part
    return result
def receive():
    header=read_exact(4)
    return header[3], read_exact(int.from_bytes(header[:3],'little'))
def send(sequence,payload):
    s.sendall(len(payload).to_bytes(3,'little')+bytes([sequence])+payload)
_,greeting=receive()
assert greeting[0]==10, greeting
print('loopback server_version='+greeting[1:].split(b'\0')[0].decode())
flags=1|4|0x200|0x2000|0x8000|0x80000
send(1,struct.pack('<IIB23x',flags,1<<24,45)+b'root\0\0caching_sha2_password\0')
_,accepted=receive()
assert accepted[:1]==b'\0', 'fixture empty-root authentication failed: '+repr(accepted)
send(0,b"\x03SELECT CONCAT('legacy-v3:',VERSION(),':',@@innodb_use_native_aio,':',@@datadir,':',(SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='cm_database_test_marker'))")
packets=[receive()[1] for _ in range(5)]
assert all(p[:1]!=b'\xff' for p in packets), packets
expected=b'legacy-v3:8.4.8:0:/var/lib/mysql/data/:1'
assert any(expected in p for p in packets), packets
print('authenticated loopback SQL='+expected.decode())
s.close()
