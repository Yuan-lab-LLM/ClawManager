"""Keep only the owned MinIO fixture forward alive through cancelled transfers."""
import json,os,re,signal,socket,subprocess,time
from pathlib import Path
namespace='cm-database-completion-20261118'
base=Path('/root/cm-database-completion-20261118')
assert json.loads(subprocess.check_output(['kubectl','-n',namespace,'get','pod','minio','-o','json']))['metadata']['namespace']==namespace
for value in re.findall(r'pid=(\d+)',subprocess.check_output(['ss','-lptn','sport = :33319'],text=True)):
 pid=int(value);cmd=Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\0',b' ').decode()
 assert 'kubectl' in cmd and namespace in cmd and 'port-forward' in cmd and 'minio' in cmd and '33319' in cmd
 os.kill(pid,signal.SIGTERM)
deadline=time.monotonic()+7200
child=None
def stop(*_):
 if child and child.poll() is None:child.terminate()
 raise SystemExit(0)
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
while time.monotonic()<deadline:
 print(json.dumps({'event':'start','at':time.time(),'port':33319}),flush=True)
 child=subprocess.Popen(['kubectl','-n',namespace,'port-forward','--address','127.0.0.1','pod/minio','33319:9000'])
 code=child.wait()
 print(json.dumps({'event':'forward_exit','exit_code':code,'at':time.time()}),flush=True)
 time.sleep(.1)
