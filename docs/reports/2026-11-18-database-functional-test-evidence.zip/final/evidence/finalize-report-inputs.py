"""Add measured delivery metadata after every frozen-source suite completes."""
import collections
import hashlib
import json
import sys
from pathlib import Path

root = Path('/root/cm-database-completion-20261118/final')
sys.path.insert(0, str(root / 'ClawManager/docs/reports'))
from generate_database_report import read_cases

frozen_path = root / 'code-freeze.json'
freeze = json.loads(frozen_path.read_text())
fingerprint = hashlib.sha256((root / 'source-manifest.json').read_bytes()).hexdigest()
suites = [json.loads(p.read_text()) for p in sorted((root / 'evidence').glob('v5-*.meta.json'))]
assert suites and all(s.get('exit_code') == 0 for s in suites), 'unfinished or failed final suite'
assert all(s['source_manifest_sha256'] == fingerprint for s in suites)
cases = [case for suite in suites for case in read_cases(suite)]
assert all(c['status'] in ('PASS', 'SKIP') for c in cases)
passed = collections.defaultdict(list)
for case in cases:
    if case['status'] == 'PASS':
        passed[(case.get('package', ''), case['name'])].append(case['suite'])
skips = []
for case in cases:
    if case['status'] != 'SKIP':
        continue
    reasons = [line.strip() for line in case['output'].splitlines() if '_test.go:' in line]
    skips.append(dict(package=case.get('package', ''), name=case['name'], suite=case['suite'],
                      reason='\n'.join(reasons),
                      covered_by=passed.get((case.get('package', ''), case['name']), [])))
remaining = [s for s in skips if not s['covered_by']]
skip_summary = dict(skipped_executions=len(skips),
                    covered_elsewhere_executions=len(skips) - len(remaining),
                    remaining_executions=len(remaining),
                    remaining_unique_cases=len({(s['package'], s['name']) for s in remaining}))
(root / 'evidence/v5-skip-inventory.json').write_text(
    json.dumps(dict(summary=skip_summary, cases=skips), ensure_ascii=False, indent=2) + '\n')
events = []
for line in (root / 'evidence/v5-redis-budget.log').read_text().splitlines():
    try:
        value = json.loads(line)
    except ValueError:
        continue
    if isinstance(value, dict):
        events.append(value)
recovered = next(e for e in events if 'verified_full_payload_keys' in e)
restart = next(e for e in events if 'recovery_seconds' in e)
prepared = next(e for e in events if 'noeviction_oom' in e)
budget = dict(verified_keys=recovered['verified_full_payload_keys'],
              verified_payload_bytes=recovered['verified_bytes'],
              evicted_keys=recovered['evicted_keys'],
              cgroup_peak_bytes=recovered['cgroup_peak_bytes'],
              recovery_seconds=restart['recovery_seconds'],
              rewrite_samples=prepared['rewrite_samples'],
              noeviction_oom=prepared['noeviction_oom'],
              evidence='v5-redis-budget.log',
              boundary='有限合成负载实测，不能据此保证所有生产负载的峰值。')
freeze['environment']['redis_budget_observation'] = budget
freeze['environment']['skip_summary'] = skip_summary
freeze['environment']['execution_summary'] = dict(suites=len(suites),
    counts=dict(collections.Counter(c['status'] for c in cases)),
    method='Go 叶子用例执行次数；专项及 race 重跑分别记录；非 Go 按命令记录。')
freeze['limitations'].append(
    f"最终有 {len(skips)} 条 SKIP 执行记录，其中 {len(skips)-len(remaining)} 条对应的同名用例已在专用夹具通过；"
    f"仍有 {len(remaining)} 条未实跑。完整逐项原因及补测绑定见 ZIP 中 v5-skip-inventory.json，"
    '包括其他专属 SQL 配置、SQLite/原生宿主、Kubernetes/NFS 环境和额外诊断场景；这些项目不计通过。')
frozen_path.write_text(json.dumps(freeze, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(summary=freeze['environment']['execution_summary'], skips=skip_summary, redis=budget), ensure_ascii=False))
