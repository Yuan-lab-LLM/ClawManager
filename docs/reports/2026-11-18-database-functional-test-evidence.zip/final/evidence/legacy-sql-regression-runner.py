#!/usr/bin/env python3
"""Explicitly run the audited SQL-only skips on an audited fixture after explicit parent release."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/root/cm-database-completion-20261118/final')
EVIDENCE = ROOT / 'evidence'
GO = '/root/cm-nfs-multislot-20261105/tools/usr/local/go/bin/go'
MANIFEST_SHA = json.loads((ROOT / 'code-freeze.json').read_text())['source']['manifest_sha256']
SELECTION_SHA = 'ade72992b54f52144e851cdf174df321e72b0a9977839a337720f9753d340319'
FIXTURES = {'33317': ('mysql', '4b560ba6-cb33-4d36-81ae-40fa520704c4'), '33347': ('mysql-legacy-v3', '254663e7-5532-4a25-8e31-d414d41ee875')}
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--execute', action='store_true', help='Only after parent confirms race completion and fixture release')
parser.add_argument('--port', choices=tuple(FIXTURES), default='33317')
parser.add_argument('--run-tag', choices=('v2', 'v3', 'v4', 'v5'), default='v3')
args = parser.parse_args()
pod_name, pod_uid = FIXTURES[args.port]
raw = (EVIDENCE / 'legacy-sql-selected-skip-tests.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == SELECTION_SHA, 'audited selection changed'
selection = json.loads(raw)
names = sorted({name for tests in selection.values() for name in tests})
regex = '^(' + '|'.join(re.escape(name) for name in names) + ')$'
packages = sorted('./' + package.removeprefix('clawreef/') for package in selection)
for package in selection:
    directory = ROOT / 'ClawManager/backend' / package.removeprefix('clawreef/')
    declared = {name for file in directory.glob('*test.go') for name in re.findall(r'^func (Test\w+)\(', file.read_text(), re.M)}
    assert set(selection[package]) <= declared, 'selected test absent from frozen source'
    assert {name for name in declared if re.fullmatch(regex, name)} == set(selection[package]), 'regex would select an unaudited test'
manifest = (ROOT / 'source-manifest.json').read_bytes()
assert hashlib.sha256(manifest).hexdigest() == MANIFEST_SHA, 'wrong frozen source manifest'
for relative, digest in json.loads(manifest).items():
    assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == digest, 'frozen source changed: ' + relative
ports = {name: args.port for name in ('TEST_RUNTIME_MYSQL_PORT', 'TEST_RUNTIME_SECURITY_MYSQL_PORT', 'TEST_IDLE_MYSQL_PORT', 'TEST_TEAM_ICON_MYSQL_PORT')}
ports['NB_KEYS_TEST_MYSQL'] = '127.0.0.1:' + args.port
command = ['env', *(key + '=' + value for key, value in ports.items()), GO, 'test', *packages, '-run', regex, '-json', '-p', '1', '-count=1', '-timeout=20m']
if not args.execute:
    print(json.dumps({'status': 'prepared-not-executed', 'packages': packages, 'top_level_tests': sum(map(len, selection.values())), 'prior_skip_events': sum(sum(tests.values()) for tests in selection.values()), 'ports': ports, 'source_manifest_sha256': MANIFEST_SHA, 'selection_sha256': SELECTION_SHA}))
    raise SystemExit(0)
for suite in ((args.run_tag + '-backend-full', args.run_tag + '-backend-race') if args.port == '33317' else ()):
    record = json.loads((EVIDENCE / (suite + '.meta.json')).read_text())
    assert record.get('finished_at') and record.get('exit_code') == 0 and record.get('source_manifest_sha256') == MANIFEST_SHA, suite + ' must finish successfully before fixture reuse'
freeze = json.loads((ROOT / 'code-freeze.json').read_text())
assert freeze['development_complete'] and freeze['review_passed']
# Read-only preflight of the already-owned general fixture; never provision or repair it.
pod = json.loads(subprocess.check_output(['kubectl', '-n', 'cm-database-completion-20261118', 'get', 'pod', pod_name, '-o', 'json']))
assert pod['metadata']['uid'] == pod_uid and all(c['ready'] for c in pod['status']['containerStatuses']), 'general fixture identity/health changed'
marker = subprocess.check_output(['kubectl', '-n', 'cm-database-completion-20261118', 'exec', pod_name, '--', 'mysql', '-h127.0.0.1', '-uroot', '-Nse', "SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='cm_database_test_marker'"], text=True).strip()
assert marker == '1', 'disposable fixture marker absent'
# Only standard process variables and the audited SQL opt-ins enter the test.
# No real Kubernetes/NFS/Runtime/Redis/MinIO opt-in is inherited.
env = {key: os.environ[key] for key in ('PATH', 'HOME', 'TMPDIR', 'LANG', 'LC_ALL', 'TZ', 'USER', 'LOGNAME') if key in os.environ}
env.update(PATH=str(Path(GO).parent) + ':' + env.get('PATH', '/usr/bin:/bin'), GOTOOLCHAIN='local', CGO_ENABLED='0', GOMAXPROCS='2', GOPROXY='off', GOSUMDB='off', GOMODCACHE='/root/cm-nfs-multislot-20261105/cache/mod', GOCACHE='/root/cm-nfs-multislot-20261105/cache/build')
# The task-owned MySQL fixture uses its existing blank root password; never print password variables.
for key in ('TEST_RUNTIME_MYSQL_PASSWORD', 'TEST_RUNTIME_SECURITY_MYSQL_PASSWORD', 'TEST_IDLE_MYSQL_PASSWORD', 'NB_KEYS_TEST_PASSWORD'):
    env[key] = ''
wrapper = [sys.executable, str(ROOT / 'ClawManager/docs/reports/run_database_evidence.py'), '--record', str(EVIDENCE / (args.run_tag + '-legacy-sql-regression.meta.json')), '--evidence', str(EVIDENCE / (args.run_tag + '-legacy-sql-regression.jsonl')), '--name', '旧 SQL 身份、升级、生命周期与所有者统计回归', '--suite-id', 'legacy-sql-regression', '--category', '后端整合', '--kind', 'go-json', '--cwd', str(ROOT / 'ClawManager/backend'), '--source-manifest', str(ROOT / 'source-manifest.json'), '--source-root', str(ROOT), '--', *command]
raise SystemExit(subprocess.run(wrapper, env=env, check=False).returncode)
