import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path('/root/cm-database-completion-20261118/final')
evidence=root/'evidence'
expected='dc384330cef3d943dc0e7060ae06a464213f1e3a7bc4875e7f381b25c314f11c'
raw=(root/'source-manifest.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()==expected
for relative,digest in json.loads(raw).items():
 assert hashlib.sha256((root/relative).read_bytes()).hexdigest()==digest,relative
previous=json.loads((evidence/'v3-query-capacity.meta.json').read_text())
assert previous['exit_code']==0 and previous['finished_at'] and previous['source_manifest_sha256']==expected
pod=json.loads(subprocess.check_output(['kubectl','-n','cm-database-completion-20261118','get','pod','mysql-perf','-o','json']))
assert all(c['ready'] for c in pod['status']['containerStatuses'])
query="SELECT @@version,@@innodb_buffer_pool_size,@@innodb_use_native_aio,@@max_connections; SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='cm_database_test_marker'; SELECT COUNT(*) FROM information_schema.PROCESSLIST WHERE USER='root' AND ID<>CONNECTION_ID()"
health=subprocess.check_output(['kubectl','-n','cm-database-completion-20261118','exec','mysql-perf','--','mysql','-h127.0.0.1','-uroot','-Nse',query],text=True).strip().splitlines()
assert health[1:]==['1','0'],health
sockets=subprocess.check_output(['ss','-Htnp','dport = :33327'],text=True)
assert not sockets.strip(),sockets
(evidence/'v3-owner-baseline-resource-check-fixture.json').write_text(json.dumps({'pod':pod['metadata']['name'],'uid':pod['metadata']['uid'],'resources':pod['spec']['containers'][0]['resources'],'health':health,'source_manifest_sha256':expected},indent=2)+'\n')
go='/root/cm-nfs-multislot-20261105/tools/usr/local/go/bin/go'
env={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL','TZ','USER','LOGNAME') if k in os.environ}
env.update(PATH=str(Path(go).parent)+':'+env.get('PATH','/usr/bin:/bin'),GOTOOLCHAIN='local',CGO_ENABLED='0',GOMAXPROCS='2',GOPROXY='off',GOSUMDB='off',GOMODCACHE='/root/cm-nfs-multislot-20261105/cache/mod',GOCACHE='/root/cm-nfs-multislot-20261105/cache/build',NB_KEYS_TEST_PASSWORD='')
command=['env','NB_KEYS_TEST_MYSQL=127.0.0.1:33327',go,'test','./internal/ownerrecords','-run','^TestOwnerMigrationMySQL$','-json','-p','1','-count=1','-timeout=10m']
wrapper=[sys.executable,str(root/'ClawManager/docs/reports/run_database_evidence.py'),'--record',str(evidence/'v3-owner-baseline-resource-check.meta.json'),'--evidence',str(evidence/'v3-owner-baseline-resource-check.jsonl'),'--name','Owner baseline resource comparison','--suite-id','owner-baseline-resource-check','--category','后端整合','--kind','go-json','--cwd',str(root/'ClawManager/backend'),'--source-manifest',str(root/'source-manifest.json'),'--source-root',str(root),'--',*command]
raise SystemExit(subprocess.run(wrapper,env=env,check=False).returncode)
