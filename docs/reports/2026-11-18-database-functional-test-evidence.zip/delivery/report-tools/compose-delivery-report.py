"""Compose only recorded frozen-source results; render with the checked-in report tool."""
import argparse, hashlib, json, re, sys
from datetime import datetime, timezone
from pathlib import Path

root=Path('/root/cm-database-completion-20261118/final')
sys.path.insert(0,str(root/'report-delivery-tools'))
from generate_database_report import PERFORMANCE_EVIDENCE, REQUIRED_PERFORMANCE, duration_ms
parser=argparse.ArgumentParser();parser.add_argument('--tag',default='v1');parser.add_argument('--bundle',required=True);parser.add_argument('--output',required=True);args=parser.parse_args()
freeze=json.loads((root/'code-freeze.json').read_text())
suites=[json.loads(p.read_text()) for p in sorted((root/'evidence').glob(args.tag+'-*.meta.json'))]
identities=[s['suite_id'] for s in suites]
assert len(identities)==len(set(identities)),'duplicate suite identity'
performance=[]
names={'audit_default30':'审计默认30天 /30万条','audit90':'审计90天 /90万条','audit_search30':'审计默认30天搜索 /30万条','audit_search90':'管理员90天搜索 /90万条','admin_all':'管理员概览 /1万实例、30天选中30万调用','admin_fractional':'管理员概览 /非整日30天窗口','session_instance':'单实例会话统计 /90万全局调用','trace_page':'Trace分页 /90万全局调用','cost_overview':'费用概览 /90万账单、30天选中30万条','cost_fractional':'费用概览 /非整日30天窗口'}
for identity,(suite_id,marker) in PERFORMANCE_EVIDENCE.items():
 suite=next(s for s in suites if s['suite_id']==suite_id)
 matches=[]
 for raw in Path(suite['evidence']).read_text().splitlines():
  try:event=json.loads(raw)
  except ValueError:continue
  if not isinstance(event,dict) or event.get('Action')!='output':continue
  for line in event.get('Output','').splitlines():
   if 'MEASURED ' in line and marker in line and 'P95=' in line:matches.append((event['Test'],line))
 assert len(matches)==1,(identity,len(matches))
 test,line=matches[0]
 performance.append(dict(id=identity,name=names[identity],samples=int(re.search(r'samples=(\d+)',line)[1]),p50_ms=duration_ms(re.search(r'P50=(\S+)',line)[1]),p95_ms=duration_ms(re.search(r'P95=(\S+)',line)[1]),limit_ms=REQUIRED_PERFORMANCE[identity],evidence_suite_id=suite_id,evidence_test=test,evidence_output=line))
criteria=[
 ('queries','查询与稳定分页','SQL筛选/计数、30/90天范围、会话版本游标、完整Trace与独立正文', ['Test(SessionSQL|AdminSessionSQL|QueryReview|Trace|WholeBranch)']),
 ('large_tables','大表维护','500行/30秒与字节上限、租约暂停、已完成活动/结算安全保留、失败后继续推进', ['TestMySQL(BoundedMaintenance|LeaseAndBackupPause|ArchiveRestoreGate)|TestWholeBranch|TestHistoryCLI']),
 ('storage_dedup','正文去重与回收','同所有者去重/跨所有者隔离、真实存储失败、正文替换、证明和过期后的再次备份', ['TestEncryptedObjects|TestObservabilityUsesEncryptedReal|TestDurableInvocationRealMySQL|TestObservationNativeProof|TestWholeBranchActiveMonthBody']),
 ('redis_bounds','Redis容量与可靠回收','条数/字节/状态/键额度、终态预留、挂起与未知组保护、DLQ归档、删除中断恢复', ['TestReliableTeam|TestTeamState|TestReliableReceipt|TestManagedDeferredCapacity|TestSafeTeamTrim|TestQuiescentTeamTrim|TestTeamReceiptClosure|TestLiveTeamDLQ|TestDeletedTeamRedisCleanup']),
 ('E1_fee','E1费用正确性','同Trace多次调用、多条费用、回填并发与低ID晚提交；补偿不重复结算', ['TestCostReporting|TestCostSummary|TestQueryReview|TestWholeBranchLegacyCommit|TestGatewayObservationMatrix']),
 ('E2_audit','E2审计完整性','请求/计数一致、旧写入晚提交、归档先于热回填、完整错误与消息字段', ['TestAudit(Report|Summary|Backfill)|TestObservationBackfillCLI|TestWholeBranch']),
 ('E3_projection','E3原子投影','提交前无Redis副作用，断连/回滚/重启恢复，永久幂等与安全水位', ['TestAtomicProjection|TestTeamProjection|TestRuntimeJournalThroughManagedBridge']),
 ('E4_durable','E4持久补偿','真实网关普通/流式双存储故障、预留通道、全局/所有者拒绝在上游之前、重启重放无重复', ['TestJournal|TestGatewayObservationMatrix|TestGatewayExecutedResult']),
 ('E5_redis_reads','E5有界读取','批次/响应预算、异常协议、连接丢弃、错误信息不泄露凭据', ['TestRedisReply|TestRedisBusXRead|TestRedisReadFailure|TestManagedRedisRESP']),
 ('E6_backup_partials','E6未完成备份','活跃锁/心跳保护、失活身份与路径校验、实际MySQL镜像FD锁继承与重入', ['备份残留身份与锁故障测试','实际 MySQL 镜像锁继承与重入']),
 ('monthly_routing','月表实际读写','五种日志/展示副本，预建、跨月、旧ID、灰度切读/回滚、并发注册、字节前缀推进与恢复后ID不复用', ['TestWholeBranch']),
 ('native_restore','原生备份与隔离恢复','真实SQL/Redis/对象/文件六段链路、已签名证明、最小权限、篡改拒绝与惰性恢复', ['TestWholeBranchFullSchemaArchiveMonthlyNativeRestore|TestWholeBranchNativeRestorePreservesRetiredPublicIDFloor|TestObservationNativeProof|TestTeamHistoryNative|TestTeamDataMonthlyNativeSchemaRestore|TestSchemaContractMatchesFreshMigrations']),
 ('owner_authorization','正文与归档权限','真实认证下载、无身份/错误所有者拒绝、密文校验与跨所有者读取拒绝', ['TestRuntimePublicArtifact|TestRuntimeLargePublicDelivery|TestHistoryHandler|TestHistoryBody|TestEncryptedObjectsOwner']),
 ('frontend_workflows','实际页面流程','生产构建页面：审计/费用/Trace/会话，连续翻页、移动时钟、409/503、导出和手机显示', ['实际页面 audit-list-pagination','实际页面 cost-pagination','实际页面 trace-pagination','实际页面 session-refresh']),
 ('runtime_durability','Runtime可靠交付','完整Runtime回归，实际ENOSPC、Redis OOM/AOF、并发执行所有权与不确定通知保留', ['Hermes 全部测试','OpenCode 全部协议测试','Runtime 实际 ENOSPC','Node durable-claim-race-test','TestRuntimeJournalThroughManagedBridge']),
]
coverage=[dict(id=identity,title=title,criterion=criterion,selectors=selectors) for identity,title,criterion,selectors in criteria]
bundle=Path(args.output).parent/args.bundle
source=dict(freeze['source']);source['manifest_sha256']=hashlib.sha256((root/'source-manifest.json').read_bytes()).hexdigest()
manifest=dict(title='数据库与 Redis 整改完整功能测试报告',development_complete=True,review_passed=True,code_frozen_at=freeze['code_frozen_at'],created_at=datetime.now(timezone.utc).isoformat(),source=source,environment=freeze['environment'],suites=suites,coverage=coverage,performance=performance,evidence_bundle=args.bundle,evidence_bundle_sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),regressions=freeze.get('regressions',[]),screenshots=freeze.get('screenshots',[]),limitations=freeze.get('limitations',[]))
Path(args.output).write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'suites':len(suites),'performance':len(performance),'manifest':args.output}))
