package repository
import("context";"testing";"time";"sort";"os";"github.com/upper/db/v4/adapter/mysql")
// Development diagnostic only: uses explicitly synthetic report rows, not source/backfill acceptance.
func TestDevelopmentAuditSearchThreshold(t *testing.T){
 if os.Getenv("CM_AUDIT_DEVELOPMENT_DIAGNOSTIC")!="1" {t.Skip("development diagnostic")}
 s,e:=mysql.Open(mysql.ConnectionURL{Host:"127.0.0.1:33337",User:"root",Database:"cm_audit_diag_1794947475049501366",Options:map[string]string{"parseTime":"true"}});if e!=nil{t.Fatal(e)};defer s.Close()
 if _,e=s.SQL().Exec("UPDATE observation_audit_backfill SET complete=TRUE");e!=nil{t.Fatal(e)}
 r:=NewModelInvocationRepository(s).(*modelInvocationRepository);until:=time.Date(2026,11,17,0,0,0,0,time.UTC)
 for _,days:=range []int{30,90}{start:=until.Add(-time.Duration(days)*24*time.Hour);times:=[]time.Duration{};for i:=0;i<20;i++{at:=time.Now();p,e:=r.ListAuditReportPage(context.Background(),AuditReportQuery{Limit:20,Since:&start,Until:&until,Search:"capacity-model"});times=append(times,time.Since(at));if e!=nil||p.Total!=days*10000||len(p.Items)!=20||p.NextCursor==""{t.Fatalf("shape %v %v",p,e)}};sort.Slice(times,func(i,j int)bool{return times[i]<times[j]});threshold:=2*time.Second;if days==30{threshold=500*time.Millisecond};t.Logf("DEVELOPMENT_SYNTHETIC_ONLY days=%d P95=%s threshold=%s",days,times[18],threshold);if times[18]>threshold{t.Errorf("actual repository search %dd P95 %s exceeds %s",days,times[18],threshold)}}
}
