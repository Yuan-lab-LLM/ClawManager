package main
import("database/sql";"fmt";"strings";"time";_ "github.com/go-sql-driver/mysql")
func must(e error){if e!=nil{panic(e)}}
func main(){
 db,e:=sql.Open("mysql","root@tcp(127.0.0.1:33327)/cm_database_test_1794946418032154124?parseTime=true");must(e);defer db.Close();db.SetMaxOpenConns(1)
 var marker int;must(db.QueryRow("SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='cm_database_test_marker'").Scan(&marker));if marker!=1{panic("marker")}
 selectQuery:=`SELECT p.id FROM observation_cost_pending p JOIN cost_records c ON c.id=p.id JOIN observation_cost_facts f ON f.id=c.id AND f.trace_id=c.trace_id AND f.invocation_id=c.invocation_id AND f.estimated_cost=c.estimated_cost AND f.resolved=TRUE ORDER BY p.id LIMIT 500`
 bounded:=strings.ReplaceAll(selectQuery," JOIN "," STRAIGHT_JOIN ")
 for _,v:=range []struct{name,q string}{{"original",selectQuery},{"bounded",bounded}}{var plan string;must(db.QueryRow("EXPLAIN FORMAT=JSON "+v.q).Scan(&plan));fmt.Println("PLAN",v.name,strings.ReplaceAll(plan,"\n"," "))}
 tx,e:=db.Begin();must(e);defer tx.Rollback();var before int;must(tx.QueryRow("SELECT COUNT(*) FROM observation_cost_pending").Scan(&before))
 rows,e:=tx.Query(`SELECT f.id,f.trace_id,f.invocation_id,f.estimated_cost,f.resolved FROM observation_cost_pending p STRAIGHT_JOIN observation_cost_facts f ON f.id=p.id ORDER BY p.id LIMIT 4`);must(e)
 type fact struct{id,inv int64;trace,cost string;resolved bool};facts:=[]fact{};for rows.Next(){var f fact;must(rows.Scan(&f.id,&f.trace,&f.inv,&f.cost,&f.resolved));facts=append(facts,f)};must(rows.Err());rows.Close();if len(facts)!=4{panic("four receipt probes required")}
 updates:=[]string{"trace_id=CONCAT(trace_id,'-diagnostic-mismatch')","invocation_id=invocation_id+10000000","estimated_cost=estimated_cost+1","resolved=FALSE"}
 for i,f:=range facts{_,e=tx.Exec("UPDATE observation_cost_facts SET "+updates[i]+" WHERE id=?",f.id);must(e)}
 at:=time.Now();result,e:=tx.Exec(`DELETE FROM observation_cost_pending WHERE id IN (SELECT id FROM (`+bounded+`) verified)`);must(e);changed,e:=result.RowsAffected();must(e);if changed!=500{panic(changed)}
 for i,f:=range facts{var n int;must(tx.QueryRow("SELECT COUNT(*) FROM observation_cost_pending WHERE id=?",f.id).Scan(&n));if n!=1{panic("mismatched receipt removed")};fmt.Printf("UNVERIFIED_RETAINED id=%d predicate=%s count=%d\n",f.id,updates[i],n)}
 var after int;must(tx.QueryRow("SELECT COUNT(*) FROM observation_cost_pending").Scan(&after));if after!=before-500{panic("wrong pending progress")}
 for _,f:=range facts{_,e=tx.Exec("UPDATE observation_cost_facts SET trace_id=?,invocation_id=?,estimated_cost=?,resolved=? WHERE id=?",f.trace,f.inv,f.cost,f.resolved,f.id);must(e)}
 must(tx.Commit());fmt.Printf("VERIFIED_BATCH_COMMITTED before=%d after=%d exact_deleted=%d elapsed=%s all_four_original_facts_restored=true\n",before,after,changed,time.Since(at))
}
