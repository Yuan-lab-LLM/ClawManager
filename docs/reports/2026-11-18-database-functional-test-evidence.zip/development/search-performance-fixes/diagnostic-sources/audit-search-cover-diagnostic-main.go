package main
import("database/sql";"fmt";"sort";"strings";"time";_ "github.com/go-sql-driver/mysql")
func must(e error){if e!=nil{panic(e)}}
func main(){
 db,e:=sql.Open("mysql","root@tcp(127.0.0.1:33337)/cm_audit_diag_1794947475049501366?parseTime=true");must(e);defer db.Close();db.SetMaxOpenConns(2)
 var exists int;must(db.QueryRow("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='observation_audit_trace_reports' AND INDEX_NAME='idx_audit_report_model_search'").Scan(&exists))
 if exists==0{at:=time.Now();_,e=db.Exec("ALTER TABLE observation_audit_trace_reports ADD INDEX idx_audit_report_model_search(sort_at,requested_model,actual_provider_model,sequence_id,id,status)");must(e);fmt.Println("DIAGNOSTIC_INDEX_CREATE",time.Since(at))}
 until:=time.Date(2026,11,17,0,0,0,0,time.UTC);start:=until.Add(-30*24*time.Hour);models:=`(LOCATE(?,LOWER(COALESCE(r.requested_model,'')))>0 OR LOCATE(?,LOWER(COALESCE(r.actual_provider_model,'')))>0)`
 base:=` FROM observation_audit_trace_reports r FORCE INDEX(idx_audit_report_model_search)`;where:=` WHERE r.id>0 AND r.sort_at>=? AND r.sort_at<? AND r.sequence_id<=?`;args:=[]any{start,until,900000,"capacity-model","capacity-model"}
 first:="SELECT COUNT(*) n"+base+where+" AND "+models
 clauses:=[]string{};for _,f:=range []string{"u.username","r.trace_id","r.request_id","r.provider_type","r.event_type","r.message"}{clauses=append(clauses,"LOCATE(?,LOWER(COALESCE("+f+",'')))>0")}
 second:="SELECT COUNT(*) n"+base+" LEFT JOIN users u ON u.id=r.user_id"+where+" AND NOT "+models+" AND ("+strings.Join(clauses," OR ")+")";args2:=append([]any{},args...);for range clauses{args2=append(args2,"capacity-model")}
 for _,v:=range []struct{name,q string;args []any;want int}{{"covered-model",first,args,300000},{"remaining-fields",second,args2,0},{"disjoint-union","SELECT SUM(n) FROM ("+first+" UNION ALL "+second+") counted",append(append([]any{},args...),args2...),300000}}{
 var plan string;must(db.QueryRow("EXPLAIN FORMAT=JSON "+v.q,v.args...).Scan(&plan));fmt.Printf("PLAN name=%s %s\n",v.name,strings.ReplaceAll(plan,"\n"," "))
 times:=[]time.Duration{};for i:=0;i<20;i++{at:=time.Now();var n int;must(db.QueryRow(v.q,v.args...).Scan(&n));if n!=v.want{panic(n)};times=append(times,time.Since(at))};sort.Slice(times,func(i,j int)bool{return times[i]<times[j]});fmt.Printf("COUNT name=%s P50=%s P95=%s MAX=%s\n",v.name,times[9],times[18],times[19])
 rows,e:=db.Query("EXPLAIN ANALYZE "+v.q,v.args...);must(e);for rows.Next(){var a string;must(rows.Scan(&a));fmt.Printf("ACTUAL name=%s %s\n",v.name,a)};rows.Close()
 }
}
