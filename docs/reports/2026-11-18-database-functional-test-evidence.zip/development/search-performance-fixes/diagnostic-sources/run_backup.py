import json,os,subprocess,sys,pathlib
root=pathlib.Path('/root/cm-database-completion-20261118/audit-search-v3')
env=os.environ.copy();env.pop('GOROOT',None)
env.update(GOTOOLCHAIN='local',CGO_ENABLED='0',GOMAXPROCS='2',GOPROXY='off',GOSUMDB='off',GOMODCACHE='/root/cm-nfs-multislot-20261105/cache/mod',GOCACHE='/root/cm-nfs-multislot-20261105/cache/build',TEST_DATABASE_MYSQL_PORT='33317',CM_HISTORY_MINIO_CREDENTIALS='/root/cm-database-completion-20261118/fixtures/minio-credentials.json',TEST_SYSTEM_BACKUP_MYSQL_PORT='33317',TEST_SYSTEM_BACKUP_MINIO_PORT='33319',TEST_SYSTEM_BACKUP_REDIS_PORT='33318',TEST_SYSTEM_BACKUP_REDIS_TARGET_PORT='33320',TEST_SYSTEM_BACKUP_REDIS_DATABASE='15',TEST_SYSTEM_BACKUP_VERIFY_EXE=str(root/'bin/system-backup-artifact'))
with open('/root/cm-database-completion-20261118/fixtures/minio-credentials.json') as f:creds=json.load(f)
env['TEST_SYSTEM_BACKUP_MINIO_USER']=creds['access_key'];env['TEST_SYSTEM_BACKUP_MINIO_PASSWORD']=creds['secret_key']
log=sys.argv[1];selector=sys.argv[2]
args=['/root/cm-nfs-multislot-20261105/tools/usr/local/go/bin/go','test','./internal/systembackup','-run',selector,'-count=1','-v','-timeout=5m']
if len(sys.argv)>3 and sys.argv[3]=='race': env['CGO_ENABLED']='1';args.insert(2,'-race')
with (root/'evidence'/log).open('w') as out:r=subprocess.run(args,cwd=root/'ClawManager/backend',env=env,stdout=out,stderr=subprocess.STDOUT)
print(log,'exit',r.returncode)
for line in (root/'evidence'/log).read_text().splitlines():
 if line.startswith(('--- PASS','--- FAIL','ok ','FAIL')) or 'pipeline_integration_test.go:' in line: print(line)
sys.exit(r.returncode)
