package main
import (
 "context"
 "database/sql"
 "fmt"
 "os"
 "sort"
 "regexp"
 "strings"
 "time"
 "clawreef/internal/config"
 appdb "clawreef/internal/db"
 _ "github.com/go-sql-driver/mysql"
)
func must(e error){if e!=nil{panic(e)}}
func main(){
 root,e:=sql.Open("mysql","root@tcp(127.0.0.1:33337)/mysql?parseTime=true");must(e);defer root.Close()
 var marker int;must(root.QueryRow("SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME='cm_database_test_marker'").Scan(&marker));if marker!=1{panic("marker")}
 name:=fmt.Sprintf("cm_audit_diag_%d",time.Now().UnixNano());fresh:=len(os.Args)==1;if !fresh{name=os.Args[1];if !strings.HasPrefix(name,"cm_audit_diag_"){panic("unowned schema")}}
 if fresh{_,e=root.Exec("CREATE DATABASE "+name);must(e)}
 s,e:=appdb.Initialize(config.DatabaseConfig{Host:"127.0.0.1",Port:33337,User:"root",Database:name,MaxOpenConns:4,MaxIdleConns:2});must(e);defer s.Close();pool:=s.Driver().(*sql.DB)
 execute:=func(q string,args ...any){_,e:=pool.Exec(q,args...);must(e)}
 until:=time.Date(2026,11,17,0,0,0,0,time.UTC);since:=until.Add(-90*24*time.Hour)
 if fresh{
 execute("INSERT IGNORE INTO users(id,username,email,password_hash) VALUES(1,'capacity-auditor','capacity-auditor@example.test','fixture')")
 execute("CREATE TABLE diagnostic_digits(n INT PRIMARY KEY)");execute("INSERT INTO diagnostic_digits VALUES(0),(1),(2),(3),(4),(5),(6),(7),(8),(9)")
 numbers:=`SELECT a.n+10*b.n+100*c.n+1000*d.n+10000*e.n+100000*f.n n FROM diagnostic_digits a CROSS JOIN diagnostic_digits b CROSS JOIN diagnostic_digits c CROSS JOIN diagnostic_digits d CROSS JOIN diagnostic_digits e CROSS JOIN diagnostic_digits f`
 at:=time.Now();execute(`INSERT INTO observation_audit_trace_reports(sequence_id,id,trace_id,request_id,session_id,user_id,instance_id,requested_model,actual_provider_model,provider_type,status,prompt_tokens,completion_tokens,total_tokens,created_at,sort_at,message) SELECT n+1,n+1,CONCAT('audit-',FLOOR(n/90)+1,'-',MOD(n,90)),CONCAT('req-',FLOOR(n/90)+1,'-',MOD(n,90)),'main',1,FLOOR(n/90)+1,'auto','capacity-model','openai','completed',10,5,15,DATE_ADD(?,INTERVAL MOD(n,90) DAY),DATE_ADD(?,INTERVAL MOD(n,90) DAY),'' FROM (`+numbers+`) v WHERE n<900000 ORDER BY n`,since,since)
 fmt.Printf("DIAGNOSTIC_ONLY_SYNTHETIC_REPORTS database=%s rows=900000 seed=%s not_backfill_acceptance=true\n",name,time.Since(at));execute("ANALYZE TABLE observation_audit_trace_reports")
 }
 fmt.Println("DIAGNOSTIC_DATABASE",name)
 for _,hint:=range []string{""," FORCE INDEX(PRIMARY)"," IGNORE INDEX(idx_audit_report_count)"}{for _,join:=range []bool{true,false}{
  base:=" FROM observation_audit_trace_reports r"+hint;if join{base+=" LEFT JOIN users u ON u.id=r.user_id"};base+=" WHERE r.id>0 AND r.sort_at>=? AND r.sort_at<? AND r.sequence_id<=?"
  args:=[]any{until.Add(-30*24*time.Hour),until,900000};clauses:=[]string{}
  for _,field:=range []string{"r.requested_model","r.actual_provider_model","u.username","r.trace_id","r.request_id","r.provider_type","r.event_type","r.message"}{
   if field=="u.username"&&!join{clauses=append(clauses,"r.user_id IN (SELECT id FROM users WHERE LOCATE(?,LOWER(COALESCE(username,'')))>0)")}else{clauses=append(clauses,"LOCATE(?,LOWER(COALESCE("+field+",'')))>0")};args=append(args,"capacity-model")
  }
  q:="SELECT COUNT(*)"+base+" AND ("+strings.Join(clauses," OR ")+")";if len(os.Args)>2 && os.Args[2]=="collation" { q=regexp.MustCompile(`LOWER\(COALESCE\(([a-z_.]+),''\)\)`).ReplaceAllString(q,"$1") };var plan string;must(pool.QueryRow("EXPLAIN FORMAT=JSON "+q,args...).Scan(&plan));fmt.Printf("PLAN join=%v hint=%q %s\n",join,hint,strings.ReplaceAll(plan,"\n"," "))
  times:=[]time.Duration{};for i:=0;i<5;i++{at:=time.Now();var count int;must(pool.QueryRowContext(context.Background(),q,args...).Scan(&count));if count!=300000{panic(count)};times=append(times,time.Since(at))};sort.Slice(times,func(i,j int)bool{return times[i]<times[j]});fmt.Printf("COUNT join=%v hint=%q min=%s median=%s max=%s\n",join,hint,times[0],times[2],times[4])
 }}
}
